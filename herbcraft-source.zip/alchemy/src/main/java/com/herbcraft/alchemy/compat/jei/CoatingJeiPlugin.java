package com.herbcraft.alchemy.compat.jei;

import com.herbcraft.alchemy.coating.CoatingItems;
import com.herbcraft.alchemy.coating.CoatingSmithingRecipe;
import com.herbcraft.alchemy.coating.CoatingSystem;
import com.herbcraft.alchemy.coating.WeaponCoating;
import com.herbcraft.alchemy.registry.AlchemyRegistries;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.gui.builder.IIngredientAcceptor;
import mezz.jei.api.recipe.category.extensions.vanilla.smithing.ISmithingCategoryExtension;
import mezz.jei.api.registration.IRecipeRegistration;
import mezz.jei.api.registration.IVanillaCategoryExtensionRegistration;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;

@JeiPlugin
public final class CoatingJeiPlugin implements IModPlugin {
   private static final Identifier PLUGIN_ID = Identifier.fromNamespaceAndPath("herbcraft", "coating_jei");
   private static final ResourceKey<Recipe<?>> APPLY_RECIPE_ID = recipeKey("coating_apply");
   private static final ResourceKey<Recipe<?>> REFINE_RECIPE_ID = recipeKey("coating_refine");

   public Identifier getPluginUid() {
      return PLUGIN_ID;
   }

   public void registerVanillaCategoryExtensions(IVanillaCategoryExtensionRegistration registration) {
      registration.getSmithingCategory().addExtension(CoatingSmithingRecipe.class, new CoatingSmithingExtension());
   }

   public void registerRecipes(IRecipeRegistration registration) {
      registration.addRecipes(RecipeTypes.SMITHING, List.of(
         new RecipeHolder<>(APPLY_RECIPE_ID, new CoatingSmithingRecipe(CoatingSmithingRecipe.RecipeMode.APPLY)),
         new RecipeHolder<>(REFINE_RECIPE_ID, new CoatingSmithingRecipe(CoatingSmithingRecipe.RecipeMode.REFINE))
      ));
   }

   private static ResourceKey<Recipe<?>> recipeKey(String path) {
      return ResourceKey.create(Registries.RECIPE, Identifier.fromNamespaceAndPath("herbcraft", path));
   }

   private static final class CoatingSmithingExtension implements ISmithingCategoryExtension<CoatingSmithingRecipe> {
      public <T extends IIngredientAcceptor<T>> void setTemplate(CoatingSmithingRecipe recipe, T acceptor) {
         if (recipe.recipeMode() == CoatingSmithingRecipe.RecipeMode.APPLY) {
            acceptor.add(CoatingItems.BLANK_ADHESIVE);
         } else {
            acceptor.addItemStacks(List.of(new ItemStack(CoatingItems.AMETHYST_ADHESIVE), new ItemStack(CoatingItems.ECHO_ADHESIVE)));
         }
      }

      public <T extends IIngredientAcceptor<T>> void setBase(CoatingSmithingRecipe recipe, T acceptor) {
         if (recipe.recipeMode() == CoatingSmithingRecipe.RecipeMode.APPLY) {
            acceptor.add(recipe.baseIngredient());
         } else {
            acceptor.addItemStacks(fullCoatedSamples());
         }
      }

      public <T extends IIngredientAcceptor<T>> void setAddition(CoatingSmithingRecipe recipe, T acceptor) {
         if (recipe.recipeMode() == CoatingSmithingRecipe.RecipeMode.APPLY) {
            acceptor.add(recipe.additionIngredient().orElseThrow());
         }
      }

      public <T extends IIngredientAcceptor<T>> void setOutput(CoatingSmithingRecipe recipe, T acceptor) {
         if (recipe.recipeMode() == CoatingSmithingRecipe.RecipeMode.APPLY) {
            acceptor.addItemStacks(fullCoatedSamples());
         } else {
            acceptor.addItemStacks(refinedSamples());
         }
      }

      private static List<ItemStack> fullCoatedSamples() {
         List<ItemStack> stacks = new ArrayList<>();
         for (AlchemyRegistries.EssenceInfo info : AlchemyRegistries.essenceInfos()) {
            stacks.add(sample(info, WeaponCoating.Mode.FULL));
         }
         return stacks;
      }

      private static List<ItemStack> refinedSamples() {
         List<ItemStack> stacks = new ArrayList<>();
         for (AlchemyRegistries.EssenceInfo info : AlchemyRegistries.essenceInfos()) {
            if (info.effects().stream().anyMatch(AlchemyRegistries.EssenceEffect::positive)) {
               stacks.add(sample(info, WeaponCoating.Mode.POSITIVE));
            }
            if (info.effects().stream().anyMatch(effect -> !effect.positive())) {
               stacks.add(sample(info, WeaponCoating.Mode.NEGATIVE));
            }
         }
         return stacks;
      }

      private static ItemStack sample(AlchemyRegistries.EssenceInfo info, WeaponCoating.Mode mode) {
         ItemStack stack = new ItemStack(Items.IRON_SWORD);
         CoatingSystem.applyCoating(stack, info, mode);
         return stack;
      }
   }
}
