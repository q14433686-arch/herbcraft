package com.herbcraft.alchemy;

import net.fabricmc.api.ModInitializer;
import com.herbcraft.alchemy.registry.AlchemyRegistries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HerbcraftAlchemy implements ModInitializer {
	public static final String MOD_ID = "herbcraft_alchemy";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		AlchemyRegistries.initialize();
		LOGGER.info("Herbcraft: Alchemy loaded. Registered M6 essence sample set and brewing mixes.");
	}
}
