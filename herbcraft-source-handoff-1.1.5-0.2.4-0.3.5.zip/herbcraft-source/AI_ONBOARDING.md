# AI_ONBOARDING

This file is for the next AI agent taking over Herbcraft. Read it before editing anything.

## Mandatory first step

Before writing code, the next AI must:

1. Read this file.
2. Read `PROJECT_STATE.md`, `BUGS_TODO.md`, `NEXT_TASK.md`, and `CHANGE_IMPACT.md`.
3. Inspect the current source tree and resources.
4. Output a **接手状态报告** using the template below.
5. Wait for the author to confirm before changing code, unless the author explicitly says to proceed immediately.

## Environment lock

- Minecraft `26.1.2`
- Fabric Loader `0.19.3`
- Fabric API `0.151.0+26.1.2`
- Java `25`
- Gradle `9.4.1`
- Fabric Loom `1.16-SNAPSHOT` / resolved `1.16.3`
- Official Mojang names; MC 26.1 is unobfuscated and does not use Yarn remapping.

## Three design philosophies

1. **Stable IDs are sacred**  
   Never rename existing item, potion, recipe, component, trade or knowledge IDs. Save compatibility and existing docs depend on them.

2. **Data-driven where possible**  
   MC 26.1 made villager trades data-driven. Loot injection uses Fabric `LootTableEvents.MODIFY`. Recipes, tags and language files should remain resources unless behavior requires code.

3. **Modular addons must be removable**  
   Core must run by itself. Cuisine and alchemy must not leak their trades, loot, codex entries or item variants when their jars are absent.

## Absolute architecture rules

- Do not use `TradeOfferHelper`; use 26.1 `data/<namespace>/villager_trade` plus `data/minecraft/tags/villager_trade/...`.
- Do not replace full loot tables. Use `LootTableEvents.MODIFY` and guard with `source.isBuiltin()`.
- Do not implement REI/JEI until a 26.1-compatible REI exists.
- Do not shorten translations to fix UI overflow. Fix UI layout.
- Do not add Mixins unless vanilla/Fabric APIs cannot express the behavior. Current known exception: `herbcraft_alchemy` has a minimal `ItemCost` Mixin so high-tier randomized potions can be sold to villagers by potion kind.
- Do not add empty/bare `tattered_page` to creative tabs. Creative pages must carry `herbcraft:page_entry`.
- Keep `CodexScreen.isPauseScreen()` returning `false`.

## Current module responsibilities

### core / `herbcraft`

- Loads `data/herbcraft/herbs.json` into edible herb definitions.
- Applies food/consumable components to vanilla items.
- Provides `HerbcraftAPI`, `KnowledgeAPI`, `HerbConsumeEvents`.
- Implements Herb Codex UI and knowledge sync.
- Registers `herbcraft:herbal_codex` and `herbcraft:tattered_page`.
- Injects core tattered page loot.
- Adds creative tab variants for all loaded tattered page entries.
- Tracks last meal and centralizes herb/cuisine consume sound resolution.
- Provides `#herbcraft:herb` item tag used by hodgepodge crafting.

### alchemy / `herbcraft_alchemy`

- Registers essences and herbal potion chains.
- High-tier potion progression: `_clarified`, `_murky`, `undead_venom`, `cardiac_toxin`, `wither_venom_iii`.
- Adds randomized high-tier potion quality and bonus components.
- Weapon coating system with `herbcraft:weapon_coating` component.
- Adds alchemy codex entries, loot page injection and data-driven villager trades.
- Contains `ItemCostAdvancedPotionMixin` so randomized high-tier potion stacks match villager buy trades by potion identity.

### cuisine / `herbcraft_cuisine`

- Loads curated dishes from `data/herbcraft_cuisine/dishes.json`.
- Registers raw and cooked dish items, water bowl and hodgepodge.
- Registers cooking/crafting recipes and `herbcraft_cuisine:hodgepodge` custom recipe.
- Hodgepodge crafting writes ingredient snapshots to `herbcraft_cuisine:hodgepodge_contents`.
- Hodgepodge eating dynamically resolves stored ingredients through core herb definitions.
- Adds cuisine codex entries, loot page injection and data-driven villager trades.

## Required 接手状态报告 format

```md
# 接手状态报告

## 1. 我已阅读的文件
- AI_ONBOARDING.md
- PROJECT_STATE.md
- NEXT_TASK.md
- BUGS_TODO.md
- CHANGE_IMPACT.md
- 其他：...

## 2. 当前环境确认
- MC:
- Fabric Loader:
- Fabric API:
- Java:
- Gradle/Loom:

## 3. 当前模块状态
### core
- ...
### alchemy
- ...
### cuisine
- ...

## 4. 我看到的当前重点功能
- ...

## 5. 我看到的风险点 / 不应破坏的内容
- ...

## 6. 我建议下一步做什么
- ...

## 7. 开始编码前需要作者确认的问题
- ...
```

## Useful validation commands

```bash
./gradlew clean build
python3 scripts/check_lang_diff.py
python3 scripts/validate_trade_tags.py
python3 scripts/validate_panel_hodge_recipe.py
python3 scripts/validate_fix_codex_hodgepodge.py
python3 scripts/validate_bugfix_advanced_potion_trade.py
```

Some scripts may be historical diagnostics; if absent or stale, update them rather than trusting them blindly.
