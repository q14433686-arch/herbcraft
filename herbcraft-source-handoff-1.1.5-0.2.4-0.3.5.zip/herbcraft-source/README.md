# Herbcraft / 百草可食

Herbcraft is a Fabric 26.1.2 mod suite about turning Minecraft plants, odd natural materials, foodcraft and alchemy into a coherent survival system.

This repository is source-only. Release jars should be downloaded from the project's GitHub Releases page, not committed into the source tree.

## Modules

| Module | Mod id | Current version | Purpose |
|---|---|---:|---|
| `core` | `herbcraft` | `1.1.5` | Core edible herb definitions, raw herb effects, Herb Codex / 百草经, tattered pages, shared APIs. |
| `alchemy` | `herbcraft_alchemy` | `0.2.4` | Essences, herbal potions, clarified/murky high-tier potion progression, potion quality/bonus components, weapon coating, alchemy trades. |
| `cuisine` | `herbcraft_cuisine` | `0.3.5` | Curated dishes, raw dish cooking, water bowl, Herbal Hodgepodge / 百草盅, cuisine trades and cuisine codex chapter. |

## Environment

- Minecraft Java Edition `26.1.2`
- Fabric Loader `0.19.3`
- Fabric API `0.151.0+26.1.2`
- Java `25`
- Gradle `9.4.1`
- Fabric Loom `1.16-SNAPSHOT` / resolved `1.16.3`
- Mojang official names / no Yarn remapping

## Design philosophy

1. **Data first, code second**: herbs, dishes, recipes, loot tables and villager trades should stay data-driven where 26.1 supports it.
2. **Module boundaries matter**: core must run alone; alchemy/cuisine content must disappear cleanly when their jar is absent.
3. **Compatibility over cleverness**: prefer Fabric API events and vanilla 26.1 data-driven systems. Use Mixins only when the vanilla/Fabric API surface cannot express the required behavior.

## Development discipline

- Do not rename existing IDs such as `_clarified`, `_murky`, `herbcraft:tattered_page`, or existing dish/essence IDs.
- Do not replace vanilla loot tables or trade tags. Always append with `replace: false` or `LootTableEvents.MODIFY` guarded by `source.isBuiltin()`.
- Do not use old `TradeOfferHelper`; MC 26.1 villager trading is data-driven.
- Keep REI/JEI integration disabled until a 26.1-compatible REI exists.
- Before writing code, read `AI_ONBOARDING.md` and produce a handoff/status report.

## Build

Use Java 25.

```bash
./gradlew clean build
```

If the wrapper is not available in your environment, use Gradle 9.4.1 directly:

```bash
JAVA_HOME=/path/to/jdk-25 gradle clean build
```

Built jars are generated under each module's `build/libs/` directory. These build outputs are ignored by git.

## Release guide for the author

- Upload jars through **GitHub Releases**.
- Do **not** place release jars in the source repository.
- The source repo should contain code, resources, docs and Gradle files only.
- For the next AI handoff, simply say: **“请先读 AI_ONBOARDING.md”**.
