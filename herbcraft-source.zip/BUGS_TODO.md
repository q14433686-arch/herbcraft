# BUGS_TODO

Current for Herbcraft `1.1.1` test baseline.

## Current known risks

| Priority | Area | Item |
|---:|---|---|
| P0 | Release sanity | Before public upload, run a clean build and all validators listed in `CURRENT_BASELINE.md`. |
| P0 | Client compatibility | Homeostatic compatibility has passed local client testing after the negative-amount fix, but should be rechecked if Homeostatic updates its data format or water storage behavior. |
| P0 | Brewing interaction | Hidden cuisine catalyst brewing passed local client testing once, but should be rechecked in any release candidate with all three jars installed. |
| P1 | Dynamic essence extension | Extra JSON essences can register, but polished addon entries still require assets, lang, recipes, and optional trade/Codex resources. Use `scripts/generate_essence_resources.py`. |
| P1 | Advancement reachability | Advancement JSON loads and count validators pass, but a full reachability/criteria audit remains useful. |
| P1 | Public extension docs | `docs/EXTENDING_HERBCRAFT.md` exists, but the extension surface is still a 1.1.x test-line contract, not a long-term stable public API promise. |
| P2 | Animal food validator | `validate_animal_food_tags.py` can fail without a vanilla client jar cache. Update it to use Loom's client jar or provide the cache if needed. |
| P2 | REI | REI compatibility is not implemented. |

## Recently addressed

### Source/jar consistency

- Built jars are now `1.1.1`.
- Alchemy and Cuisine depend on `herbcraft >=1.1.1`.
- `BrewingStandCatalystMixin.java` exists and builds.
- Hidden Cuisine dishes exist in source/resources/built jars.
- `百草经总纲` is registered in source.

### Nutrition and Homeostatic

- Nutrition uses custom Herbcraft effects, not vanilla negative effects.
- Nutrition effect mechanics and timing are data-backed by `data/herbcraft/nutrition_effects.json`.
- Stale nutrition effects are cleared on evaluation before current-state effects are applied.
- Severe malnutrition is sustained; warning states remain light/probabilistic.
- Cuisine clear effects skip Herbcraft nutrition effects.
- Milk bucket has gentle `flesh/oil` nutrition.
- Displayed `fruit` nutrition dimension is now `津液` / `Fluids`.
- Optional Homeostatic compatibility exists for Cuisine custom edible outputs and selected Core/vanilla Herbcraft edible items.
- Homeostatic negative `amount` values were removed after client testing showed below-zero internal water could keep dehydration active after partial recovery.
- Selected drink-like Cuisine dishes are `can_always_eat` so they can hydrate at full hunger.

### Data-driven architecture

The following major tables are JSON-backed:

- herbs
- herb natures
- nutrition profiles
- nutrition effects
- special counters
- Codex loot injections
- Cuisine dishes
- hodgepodge rules
- alchemy essences
- potion bonus pools
- special/T3/witch potions
- witch loot
- coating rules
- Homeostatic drinkable compatibility

## TODO / future ideas

| Priority | Idea |
|---:|---|
| P1 | Add better documentation/examples for third-party Herbcraft addon authors after 1.1.1 settles. |
| P1 | Consider a dedicated Hardcore Nutrition addon. Do not harden the main mod further by default. |
| P1 | Consider Homeostatic temperature compatibility for ice/snow/hot foods, separate from thirst. |
| P2 | Improve generated or placeholder textures if the author dislikes in-game presentation. |
| P2 | Add more generators for cuisine/trades/Codex resources if extension work increases. |

## Required validation before release claim

```bash
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
python3 scripts/check_lang_diff.py
python3 scripts/validate_custom_nutrition_effects_phase8.py
python3 scripts/validate_externalized_rules.py
python3 scripts/validate_essence_resources.py
python3 scripts/validate_homeostatic_compat.py
python3 scripts/validate_nutrition_cuisine_immunity_isolation.py
python3 scripts/validate_recipe_isolation.py
python3 scripts/validate_trade_tags.py
python3 scripts/validate_item_textures.py
python3 scripts/validate_task_abcd.py
python3 scripts/validate_extended_features.py
python3 scripts/verify_built_jars.py
```
