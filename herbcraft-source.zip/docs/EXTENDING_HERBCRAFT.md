# Extending Herbcraft 1.1.2

This document describes the current supported data-extension surface for Herbcraft `1.1.2` on Minecraft `26.1.2`.

Herbcraft is increasingly data-driven, but not every internal ID is meant to be configurable. Stable registry IDs, component IDs, packet IDs, and recipe serializer IDs should be treated as code-level API, not pack-level configuration.

## Golden rules

1. Keep IDs stable once published.
2. Add gameplay data in JSON where a loader exists.
3. Provide matching assets, language keys, and recipes for any newly registered item.
4. Run validators before testing in-game.
5. Do not expect UI constants, packet IDs, component IDs, or serializer IDs to be data-driven.

## Current data-driven systems

Herbcraft now has two distinct extension layers:

1. **Bundled baseline files** inside Herbcraft modules, used by the main mod content.
2. **External extension paths** for addon/datapack compatibility.

Do not confuse these layers. Editing the bundled files is appropriate for maintaining Herbcraft itself. Third-party compatibility should use the external paths described below.

### Core

- `data/herbcraft/herbs.json` — edible raw item definitions, including stable food values and optional probabilistic `food_rolls`.
- `data/herbcraft/herb_natures.json` — temperature, pharmacological flavors, taste flavors, and traits.
- `data/herbcraft/nutrition_profiles.json` — five-dimension nutrition profiles.
- `data/herbcraft/nutrition_rules.json` — nutrition decay/check thresholds.
- `data/herbcraft/nutrition_effects.json` — custom nutrition effect mechanics and timing.
- `data/herbcraft/nutrition_correction_rules.json` — dimension-specific correction relationship weights and self-penalty multiplier.
- `data/herbcraft/pharmacology_rules.json` — five-flavor multipliers, qi regression timing, data-backed temperature values, seven-emotion relation rules/priority, and pharmacology balance constants.
- `data/herbcraft/special_counters.json` — poppy/sugar/slime/etc. overuse counters.
- `data/herbcraft/ingredients.json` — vanilla food entries for the 食材录 knowledge chapter (items and section assignments).
- `data/herbcraft/codex_guides.json` — Core-owned guide entries under 百草经总纲.
- `data/herbcraft/guide_hints.json` — Core-owned once-per-player onboarding hints.
- `data/herbcraft/knowledge_rumors.json` — rumor/claim data for Codex entries.
- `data/herbcraft/codex_loot_injections.json` — core Codex page loot injection rules.

### Alchemy

- `data/herbcraft_alchemy/essences.json` — essence definitions, source items, potion names, and base effects.
- `data/herbcraft_alchemy/potion_bonus_pools.json` — advanced potion bonus pools.
- `data/herbcraft_alchemy/special_potions.json` — T3/special/witch potion definitions and witch throw pool.
- `data/herbcraft_alchemy/coating_rules.json` — weapon coating rules.
- `data/herbcraft_alchemy/witch_loot.json` — witch alchemy page/essence/potion drops.
- `data/herbcraft_alchemy/codex_guides.json` — Alchemy-owned guide entry under 百草经总纲.
- `data/herbcraft_alchemy/guide_hints.json` — Alchemy-owned once-per-player onboarding hints.
- `data/herbcraft_alchemy/codex_loot_injections.json` — alchemy Codex page loot injection rules.

### Cuisine

- `data/herbcraft_cuisine/dishes.json` — fixed and medicinal dish definitions.
- `data/herbcraft_cuisine/hodgepodge_rules.json` — hodgepodge balancing rules.
- `data/herbcraft_cuisine/codex_guides.json` — Cuisine-owned guide entry under 百草经总纲.
- `data/herbcraft_cuisine/guide_hints.json` — Cuisine-owned once-per-player onboarding hints.
- `data/herbcraft_cuisine/codex_loot_injections.json` — cuisine Codex page loot injection rules.

## External extension paths

### P2: reloadable/server-data metadata extensions

The following paths are implemented for external datapacks or addon data resources:

```text
data/<namespace>/herbcraft/herb_natures/*.json
data/<namespace>/herbcraft/nutrition_profiles/*.json
data/<namespace>/herbcraft/special_counters/*.json
data/<namespace>/herbcraft/knowledge_rumors/*.json
data/<namespace>/herbcraft/codex_loot_injections/*.json
```

These are loaded by the server resource reload layer. They are intended for low-risk metadata and rules: nature, nutrition, overuse counters, Codex rumors, and Codex loot injections.

Example pack:

```text
docs/examples/external_extension_compat_pack/
```

Smoke report:

```text
docs/reports/P2_EXTERNAL_DATAPACK_SMOKE_20260615.md
```

### P3: startup-only external herb food definitions

The following path is implemented for loaded Fabric mod/addon resources:

```text
data/<namespace>/herbcraft/herbs/*.json
```

This path can make an existing registered item become a Herbcraft edible item by adding Herbcraft `FOOD` / `CONSUMABLE` default components at startup. Because this touches default item components, it is **startup-only** and is scanned from loaded Fabric mod containers during Herbcraft initialization.

It is **not** a world datapack `/reload` feature. A world datapack cannot safely make an arbitrary non-food item edible after item default components have already been applied.

Example addon layout:

```text
docs/examples/startup_herb_food_extension_mod/
```

Smoke report:

```text
docs/reports/P3_STARTUP_HERB_FOOD_SMOKE_20260615.md
```

Important P3 notes:

- Herbcraft JSON does not register brand-new Minecraft items. The item must already exist.
- If the external item should be accepted by tag-based systems such as hodgepodge ingredients, the addon should also provide the relevant item tags. P3 does not automatically edit tags.
- If the item should have Herbcraft nature/nutrition/rumor data, provide the P2 files as well.
- Optional `food_rolls` are supported at this startup-only path for probabilistic visible hunger or direct hidden saturation settlement.

## Adding an alchemy essence

Add an entry to:

```text
alchemy/src/main/resources/data/herbcraft_alchemy/essences.json
```

Example:

```json
{
  "id": "lavender",
  "source_items": ["examplemod:lavender"],
  "potion_name": "lavender",
  "effects": [
    { "effect": "minecraft:regeneration", "amplifier": 0, "duration_seconds": 20, "positive": true }
  ]
}
```

The Java registry can register extra essence definitions from JSON, but a polished entry still needs resources:

- `assets/herbcraft/items/essence_lavender.json`
- `assets/herbcraft/models/item/essence_lavender.json`
- `assets/herbcraft/textures/item/essence_lavender.png`
- `data/herbcraft/recipe/essence_lavender.json`
- language keys in `assets/herbcraft/lang/en_us.json` and `zh_cn.json`

Use:

```bash
python3 scripts/generate_essence_resources.py --check
python3 scripts/generate_essence_resources.py --write-missing
```

`--write-missing` creates skeleton files only for missing resources. Existing files are not overwritten unless `--overwrite-generated` is provided.

To check the current built-in essence resource coverage:

```bash
python3 scripts/generate_essence_resources.py --check
```

To check a standalone extension scaffold/resource directory:

```bash
python3 scripts/generate_essence_resources.py --check-extension /path/to/extension
```

To create a standalone example scaffold for one essence, including optional wandering trader trade and Codex rumor skeletons:

```bash
python3 scripts/generate_essence_resources.py \
  --scaffold-extension /tmp/herbcraft_lavender_example \
  --essence lavender \
  --source examplemod:lavender \
  --en-name "Lavender Essence" \
  --zh-name "薰衣草精华"
```

For multiple source items:

```bash
python3 scripts/generate_essence_resources.py \
  --scaffold-extension /tmp/herbcraft_tulip_example \
  --essence tulip_example \
  --sources examplemod:red_tulip,examplemod:white_tulip
```

To generate only the mandatory essence/item/model/texture/recipe/lang skeleton and skip optional trade/Codex skeletons:

```bash
python3 scripts/generate_essence_resources.py \
  --scaffold-extension /tmp/herbcraft_minimal_example \
  --essence mint \
  --source examplemod:mint \
  --no-trade \
  --no-codex
```

Review generated trades, Codex claim text keys, lang, and placeholder texture before release.

See:

```text
docs/examples/essence_extension_example/
```

## Adding nutrition profiles

For Herbcraft's built-in content, edit:

```text
data/herbcraft/nutrition_profiles.json
```

For external compatibility packs/addons, prefer:

```text
data/<namespace>/herbcraft/nutrition_profiles/*.json
```

Supported dimensions are still internally named:

- `grain`
- `flesh`
- `oil`
- `vege`
- `fruit`

The displayed name for `fruit` is now `津液` / `Fluids`, but the internal key remains `fruit` for compatibility.

Built-in file example:

```json
"examplemod:lavender_tea": {
  "fruit": 12,
  "vege": 6
}
```

External file example:

```json
{
  "schema_version": 1,
  "item": "examplemod:lavender_tea",
  "values": {
    "fruit": 12,
    "vege": 6
  }
}
```

## Adding raw edible herb data

For Herbcraft's built-in content, add entries to:

```text
data/herbcraft/herbs.json
```

For a loaded Fabric addon/mod that wants to make an existing item Herbcraft-edible at startup, add files under:

```text
data/<namespace>/herbcraft/herbs/*.json
```

You must provide:

- item ID
- stable `nutrition` / `saturation_modifier` / consume timing
- medicinal flag
- stack group flag
- effects/removals/flags as needed

You may also provide optional `food_rolls`:

```json
"food_rolls": {
  "nutrition": { "amount": 1, "chance": 0.35 },
  "saturation": { "amount": 0.3, "chance": 0.45 }
}
```

`food_rolls.nutrition.amount` adds direct visible hunger points and should be an integer. `food_rolls.saturation.amount` adds direct hidden saturation points, not a vanilla modifier. This is useful for raw forage that should sometimes help without becoming stable early food.

If the item should show nature information, also add either built-in or external nature data:

```text
data/herbcraft/herb_natures.json
data/<namespace>/herbcraft/herb_natures/*.json
```

If it should participate in rumors/Codex claims, add either built-in or external rumor data:

```text
data/herbcraft/knowledge_rumors.json
data/<namespace>/herbcraft/knowledge_rumors/*.json
```

If it should participate in tag-based systems, add the appropriate item tags separately. P3 startup herb food JSON does not automatically add item tags.

## Adding cuisine dishes

Add dish definitions to:

```text
data/herbcraft_cuisine/dishes.json
```

Cuisine raw/cooked assets and recipes are not automatically generated yet. Follow existing dish resource patterns.

## Adding Codex loot injections

Use the module-level files:

```text
data/herbcraft/codex_loot_injections.json
data/herbcraft_alchemy/codex_loot_injections.json
data/herbcraft_cuisine/codex_loot_injections.json
```

Each injection should include:

```json
{
  "loot_table": "minecraft:chests/village/village_temple",
  "chance": 0.18,
  "chapter": "alchemy",
  "entry": "",
  "page_kind": "common"
}
```

## What is not public data API yet

The following are not recommended extension points yet:

- network payload IDs
- data component IDs
- recipe serializer IDs
- item registry IDs for built-in items
- UI layout constants
- automatic villager trade generation for new dynamic essences
- automatic Codex prose generation for new dynamic essences

## Validators

Run at minimum:

```bash
python3 scripts/validate_externalized_rules.py
python3 scripts/validate_external_extension_spec.py
python3 scripts/validate_essence_resources.py
python3 scripts/check_lang_diff.py
```

For full release checks, use the validator list in `CURRENT_BASELINE.md`.
