#!/usr/bin/env python3
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(cond, msg):
    if not cond:
        errors.append(msg)

def load(rel):
    p = ROOT / rel
    require(p.exists(), f"missing {rel}")
    return json.load(open(p, encoding="utf-8")) if p.exists() else {}

special = load("core/src/main/resources/data/herbcraft/special_counters.json")
rules = { (entry.get("id"), tuple(entry.get("items", []))): entry for entry in special.get("counters", []) }
require(len(special.get("counters", [])) >= 5, "special counter rules should include poppy, torchflower, sugar, honey block, and slime")
require(("poppy", ("minecraft:poppy",)) in rules, "missing poppy special counter rule")
require(("torchflower", ("minecraft:torchflower",)) in rules, "missing torchflower special counter rule")
require(("sugar", ("minecraft:sugar",)) in rules, "missing sugar special counter rule")
require(("sugar", ("minecraft:honey_block",)) in rules, "missing honey block shared sugar counter rule")
require(("slime", ("minecraft:slime_ball",)) in rules, "missing slime special counter rule")
require(any(e.get("effect") == "minecraft:darkness" and e.get("min_count") == 3 for e in rules[("poppy", ("minecraft:poppy",))].get("threshold_effects", [])), "poppy rule should apply darkness at count 3")
require(any(e.get("effect") == "minecraft:fire_resistance" and e.get("min_count") == 3 for e in rules[("torchflower", ("minecraft:torchflower",))].get("threshold_effects", [])), "torchflower rule should apply fire resistance at count 3")
require(any(e.get("effect") == "minecraft:nausea" and e.get("min_count") == 4 and abs(e.get("chance", 0)-0.5)<1e-6 for e in rules[("sugar", ("minecraft:sugar",))].get("threshold_effects", [])), "sugar rule should apply 50% nausea at count 4")
require(any(e.get("effect") == "minecraft:nausea" and e.get("min_count") == 2 and abs(e.get("chance", 0)-0.5)<1e-6 for e in rules[("sugar", ("minecraft:honey_block",))].get("threshold_effects", [])), "honey block rule should apply 50% nausea at count 2")

special_java = (ROOT / "core/src/main/java/com/herbcraft/logic/SpecialCounters.java").read_text(encoding="utf-8")
herbcraft_java = (ROOT / "core/src/main/java/com/herbcraft/Herbcraft.java").read_text(encoding="utf-8")
require("special_counters.json" in special_java, "SpecialCounters should load special_counters.json")
require("MobEffects." not in special_java, "SpecialCounters should not hardcode MobEffects after externalization")
require("Items.POPPY" not in special_java and "Items.SUGAR" not in special_java and "Items.SLIME_BALL" not in special_java, "SpecialCounters should not hardcode item-specific rules")
require("SpecialCounters.loadFromBundledJson();" in herbcraft_java, "Herbcraft initializer must load special counter JSON")

hodge = load("cuisine/src/main/resources/data/herbcraft_cuisine/hodgepodge_rules.json")
require(hodge.get("min_herbs") == 3, "hodgepodge min_herbs should be 3")
require(hodge.get("normal_max_herbs") == 4, "hodgepodge normal_max_herbs should be 4")
require(hodge.get("max_herbs") == 7, "hodgepodge max_herbs should be 7")
require(hodge.get("nutrition_cap") == 10, "hodgepodge nutrition_cap should be 10")
require(abs(hodge.get("chance_bonus", 0)-0.15)<1e-6, "hodgepodge chance_bonus should be 0.15")
clash = hodge.get("clash", {})
require(abs(clash.get("base_chance", 0)-0.30)<1e-6, "hodgepodge clash base chance should be 0.30")
require(abs(clash.get("max_chance", 0)-0.80)<1e-6, "hodgepodge clash max chance should be 0.80")

hodge_item = (ROOT / "cuisine/src/main/java/com/herbcraft/cuisine/item/HodgepodgeItem.java").read_text(encoding="utf-8")
hodge_recipe = (ROOT / "cuisine/src/main/java/com/herbcraft/cuisine/recipe/HodgepodgeRecipe.java").read_text(encoding="utf-8")
cuisine_java = (ROOT / "cuisine/src/main/java/com/herbcraft/cuisine/HerbcraftCuisine.java").read_text(encoding="utf-8")
require("HodgepodgeRules.current()" in hodge_item, "HodgepodgeItem should read HodgepodgeRules")
require("HodgepodgeRules.current()" in hodge_recipe, "HodgepodgeRecipe should read HodgepodgeRules")
for token in ["CHANCE_BONUS", "CLASH_CHANCE", "CLASH_NAUSEA_SECONDS", "MAX_STACK_GAIN", "MIN_HERBS", "MAX_HERBS", "NUTRITION_CAP"]:
    require(token not in hodge_item and token not in hodge_recipe, f"hodgepodge hardcoded constant remains: {token}")
require("HodgepodgeRules.loadFromBundledJson();" in cuisine_java, "Cuisine initializer must load hodgepodge rules JSON")

essences = load("alchemy/src/main/resources/data/herbcraft_alchemy/essences.json")
require(len(essences.get("essences", [])) == 40, "essences.json should contain 40 current essence definitions")
ids = {entry.get("id") for entry in essences.get("essences", [])}
for required in ["dandelion", "golden_dandelion", "poppy", "tulip", "fern", "wither_rose", "crimson_fungus", "warped_fungus", "brown_mushroom"]:
    require(required in ids, f"essences.json missing expected essence {required}")
for entry in essences.get("essences", []):
    require(entry.get("source_items"), f"essence {entry.get('id')} missing source_items")
    require(entry.get("effects"), f"essence {entry.get('id')} missing effects")
    for effect in entry.get("effects", []):
        require("effect" in effect and "duration_seconds" in effect and "amplifier" in effect and "positive" in effect, f"essence {entry.get('id')} has malformed effect")
require(set(next(e for e in essences["essences"] if e["id"] == "tulip")["source_items"]) == {"minecraft:red_tulip", "minecraft:orange_tulip", "minecraft:white_tulip", "minecraft:pink_tulip"}, "tulip source variants should be data-driven")
require(set(next(e for e in essences["essences"] if e["id"] == "fern")["source_items"]) == {"minecraft:fern", "minecraft:large_fern"}, "fern source variants should be data-driven")

alchemy_registry = (ROOT / "alchemy/src/main/java/com/herbcraft/alchemy/registry/AlchemyRegistries.java").read_text(encoding="utf-8")
alchemy_usage = (ROOT / "alchemy/src/main/java/com/herbcraft/alchemy/knowledge/AlchemyUsageHints.java").read_text(encoding="utf-8")
require("data/herbcraft_alchemy/essences.json" in alchemy_registry, "AlchemyRegistries should load essences.json")
require(alchemy_registry.count("essenceFromJson(\"") == 40, "AlchemyRegistries should initialize current static essence fields through essenceFromJson")
require("public static final Item ESSENCE_" in alchemy_registry and "= essence(" not in "\n".join(line for line in alchemy_registry.splitlines() if "public static final Item ESSENCE_" in line), "static essence fields should not hardcode effect specs directly")
require("sourceItems()" in alchemy_usage and "VARIANT_SOURCES" not in alchemy_usage, "AlchemyUsageHints should use source_items from essences.json")

bonus = load("alchemy/src/main/resources/data/herbcraft_alchemy/potion_bonus_pools.json")
require(len(bonus.get("rules", [])) >= 10, "potion bonus pools should include harmful/beneficial matching rules and fallbacks")
require(any(r.get("kind") == "harmful" and r.get("fallback") for r in bonus.get("rules", [])), "potion bonus pools need a harmful fallback")
require(any(r.get("kind") == "beneficial" and r.get("fallback") for r in bonus.get("rules", [])), "potion bonus pools need a beneficial fallback")
require(any("minecraft:poison" in r.get("when_any", []) and "minecraft:wither" in r.get("when_any", []) for r in bonus.get("rules", [])), "potion bonus pools missing poison/wither harmful rule")
require(any("minecraft:regeneration" in r.get("when_any", []) and "minecraft:instant_health" in r.get("when_any", []) for r in bonus.get("rules", [])), "potion bonus pools missing healing beneficial rule")

bonus_java = (ROOT / "alchemy/src/main/java/com/herbcraft/alchemy/potion/AdvancedPotionStackInitializer.java").read_text(encoding="utf-8")
alchemy_init = (ROOT / "alchemy/src/main/java/com/herbcraft/alchemy/HerbcraftAlchemy.java").read_text(encoding="utf-8")
require("potion_bonus_pools.json" in bonus_java, "AdvancedPotionStackInitializer should load potion_bonus_pools.json")
require("BONUS_RULES" in bonus_java and "BonusRule" in bonus_java, "AdvancedPotionStackInitializer should use parsed bonus rules")
require("MobEffects." not in bonus_java, "AdvancedPotionStackInitializer bonus pool should not hardcode MobEffects after externalization")
require("loadBonusPoolsFromBundledJson" in alchemy_init, "Alchemy initializer must load potion bonus pool JSON")

special_potions = load("alchemy/src/main/resources/data/herbcraft_alchemy/special_potions.json")
sp_ids = {entry.get("id") for entry in special_potions.get("potions", [])}
for required in ["undead_venom", "cardiac_toxin", "wither_venom_iii", "witch_tulip_murky", "witch_azure_bluet_murky", "witch_pitcher_plant_murky", "witch_azalea_murky", "witch_closed_eyeblossom_murky"]:
    require(required in sp_ids, f"special_potions.json missing {required}")
require(len(special_potions.get("witch_throw_pool", [])) == 5, "witch_throw_pool should contain five safe witch potion entries")
require(sum(entry.get("weight", 0) for entry in special_potions.get("witch_throw_pool", [])) == 13, "witch_throw_pool weights should preserve previous total weight 13")
require("special_potions.json" in alchemy_registry, "AlchemyRegistries should load special_potions.json")
require("registerSpecialPotion(\"undead_venom\")" in alchemy_registry, "undead venom should be registered from special_potions.json")
require("registerSpecialPotion(\"cardiac_toxin\")" in alchemy_registry, "cardiac toxin should be registered from special_potions.json")
require("registerSpecialPotion(\"wither_venom_iii\")" in alchemy_registry, "wither venom III should be registered from special_potions.json")
require("pickWitchThrowPotion" in alchemy_registry and "WITCH_THROW_POOL" in alchemy_registry, "witch throw potion pool should be data-backed")
witch_mixin = (ROOT / "alchemy/src/main/java/com/herbcraft/alchemy/mixin/WitchHerbcraftPotionMixin.java").read_text(encoding="utf-8")
require("AlchemyRegistries.pickWitchThrowPotion" in witch_mixin and "nextInt(13)" not in witch_mixin, "witch mixin should use data-backed throw pool")
require("registerExtraEssencesFromJson" in alchemy_registry, "AlchemyRegistries should register extra JSON essences beyond compatibility static fields")

for rel in ["core/src/main/resources/data/herbcraft/codex_loot_injections.json", "alchemy/src/main/resources/data/herbcraft_alchemy/codex_loot_injections.json", "cuisine/src/main/resources/data/herbcraft_cuisine/codex_loot_injections.json"]:
    data = load(rel)
    require(data.get("page_injections"), f"{rel} should contain page_injections")
    for entry in data.get("page_injections", []):
        require("loot_table" in entry and "chance" in entry and "chapter" in entry and "page_kind" in entry, f"malformed codex loot entry in {rel}")
core_codex = (ROOT / "core/src/main/java/com/herbcraft/knowledge/CodexLoot.java").read_text(encoding="utf-8")
loot_rules_java = (ROOT / "core/src/main/java/com/herbcraft/knowledge/CodexLootRules.java").read_text(encoding="utf-8")
alchemy_codex = (ROOT / "alchemy/src/main/java/com/herbcraft/alchemy/knowledge/AlchemyCodexHooks.java").read_text(encoding="utf-8")
cuisine_codex = (ROOT / "cuisine/src/main/java/com/herbcraft/cuisine/knowledge/CuisineCodexHooks.java").read_text(encoding="utf-8")
require("codex_loot_injections.json" in core_codex and "CodexLootRules.load" in core_codex, "core CodexLoot should be JSON-backed")
require("CodexLootRules.load" in alchemy_codex and "ALCHEMY_TABLES" not in alchemy_codex, "alchemy Codex hooks should be JSON-backed")
require("CodexLootRules.load" in cuisine_codex and "CUISINE_TABLES" not in cuisine_codex, "cuisine Codex hooks should be JSON-backed")
require("ResourceKey.create(Registries.LOOT_TABLE" in loot_rules_java, "CodexLootRules should convert loot table IDs to ResourceKeys")

if errors:
    print("FAIL")
    for err in errors:
        print(" -", err)
    raise SystemExit(1)
print("PASS - counters, hodgepodge rules, codex loot injections, alchemy essences, special potions, witch pool, and potion bonus pools are externalized to JSON and loaded by Java runtime code.")
