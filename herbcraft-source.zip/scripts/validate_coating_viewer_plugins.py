#!/usr/bin/env python3
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
errs = []

def ok(cond, msg):
    print(("PASS - " if cond else "FAIL - ") + msg)
    if not cond:
        errs.append(msg)

jei = ROOT / "alchemy/src/main/java/com/herbcraft/alchemy/compat/jei/CoatingJeiPlugin.java"
rei = ROOT / "alchemy/src/main/java/com/herbcraft/alchemy/compat/rei/CoatingReiPlugin.java"
recipe = ROOT / "alchemy/src/main/java/com/herbcraft/alchemy/coating/CoatingSmithingRecipe.java"
build = ROOT / "build.gradle"
props = ROOT / "gradle.properties"
modjson = ROOT / "alchemy/src/main/resources/fabric.mod.json"

ok(jei.exists(), "JEI coating plugin source exists")
ok(rei.exists(), "REI coating plugin source exists")
ok(recipe.exists(), "coating smithing recipe source exists")
ok(build.exists(), "build.gradle exists")
ok(props.exists(), "gradle.properties exists")
ok(modjson.exists(), "alchemy fabric.mod.json exists")

jt = jei.read_text(encoding="utf-8") if jei.exists() else ""
rt = rei.read_text(encoding="utf-8") if rei.exists() else ""
ct = recipe.read_text(encoding="utf-8") if recipe.exists() else ""
bt = build.read_text(encoding="utf-8") if build.exists() else ""
pt = props.read_text(encoding="utf-8") if props.exists() else ""

ok("@JeiPlugin" in jt and "implements IModPlugin" in jt, "JEI plugin is discoverable by JEI annotation scanning")
ok("registerVanillaCategoryExtensions" in jt and "getSmithingCategory().addExtension" in jt, "JEI plugin registers a smithing category extension")
ok("registerRecipes" in jt and "RecipeTypes.SMITHING" in jt and "new CoatingSmithingRecipe" in jt, "JEI plugin explicitly adds coating recipes to smithing category")
ok("setTemplate" in jt and "setBase" in jt and "setAddition" in jt and "setOutput" in jt, "JEI smithing extension supplies all slots")
ok("CoatingItems.BLANK_ADHESIVE" in jt and "CoatingItems.AMETHYST_ADHESIVE" in jt and "CoatingItems.ECHO_ADHESIVE" in jt, "JEI plugin exposes coating adhesive inputs")
ok("AlchemyRegistries.essenceInfos()" in jt, "JEI plugin derives displays from data-backed essence registry")
ok("CoatingSystem.applyCoating" in jt, "JEI plugin creates real coated output stacks")

ok("implements REIClientPlugin" in rt, "REI client plugin implements REIClientPlugin")
ok("registerDisplays" in rt and "registry.add" in rt, "REI plugin explicitly registers displays")
ok("DefaultSmithingDisplay" in rt and "SmithingRecipeType.TRANSFORM" in rt, "REI plugin uses the built-in smithing display category")
ok("CoatingItems.BLANK_ADHESIVE" in rt and "CoatingItems.AMETHYST_ADHESIVE" in rt and "CoatingItems.ECHO_ADHESIVE" in rt, "REI plugin exposes coating adhesive inputs")
ok("AlchemyRegistries.essenceInfos()" in rt, "REI plugin derives displays from data-backed essence registry")
ok("CoatingSystem.applyCoating" in rt, "REI plugin creates real coated output stacks")
ok("BuiltInRegistries.ITEM" in rt and "CoatingSystem.COATABLE_WEAPONS" in rt, "REI plugin expands the coatable-weapons tag instead of showing only iron sword")
ok("coatableWeaponStacks()" in rt and "coatedWeaponStacks" in rt, "REI plugin supplies all coatable inputs and corresponding coated outputs")

mod = json.loads(modjson.read_text(encoding="utf-8")) if modjson.exists() else {}
entrypoints = mod.get("entrypoints", {})
ok("jei_mod_plugin" in entrypoints, "fabric.mod.json declares JEI mod-plugin entrypoint")
ok("com.herbcraft.alchemy.compat.jei.CoatingJeiPlugin" in entrypoints.get("jei_mod_plugin", []), "JEI entrypoint points to coating plugin")
ok("rei_client" in entrypoints, "fabric.mod.json declares REI client entrypoint")
ok("com.herbcraft.alchemy.compat.rei.CoatingReiPlugin" in entrypoints.get("rei_client", []), "REI entrypoint points to coating plugin")
ok("jei" not in mod.get("depends", {}), "JEI remains optional, not a hard dependency")
ok("roughlyenoughitems" not in mod.get("depends", {}), "REI remains optional, not a hard dependency")

ok("jei_version=" in pt and "rei_version=" in pt and "architectury_version=" in pt, "viewer API versions are pinned in gradle.properties")
ok("jei-${rootProject.minecraft_version}-common-api" in bt and "jei-${rootProject.minecraft_version}-fabric-api" in bt, "JEI compile-only APIs are configured")
ok("RoughlyEnoughItems-api-fabric" in bt and "RoughlyEnoughItems-default-plugin-fabric" in bt, "REI compile-only APIs are configured")
ok("architectury-fabric" in bt, "Architectury compile-only dependency is configured for REI API types")
ok("compileOnly" in bt and "implementation \"mezz.jei" not in bt and "implementation \"me.shedaniel:RoughlyEnoughItems" not in bt, "viewer APIs are compile-only and not bundled as hard runtime deps")

ok("public CoatingSmithingRecipe.RecipeMode recipeMode()" in ct, "coating recipe exposes mode for viewer plugins")
ok("public boolean isSpecial()" in ct and "return false;" in ct, "coating recipe remains non-special for viewer indexing")
ok("public List<RecipeDisplay> display()" in ct, "vanilla display fallback remains present")

if errs:
    print("Coating viewer plugin validation failed:")
    for err in errs:
        print("- " + err)
    sys.exit(1)
print("Coating viewer plugin validation passed.")
