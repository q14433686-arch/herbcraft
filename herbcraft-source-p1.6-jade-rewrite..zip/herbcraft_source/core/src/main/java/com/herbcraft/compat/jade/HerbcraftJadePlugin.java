package com.herbcraft.compat.jade;

import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.Block;
import snownee.jade.api.IWailaClientRegistration;
import snownee.jade.api.IWailaCommonRegistration;
import snownee.jade.api.IWailaPlugin;
import snownee.jade.api.WailaPlugin;

@WailaPlugin
public final class HerbcraftJadePlugin implements IWailaPlugin {
   public static final Identifier HERB_NATURE = Identifier.fromNamespaceAndPath("herbcraft", "herb_nature");
   public static final Identifier HERB_NATURE_ITEM_ENTITY = Identifier.fromNamespaceAndPath("herbcraft", "herb_nature_item_entity");

   @Override
   public void register(IWailaCommonRegistration registration) {
      registration.registerBlockDataProvider(HerbNatureProvider.INSTANCE, Block.class);
      registration.registerEntityDataProvider(HerbNatureEntityProvider.INSTANCE, ItemEntity.class);
   }

   @Override
   public void registerClient(IWailaClientRegistration registration) {
      registration.addConfig(HERB_NATURE, true);
      registration.addConfig(HERB_NATURE_ITEM_ENTITY, true);
      registration.registerBlockComponent(HerbNatureProvider.INSTANCE, Block.class);
      registration.registerEntityComponent(HerbNatureEntityProvider.INSTANCE, ItemEntity.class);
   }
}
