package com.herbcraft.compat.jade;

import com.herbcraft.api.HerbNatureAPI;
import com.herbcraft.api.HerbUsageAPI;
import com.herbcraft.api.HerbcraftAPI;
import com.herbcraft.api.KnowledgeAPI;
import com.herbcraft.nature.NatureProfile;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import snownee.jade.api.ITooltip;

final class HerbJadeData {
   static final String IS_HERB = "herbcraft:is_herb";
   static final String KNOWLEDGE_STATE = "herbcraft:knowledge_state";
   static final String TEMPERATURE = "herbcraft:nature_temperature";
   static final String FLAVORS = "herbcraft:nature_flavors";
   static final String USAGES = "herbcraft:usages";

   private HerbJadeData() {
   }

   static boolean isHerb(Item item) {
      return item != null && HerbcraftAPI.getHerbRegistry().containsKey(item);
   }

   static void write(CompoundTag data, ServerPlayer player, Item item) {
      if (!isHerb(item)) {
         return;
      }
      data.putBoolean(IS_HERB, true);
      data.putInt(KNOWLEDGE_STATE, knowledgeState(player, item));
      NatureProfile nature = HerbNatureAPI.getNatureOrFallback(new ItemStack(item));
      data.putString(TEMPERATURE, nature.temperature());
      data.putString(FLAVORS, String.join(",", nature.flavors()));
      java.util.List<String> usages = HerbUsageAPI.usageKeys(item);
      if (!usages.isEmpty()) {
         data.putString(USAGES, String.join(",", usages));
      }
   }

   static void appendTooltip(ITooltip tooltip, CompoundTag data, boolean localHerb) {
      boolean serverHerb = data.getBooleanOr(IS_HERB, false);
      if (!serverHerb && !localHerb) {
         return;
      }
      tooltip.add(Component.translatable("jade.herbcraft.title").withStyle(ChatFormatting.GREEN));
      int state = data.getIntOr(KNOWLEDGE_STATE, 0);
      if (state <= 0) {
         tooltip.add(Component.translatable("jade.herbcraft.unknown").withStyle(ChatFormatting.GRAY));
         return;
      }
      tooltip.add(Component.translatable(state >= 2 ? "jade.herbcraft.mastered" : "jade.herbcraft.heard").withStyle(ChatFormatting.YELLOW));
      NatureProfile nature = new NatureProfile(data.getStringOr(TEMPERATURE, "neutral"), java.util.List.of(data.getStringOr(FLAVORS, "bland").split(",")), java.util.List.of());
      tooltip.add(HerbNatureAPI.natureLine(nature).withStyle(ChatFormatting.AQUA));
      if (state >= 2) {
         String usages = data.getStringOr(USAGES, "");
         if (!usages.isEmpty()) {
            tooltip.add(HerbUsageAPI.usageLine(java.util.List.of(usages.split(","))).withStyle(ChatFormatting.DARK_GRAY));
         } else {
            tooltip.add(Component.translatable("jade.herbcraft.usage.basic").withStyle(ChatFormatting.DARK_GRAY));
         }
      }
   }

   private static int knowledgeState(ServerPlayer player, Item item) {
      Identifier id = BuiltInRegistries.ITEM.getKey(item);
      if (id == null) {
         return 0;
      }
      String entryId = id.getPath();
      if (player.getStats().getValue(Stats.ITEM_USED.get(item)) > 0) {
         return KnowledgeAPI.State.MASTERED.ordinal();
      }
      Integer stored = KnowledgeAPI.knowledge(player).get("herbal/" + entryId);
      if (stored != null) {
         return Math.max(0, Math.min(stored, KnowledgeAPI.State.MASTERED.ordinal()));
      }
      KnowledgeAPI.Entry entry = KnowledgeAPI.chapter("herbal").map(chapter -> chapter.entry(entryId)).orElse(null);
      if (entry == null) {
         return 0;
      }
      return KnowledgeAPI.state(player, "herbal", entry).ordinal();
   }
}
