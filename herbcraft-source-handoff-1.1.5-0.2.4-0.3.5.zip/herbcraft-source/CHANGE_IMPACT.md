# CHANGE_IMPACT

This checklist must be used whenever `data/herbcraft/herbs.json` is modified.

## herbs.json manual impact checklist

For every changed herb entry, manually verify:

- [ ] **Raw eating effects**
  - Nutrition and saturation still make sense.
  - Positive/negative flags match the actual effect.
  - Chance, duration and amplifier are sane.
  - Special flags such as `drink`, `extinguish`, `clearPositiveEffects`, `bucketRemainder`, `shortUseProjectile` still behave correctly.

- [ ] **Herb stack / overload behavior**
  - `stack_group` changes do not make overload too common or impossible.
  - Hodgepodge stack gain remains capped at +3 per bowl.

- [ ] **Essence and potion linkage**
  - Alchemy `AlchemyRegistries` effect values still match the intended herb identity.
  - Ordinary potion stabilization remains valid.
  - Clarified/murky variants remain meaningful.
  - High-tier quality multipliers do not exceed the 480s cap unexpectedly.

- [ ] **Tooltip and Codex linkage**
  - Essence tooltips still describe the right effects.
  - Herb Codex lines still match raw herb behavior.
  - Unknown entries still show `???` and do not leak hidden names.
  - Long new text still wraps in `CodexScreen`.

- [ ] **Hodgepodge / 百草盅**
  - The item is present in `#herbcraft:herb` if it should be usable in hodgepodge.
  - The item is absent from `#herbcraft:herb` if it should not be usable.
  - `HodgepodgeRecipe` still accepts bowl + 3/4 valid herbs and rejects invalid inputs.
  - Hodgepodge dynamic effects, clears, heal/damage events and clash nausea still make sense.

- [ ] **Cuisine recipes**
  - Curated dish ingredient lists in `data/herbcraft_cuisine/dishes.json` still match recipe JSONs.
  - Curated dish combinations remain excluded from hodgepodge if intended.
  - Raw/cooked dish effects remain aligned with changed herb values.

- [ ] **Villager trade prices and predicates**
  - Trades that buy/sell herbs, essences or potions are still priced appropriately.
  - Potion-buy trades still use `minecraft:potion_contents.potion` and not exact randomized high-tier components.
  - Trade tags still reference every custom trade with `replace=false`.

- [ ] **Weapon coating values**
  - Coating hit effects, durations and use counts still make sense for changed herb effect strength.
  - Weaponsmith coated-weapon trades still carry valid `herbcraft:weapon_coating` components.

- [ ] **Consume sounds**
  - `ConsumeSoundResolver` category mapping still fits the item path/category.
  - New herb-like items do not all fall back to generic food if a better category exists.

## Recommended commands after edits

```bash
./gradlew clean build
python3 scripts/check_lang_diff.py
python3 scripts/validate_trade_tags.py
python3 scripts/validate_panel_hodge_recipe.py
python3 scripts/validate_bugfix_advanced_potion_trade.py
```
