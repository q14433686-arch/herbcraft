package com.herbcraft.effect;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

/** Herbcraft nutrition status effect with optional periodic exhaustion feedback. */
public class NutritionMobEffect extends SimpleHerbcraftMobEffect {
   private final int exhaustionIntervalTicks;
   private final float exhaustionAmount;

   public NutritionMobEffect(MobEffectCategory category, int color) {
      this(category, color, 0, 0.0F);
   }

   public NutritionMobEffect(MobEffectCategory category, int color, int exhaustionIntervalTicks, float exhaustionAmount) {
      super(category, color);
      this.exhaustionIntervalTicks = Math.max(0, exhaustionIntervalTicks);
      this.exhaustionAmount = Math.max(0.0F, exhaustionAmount);
   }

   @Override
   public boolean shouldApplyEffectTickThisTick(int durationTicks, int amplifier) {
      return this.exhaustionIntervalTicks > 0 && durationTicks % this.exhaustionIntervalTicks == 0;
   }

   @Override
   public boolean applyEffectTick(ServerLevel level, LivingEntity entity, int amplifier) {
      if (this.exhaustionAmount > 0.0F && entity instanceof ServerPlayer player) {
         player.causeFoodExhaustion(this.exhaustionAmount * (amplifier + 1));
      }
      return true;
   }
}
