package com.herbcraft;

public interface HerbcraftPlayerData {
	int herbcraft$getHerbStack(long gameTime);
	int herbcraft$addHerbStack(long gameTime);
	void herbcraft$clearHerbStack();
	int herbcraft$incrementWindowCounter(String counter, long gameTime, int windowTicks);
}
