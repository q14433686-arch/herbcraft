package com.herbcraft.nutrition;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.herbcraft.Herbcraft;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class NutritionRules {
   private static NutritionRules INSTANCE = defaults();

   public final int maxValue;
   public final int initialValue;
   public final int decayIntervalTicks;
   public final int decayAmount;
   public final int checkIntervalTicks;
   public final int balancedMin;
   public final int balancedMax;
   public final int balancedSpread;
   public final int malnutritionLow;
   public final int imbalanceHigh;
   public final int imbalanceSpread;
   public final int badStateGraceChecks;
   public final int warningCooldownTicks;
   public final float minorDebuffChance;
   public final int minorDebuffDurationTicks;
   public final int abundanceThreshold;
   public final int fullBalanceMin;
   public final int fullBalanceMax;

   private NutritionRules(int maxValue, int initialValue, int decayIntervalTicks, int decayAmount,
                           int checkIntervalTicks, int balancedMin, int balancedMax, int balancedSpread,
                           int malnutritionLow, int imbalanceHigh, int imbalanceSpread,
                           int badStateGraceChecks, int warningCooldownTicks,
                           float minorDebuffChance, int minorDebuffDurationTicks,
                           int abundanceThreshold, int fullBalanceMin, int fullBalanceMax) {
      this.maxValue = maxValue;
      this.initialValue = initialValue;
      this.decayIntervalTicks = decayIntervalTicks;
      this.decayAmount = decayAmount;
      this.checkIntervalTicks = checkIntervalTicks;
      this.balancedMin = balancedMin;
      this.balancedMax = balancedMax;
      this.balancedSpread = balancedSpread;
      this.malnutritionLow = malnutritionLow;
      this.imbalanceHigh = imbalanceHigh;
      this.imbalanceSpread = imbalanceSpread;
      this.badStateGraceChecks = badStateGraceChecks;
      this.warningCooldownTicks = warningCooldownTicks;
      this.minorDebuffChance = minorDebuffChance;
      this.minorDebuffDurationTicks = minorDebuffDurationTicks;
      this.abundanceThreshold = abundanceThreshold;
      this.fullBalanceMin = fullBalanceMin;
      this.fullBalanceMax = fullBalanceMax;
   }

   public static NutritionRules current() { return INSTANCE; }

   public static void loadFromBundledJson() {
      INSTANCE = defaults();
      try (InputStream in = NutritionRules.class.getClassLoader()
               .getResourceAsStream("data/herbcraft/nutrition_rules.json")) {
         if (in == null) return;
         JsonObject r = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
         INSTANCE = new NutritionRules(
            i(r,"max_value",1000), i(r,"initial_value",500),
            i(r,"decay_interval_ticks",1200), i(r,"decay_amount",2),
            i(r,"check_interval_ticks",1200), i(r,"balanced_min",350), i(r,"balanced_max",650),
            i(r,"balanced_spread",300), i(r,"malnutrition_low",150),
            i(r,"imbalance_high",850), i(r,"imbalance_spread",550),
            i(r,"bad_state_grace_checks",3), i(r,"warning_cooldown_ticks",6000),
            f(r,"minor_debuff_chance",0.12F), i(r,"minor_debuff_duration_ticks",100),
            i(r,"abundance_threshold",750), i(r,"full_balance_min",400), i(r,"full_balance_max",600)
         );
      } catch (Exception e) {
         Herbcraft.LOGGER.warn("Failed to load nutrition_rules.json; using defaults", e);
      }
   }

   private static NutritionRules defaults() {
      return new NutritionRules(1000,500,1200,2,1200,350,650,300,150,850,550,3,6000,0.12F,100,750,400,600);
   }

   private static int i(JsonObject r, String k, int fb) { return r.has(k) ? r.get(k).getAsInt() : fb; }
   private static float f(JsonObject r, String k, float fb) { return r.has(k) ? r.get(k).getAsFloat() : fb; }
}
