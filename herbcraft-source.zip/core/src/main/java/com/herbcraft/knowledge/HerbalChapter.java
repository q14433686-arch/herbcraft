package com.herbcraft.knowledge;

import com.herbcraft.HerbcraftPlayerData;
import com.herbcraft.api.HerbDefinition;
import com.herbcraft.api.HerbEffectEntry;
import com.herbcraft.api.HerbNatureAPI;
import com.herbcraft.api.HerbUsageAPI;
import com.herbcraft.api.HerbcraftAPI;
import com.herbcraft.api.KnowledgeDisplayState;
import com.herbcraft.api.KnowledgeFlags;
import com.herbcraft.api.PlayerClaimMark;
import com.herbcraft.nature.HerbNatureRegistry;
import com.herbcraft.nature.NatureProfile;
import com.herbcraft.nutrition.NutritionRegistry;
import com.herbcraft.pharmacology.PlayerPharmacologyState;
import com.herbcraft.api.KnowledgeAPI;
import com.herbcraft.registry.HerbFoodRegistry;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class HerbalChapter {
   public static final String CHAPTER_ID = "herbal";
   private static final String FOOD_NATURE_SECTION = "foods";
   private static final Set<String> FOOD_NATURE_ENTRY_IDS = new LinkedHashSet<>();

   private HerbalChapter() {
   }

   public static void register() {
      KnowledgeAPI.registerChapter("herbal", Component.translatable("book.herbcraft.chapter.herbal"), 0);
      KnowledgeAPI.registerSection("herbal", "overview", Component.translatable("book.herbcraft.section.herbal.overview"));
      KnowledgeAPI.registerEntry(
         "herbal",
         new KnowledgeAPI.Entry(
            "overview",
            "overview",
            Component.translatable("book.herbcraft.entry.overview.title"),
            (player, state) -> overviewLines(),
            player -> true,
            player -> true
         )
      );

      registerCoreGuideProviders();
      CodexGuideRegistry.loadFromBundledJson("data/herbcraft/codex_guides.json");

      for (String section : List.of("flowers", "foliage", "sea", "nether", "ice", "curios")) {
         KnowledgeAPI.registerSection("herbal", section, Component.translatable("book.herbcraft.section.herbal." + section));
      }

      HerbcraftAPI.getHerbRegistry()
         .forEach(
            (item, definition) -> {
               String entryId = BuiltInRegistries.ITEM.getKey(item).getPath();
               KnowledgeAPI.registerEntry(
                  "herbal",
                  new KnowledgeAPI.Entry(
                     entryId,
                     classify(entryId),
                     Component.translatable(item.getDescriptionId()),
                     (player, state) -> lines(player, entryId, definition),
                     null,
                     null
                  )
               );
            }
         );
   }

   public static void applyFoodNatureEntries() {
      clearFoodNatureEntries();
      List<FoodNatureCandidate> candidates = new ArrayList<>();
      for (Identifier itemId : HerbNatureRegistry.profiles().keySet()) {
         if (!BuiltInRegistries.ITEM.containsKey(itemId) || NutritionRegistry.get(itemId).isEmpty() || !IngredientsChapter.hasEntry(itemId)) {
            continue;
         }
         Item item = BuiltInRegistries.ITEM.getValue(itemId);
         if (HerbFoodRegistry.get(item) != null) {
            continue;
         }
         candidates.add(new FoodNatureCandidate(itemId, item, foodNatureEntryId(itemId)));
      }
      if (candidates.isEmpty()) {
         return;
      }
      KnowledgeAPI.registerSection(CHAPTER_ID, FOOD_NATURE_SECTION, Component.translatable("book.herbcraft.section.herbal.foods"));
      for (FoodNatureCandidate candidate : candidates) {
         KnowledgeAPI.registerEntry(
            CHAPTER_ID,
            new KnowledgeAPI.Entry(
               candidate.entryId(),
               FOOD_NATURE_SECTION,
               Component.translatable(candidate.item().getDescriptionId()),
               (player, state) -> foodNatureLines(player, candidate.item(), candidate.entryId()),
               null,
               null
            )
         );
         FOOD_NATURE_ENTRY_IDS.add(candidate.entryId());
      }
      com.herbcraft.Herbcraft.LOGGER.info("Loaded {} food-nature entries into the Herbal Codex", candidates.size());
   }

   private static void clearFoodNatureEntries() {
      for (String entryId : FOOD_NATURE_ENTRY_IDS) {
         KnowledgeAPI.removeEntry(CHAPTER_ID, entryId);
      }
      FOOD_NATURE_ENTRY_IDS.clear();
      KnowledgeAPI.removeSectionIfEmpty(CHAPTER_ID, FOOD_NATURE_SECTION);
   }

   public static String foodNatureEntryId(Identifier itemId) {
      if ("minecraft".equals(itemId.getNamespace())) {
         return itemId.getPath();
      }
      return itemId.getNamespace() + "__" + itemId.getPath().replace('/', '_');
   }

   public static boolean hasFoodNatureEntry(Identifier itemId) {
      return KnowledgeAPI.chapter(CHAPTER_ID).map(chapter -> chapter.entry(foodNatureEntryId(itemId)) != null).orElse(false);
   }

   public static boolean hasEaten(ServerPlayer player, Item item) {
      return player.getStats().getValue(Stats.ITEM_USED.get(item)) > 0;
   }

   private static String classify(String path) {
      if (path.contains("crimson") || path.contains("warped") || path.contains("nether") || path.contains("weeping") || path.contains("twisting")) {
         return "nether";
      } else if (path.contains("snow") || path.contains("ice")) {
         return "ice";
      } else if (path.contains("kelp") || path.contains("seagrass") || path.contains("sea_pickle") || path.contains("lily_pad")) {
         return "sea";
      } else if (!path.contains("leaves")
         && !path.contains("sapling")
         && !path.contains("propagule")
         && !path.contains("fern")
         && !path.contains("grass")
         && !path.contains("vine")
         && !path.contains("bamboo")
         && !path.contains("sugar_cane")
         && !path.contains("cocoa")
         && !path.contains("seeds")
         && !path.contains("moss")
         && !path.contains("mushroom")
         && !path.contains("fungus")) {
         return !path.contains("dandelion")
               && !path.contains("poppy")
               && !path.contains("orchid")
               && !path.contains("bluet")
               && !path.contains("daisy")
               && !path.contains("cornflower")
               && !path.contains("lily_of_the_valley")
               && !path.contains("wither_rose")
               && !path.contains("sunflower")
               && !path.contains("lilac")
               && !path.contains("rose_bush")
               && !path.contains("peony")
               && !path.contains("pitcher")
               && !path.contains("torchflower")
               && !path.contains("eyeblossom")
               && !path.contains("allium")
               && !path.contains("azalea")
               && !path.contains("tulip")
               && !path.contains("petals")
               && !path.contains("spore_blossom")
               && !path.contains("cactus_flower")
               && !path.contains("flower")
            ? "curios"
            : "flowers";
      } else {
         return "foliage";
      }
   }

   private static Identifier id(String path) {
      return Identifier.fromNamespaceAndPath("herbcraft", path);
   }

   private static void registerCoreGuideProviders() {
      CodexGuideRegistry.registerProvider(id("recognizing"), player -> guideLines(player, "recognizing"));
      CodexGuideRegistry.registerProvider(id("knowledge_states"), player -> guideLines(player, "knowledge_states"));
      CodexGuideRegistry.registerProvider(id("flavors"), player -> guideLines(player, "flavors"));
      CodexGuideRegistry.registerProvider(id("seven_emotions"), player -> guideLines(player, "seven_emotions"));
      CodexGuideRegistry.registerProvider(id("herb_stack"), player -> guideLines(player, "herb_stack"));
      CodexGuideRegistry.registerProvider(id("ingredients"), player -> guideLines(player, "ingredients"));
      CodexGuideRegistry.registerProvider(id("errata"), player -> guideLines(player, "errata"));
   }

   private static List<Component> guideLines(ServerPlayer player, String guide) {
      List<Component> lines = new ArrayList<>();
      switch (guide) {
         case "recognizing" -> {
            add(lines, "book.herbcraft.guide.recognizing.line1", ChatFormatting.GRAY);
            add(lines, "book.herbcraft.guide.recognizing.line2", ChatFormatting.DARK_GRAY);
            HerbKnowledgeStats stats = herbStats(player);
            if (stats.tasted() > 0) {
               lines.add(Component.translatable("book.herbcraft.guide.recognizing.tasted_count", stats.tasted()).withStyle(ChatFormatting.DARK_AQUA));
            } else {
               add(lines, "book.herbcraft.guide.recognizing.none", ChatFormatting.DARK_GRAY);
            }
         }
         case "knowledge_states" -> {
            add(lines, "book.herbcraft.guide.knowledge_states.line1", ChatFormatting.GRAY);
            add(lines, "book.herbcraft.guide.knowledge_states.line2", ChatFormatting.GRAY);
            HerbKnowledgeStats stats = herbStats(player);
            if (stats.heard() > 0 || stats.tasted() > 0 || stats.mastered() > 0) {
               lines.add(Component.translatable("book.herbcraft.guide.knowledge_states.progress", stats.heard(), stats.tasted(), stats.mastered()).withStyle(ChatFormatting.DARK_AQUA));
            } else {
               add(lines, "book.herbcraft.guide.knowledge_states.none", ChatFormatting.DARK_GRAY);
            }
         }
         case "flavors" -> {
            add(lines, "book.herbcraft.guide.flavors.line1", ChatFormatting.GRAY);
            add(lines, "book.herbcraft.guide.flavors.line2", ChatFormatting.GRAY);
            TastedHerb first = firstTastedHerb(player);
            if (first == null) {
               add(lines, "book.herbcraft.guide.flavors.none", ChatFormatting.DARK_GRAY);
            } else {
               add(lines, "book.herbcraft.guide.flavors.tasted_once", ChatFormatting.DARK_AQUA);
               int flavorCount = discoveredFlavorCount(player);
               if (flavorCount >= 3) {
                  lines.add(Component.translatable("book.herbcraft.guide.flavors.many", flavorCount).withStyle(ChatFormatting.GRAY));
               }
               addFlavorPrinciples(player, lines);
            }
         }
         case "seven_emotions" -> {
            add(lines, "book.herbcraft.guide.seven_emotions.line1", ChatFormatting.GRAY);
            add(lines, "book.herbcraft.guide.seven_emotions.line2", ChatFormatting.GRAY);
            HerbKnowledgeStats stats = herbStats(player);
            if (stats.tasted() >= 2) {
               lines.add(Component.translatable("book.herbcraft.guide.seven_emotions.tasted", stats.tasted()).withStyle(ChatFormatting.DARK_AQUA));
               addSevenEmotionPrinciples(player, lines);
            } else {
               add(lines, "book.herbcraft.guide.seven_emotions.none", ChatFormatting.DARK_GRAY);
            }
         }
         case "herb_stack" -> {
            add(lines, "book.herbcraft.guide.herb_stack.line1", ChatFormatting.GRAY);
            if (advancementDone(player, "herbcraft", "herb_stack_3")) add(lines, "book.herbcraft.guide.herb_stack.stage3", ChatFormatting.DARK_AQUA);
            if (advancementDone(player, "herbcraft", "herb_stack_5")) add(lines, "book.herbcraft.guide.herb_stack.stage5", ChatFormatting.DARK_AQUA);
            if (advancementDone(player, "herbcraft", "herb_stack_8")) add(lines, "book.herbcraft.guide.herb_stack.stage8", ChatFormatting.GOLD);
            if (advancementDone(player, "herbcraft", "herb_overload")) add(lines, "book.herbcraft.guide.herb_stack.overload", ChatFormatting.RED);
            if (!advancementDone(player, "herbcraft", "herb_stack_3")) add(lines, "book.herbcraft.guide.herb_stack.none", ChatFormatting.DARK_GRAY);
         }
         case "ingredients" -> {
            add(lines, "book.herbcraft.guide.ingredients.line1", ChatFormatting.GRAY);
            int tasted = tastedIngredientCount(player);
            if (tasted > 0) {
               lines.add(Component.translatable("book.herbcraft.guide.ingredients.tasted", tasted).withStyle(ChatFormatting.DARK_AQUA));
            } else {
               add(lines, "book.herbcraft.guide.ingredients.none", ChatFormatting.DARK_GRAY);
            }
         }
         case "errata" -> {
            add(lines, "book.herbcraft.guide.errata.line1", ChatFormatting.GRAY);
            HerbKnowledgeStats stats = herbStats(player);
            if (stats.heard() > 0) add(lines, "book.herbcraft.guide.errata.heard", ChatFormatting.DARK_AQUA);
            int verified = verifiedHerbalClaimCount(player);
            if (verified > 0) lines.add(Component.translatable("book.herbcraft.guide.errata.verified", verified).withStyle(ChatFormatting.GREEN));
            if (stats.heard() == 0) add(lines, "book.herbcraft.guide.errata.none", ChatFormatting.DARK_GRAY);
         }
         default -> add(lines, "book.herbcraft.guide.generic", ChatFormatting.GRAY);
      }
      return lines;
   }

   private static void add(List<Component> lines, String key, ChatFormatting style) {
      lines.add(Component.translatable(key).withStyle(style));
   }

   private static void addFlavorPrinciples(ServerPlayer player, List<Component> lines) {
      addIfDiscovered(player, lines, "flavor_sweet", "book.herbcraft.guide.flavors.sweet", ChatFormatting.GRAY);
      addIfDiscovered(player, lines, "flavor_bitter", "book.herbcraft.guide.flavors.bitter", ChatFormatting.GRAY);
      addIfDiscovered(player, lines, "flavor_pungent", "book.herbcraft.guide.flavors.pungent", ChatFormatting.GRAY);
      addIfDiscovered(player, lines, "flavor_sour", "book.herbcraft.guide.flavors.sour", ChatFormatting.GRAY);
      addIfDiscovered(player, lines, "flavor_astringent", "book.herbcraft.guide.flavors.astringent", ChatFormatting.GRAY);
      addIfDiscovered(player, lines, "flavor_salty", "book.herbcraft.guide.flavors.salty", ChatFormatting.GRAY);
      addIfDiscovered(player, lines, "flavor_salty_water", "book.herbcraft.guide.flavors.salty_water", ChatFormatting.GRAY);
      addIfDiscovered(player, lines, "flavor_bland", "book.herbcraft.guide.flavors.bland", ChatFormatting.GRAY);
      addIfDiscovered(player, lines, "temperature_harmonize", "book.herbcraft.guide.flavors.temperature_harmonize", ChatFormatting.DARK_AQUA);
      addIfDiscovered(player, lines, "temperature_same_hot", "book.herbcraft.guide.flavors.temperature_same_hot", ChatFormatting.GOLD);
      addIfDiscovered(player, lines, "temperature_same_cold", "book.herbcraft.guide.flavors.temperature_same_cold", ChatFormatting.BLUE);
   }

   private static void addSevenEmotionPrinciples(ServerPlayer player, List<Component> lines) {
      addRelationIfDiscovered(player, lines, "seven_xiang_xu", "book.herbcraft.guide.seven.xiang_xu", ChatFormatting.DARK_AQUA);
      addRelationIfDiscovered(player, lines, "seven_xiang_shi", "book.herbcraft.guide.seven.xiang_shi", ChatFormatting.DARK_AQUA);
      addRelationIfDiscovered(player, lines, "seven_xiang_sha", "book.herbcraft.guide.seven.xiang_sha", ChatFormatting.GREEN);
      addRelationIfDiscovered(player, lines, "seven_xiang_wei", "book.herbcraft.guide.seven.xiang_wei", ChatFormatting.GREEN);
      addRelationIfDiscovered(player, lines, "seven_xiang_e", "book.herbcraft.guide.seven.xiang_e", ChatFormatting.GOLD);
      addRelationIfDiscovered(player, lines, "seven_xiang_fan", "book.herbcraft.guide.seven.xiang_fan", ChatFormatting.RED);
      addSingleIfDiscovered(player, lines);
   }

   private static void addSingleIfDiscovered(ServerPlayer player, List<Component> lines) {
      discovery(player, "seven_single").ifPresent(discovery -> {
         Component current = itemName(discovery.currentItemId());
         lines.add(Component.translatable("book.herbcraft.guide.seven.single", current).withStyle(ChatFormatting.DARK_GRAY));
         if (discovery.count() > 1) {
            lines.add(Component.translatable("book.herbcraft.guide.seven.count", discovery.count()).withStyle(ChatFormatting.DARK_GRAY));
         }
      });
   }

   private static void addIfDiscovered(ServerPlayer player, List<Component> lines, String discoveryKey, String langKey, ChatFormatting style) {
      if (discovery(player, discoveryKey).isPresent()) {
         lines.add(Component.translatable(langKey).withStyle(style));
      }
   }

   private static void addRelationIfDiscovered(ServerPlayer player, List<Component> lines, String discoveryKey, String langKey, ChatFormatting style) {
      discovery(player, discoveryKey).ifPresent(discovery -> {
         Component previous = itemName(discovery.previousItemId());
         Component current = itemName(discovery.currentItemId());
         lines.add(Component.translatable(langKey, previous, current).withStyle(style));
         if (discovery.count() > 1) {
            lines.add(Component.translatable("book.herbcraft.guide.seven.count", discovery.count()).withStyle(ChatFormatting.DARK_GRAY));
         }
      });
   }

   private static java.util.Optional<PlayerPharmacologyState.PrincipleDiscovery> discovery(ServerPlayer player, String key) {
      return ((HerbcraftPlayerData)player).herbcraft$pharmacologyState().discovery(key);
   }

   private static Component itemName(String itemId) {
      if (itemId == null || itemId.isBlank()) {
         return Component.translatable("book.herbcraft.guide.unknown_item");
      }
      Identifier id = Identifier.tryParse(itemId);
      if (id == null) {
         return Component.literal(itemId);
      }
      if (!BuiltInRegistries.ITEM.containsKey(id)) {
         return Component.literal(itemId);
      }
      Item item = BuiltInRegistries.ITEM.getValue(id);
      return Component.translatable(item.getDescriptionId());
   }

   private static HerbKnowledgeStats herbStats(ServerPlayer player) {
      int encountered = 0, heard = 0, tasted = 0, mastered = 0;
      Set<String> counted = new LinkedHashSet<>();
      for (Item item : HerbcraftAPI.getHerbRegistry().keySet()) {
         net.minecraft.resources.Identifier id = BuiltInRegistries.ITEM.getKey(item);
         if (id == null) continue;
         String entryId = id.getPath();
         String key = KnowledgeAPI.key(CHAPTER_ID, entryId);
         counted.add(entryId);
         KnowledgeFlags flags = KnowledgeAPI.flags(player, key);
         if (flags.encountered()) encountered++;
         if (flags.heard()) heard++;
         if (flags.tasted()) tasted++;
         if (KnowledgeAPI.isMastered(player, key, flags)) mastered++;
      }
      for (Identifier id : foodNatureItemIds()) {
         String entryId = foodNatureEntryId(id);
         if (!counted.add(entryId)) continue;
         String key = KnowledgeAPI.key(CHAPTER_ID, entryId);
         KnowledgeFlags flags = KnowledgeAPI.flags(player, key);
         if (flags.encountered()) encountered++;
         if (flags.heard()) heard++;
         if (flags.tasted()) tasted++;
         if (KnowledgeAPI.isMastered(player, key, flags)) mastered++;
      }
      return new HerbKnowledgeStats(encountered, heard, tasted, mastered);
   }

   private static TastedHerb firstTastedHerb(ServerPlayer player) {
      for (Item item : HerbcraftAPI.getHerbRegistry().keySet()) {
         net.minecraft.resources.Identifier id = BuiltInRegistries.ITEM.getKey(item);
         if (id == null) continue;
         if (KnowledgeAPI.flags(player, KnowledgeAPI.key(CHAPTER_ID, id.getPath())).tasted()) {
            return new TastedHerb(item, HerbNatureAPI.getNatureOrFallback(new ItemStack(item)));
         }
      }
      for (Identifier id : foodNatureItemIds()) {
         if (KnowledgeAPI.flags(player, KnowledgeAPI.key(CHAPTER_ID, foodNatureEntryId(id))).tasted()) {
            Item item = BuiltInRegistries.ITEM.getValue(id);
            return new TastedHerb(item, HerbNatureAPI.getNatureOrFallback(new ItemStack(item)));
         }
      }
      return null;
   }

   private static int discoveredFlavorCount(ServerPlayer player) {
      Set<String> flavors = new LinkedHashSet<>();
      for (Item item : HerbcraftAPI.getHerbRegistry().keySet()) {
         net.minecraft.resources.Identifier id = BuiltInRegistries.ITEM.getKey(item);
         if (id == null) continue;
         if (KnowledgeAPI.flags(player, KnowledgeAPI.key(CHAPTER_ID, id.getPath())).tasted()) {
            flavors.addAll(HerbNatureAPI.getNatureOrFallback(new ItemStack(item)).flavors());
         }
      }
      for (Identifier id : foodNatureItemIds()) {
         if (KnowledgeAPI.flags(player, KnowledgeAPI.key(CHAPTER_ID, foodNatureEntryId(id))).tasted()) {
            flavors.addAll(HerbNatureAPI.getNatureOrFallback(id).flavors());
         }
      }
      return flavors.size();
   }

   private static List<Identifier> foodNatureItemIds() {
      List<Identifier> ids = new ArrayList<>();
      for (Identifier id : HerbNatureRegistry.profiles().keySet()) {
         if (hasFoodNatureEntry(id) && BuiltInRegistries.ITEM.containsKey(id)) {
            ids.add(id);
         }
      }
      return ids;
   }

   private static int tastedIngredientCount(ServerPlayer player) {
      return KnowledgeAPI.chapter(IngredientsChapter.CHAPTER_ID).map(chapter -> {
         int count = 0;
         for (KnowledgeAPI.Entry entry : chapter.entries()) {
            if (!"overview".equals(entry.id()) && KnowledgeAPI.flags(player, KnowledgeAPI.key(IngredientsChapter.CHAPTER_ID, entry.id())).tasted()) {
               count++;
            }
         }
         return count;
      }).orElse(0);
   }

   private static int verifiedHerbalClaimCount(ServerPlayer player) {
      int count = 0;
      for (var entry : KnowledgeAPI.verifiedTrueClaims(player).entrySet()) if (entry.getKey().startsWith(CHAPTER_ID + "/")) count += entry.getValue().size();
      for (var entry : KnowledgeAPI.verifiedFalseClaims(player).entrySet()) if (entry.getKey().startsWith(CHAPTER_ID + "/")) count += entry.getValue().size();
      return count;
   }

   private static boolean advancementDone(ServerPlayer player, String namespace, String path) {
      var server = player.level().getServer();
      if (server == null) return false;
      var advancement = server.getAdvancements().get(net.minecraft.resources.Identifier.fromNamespaceAndPath(namespace, path));
      return advancement != null && player.getAdvancements().getOrStartProgress(advancement).isDone();
   }

   private record HerbKnowledgeStats(int encountered, int heard, int tasted, int mastered) {}
   private record TastedHerb(Item item, NatureProfile nature) {}
   private record FoodNatureCandidate(Identifier itemId, Item item, String entryId) {}

   private static List<Component> overviewLines() {
      return List.of(
         Component.translatable("book.herbcraft.entry.overview.line1").withStyle(ChatFormatting.GRAY),
         Component.translatable("book.herbcraft.entry.overview.line2"),
         Component.translatable("book.herbcraft.entry.overview.line3"),
         Component.translatable("book.herbcraft.entry.overview.line4").withStyle(ChatFormatting.DARK_GREEN)
      );
   }

   private static List<Component> lines(ServerPlayer player, String entryId, HerbDefinition definition) {
      List<Component> lines = new ArrayList<>();
      String key = "herbal/" + entryId;
      KnowledgeAPI.Entry entry = KnowledgeAPI.chapter("herbal").map(ch -> ch.entry(entryId)).orElse(null);
      KnowledgeDisplayState display = entry == null ? KnowledgeDisplayState.UNKNOWN : KnowledgeAPI.displayState(player, "herbal", entry);
      KnowledgeFlags flags = KnowledgeAPI.flags(player, key);
      NatureProfile nature = HerbNatureAPI.getNatureOrFallback(new net.minecraft.world.item.ItemStack(definition.item()));
      if (display == KnowledgeDisplayState.ENCOUNTERED) {
         lines.add(Component.translatable("knowledge.herbcraft.encountered.description").withStyle(ChatFormatting.GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.line.nature_unknown").withStyle(ChatFormatting.DARK_GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.line.traits_unknown").withStyle(ChatFormatting.DARK_GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.line.effects_unknown").withStyle(ChatFormatting.DARK_GRAY));
         return lines;
      }
      if (display == KnowledgeDisplayState.HEARD) {
         lines.add(HerbNatureAPI.natureLine(nature).append(Component.translatable("knowledge.herbcraft.claim.reported").withStyle(ChatFormatting.GRAY)).withStyle(ChatFormatting.DARK_AQUA));
         lines.add(HerbNatureAPI.traitHint(nature).append(Component.translatable("knowledge.herbcraft.claim.reported").withStyle(ChatFormatting.GRAY)).withStyle(ChatFormatting.GRAY));
         appendClaimLines(player, key, lines);
         lines.add(Component.translatable("knowledge.herbcraft.heard.not_tasted").withStyle(ChatFormatting.DARK_GRAY));
         return lines;
      }
      if (display == KnowledgeDisplayState.TASTED) {
         lines.add(HerbNatureAPI.natureLine(nature).append(Component.translatable("knowledge.herbcraft.claim.verified_by_taste").withStyle(ChatFormatting.GREEN)).withStyle(ChatFormatting.DARK_AQUA));
         lines.add(HerbNatureAPI.traitHint(nature).append(Component.translatable("knowledge.herbcraft.claim.verified_by_taste").withStyle(ChatFormatting.GREEN)).withStyle(ChatFormatting.GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.taste.line", taste(nature)).withStyle(ChatFormatting.GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.feeling.line", Component.translatable("knowledge.herbcraft.feeling." + nature.temperature())).withStyle(ChatFormatting.GRAY));
         if (flags.heard()) {
            appendClaimLines(player, key, lines);
         }
         appendExperienced(player, key, definition, lines, false);
         lines.add(Component.translatable("knowledge.herbcraft.tasted.precise_unknown").withStyle(new ChatFormatting[]{ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC}));
         return lines;
      }
      if (display == KnowledgeDisplayState.MASTERED) {
         lines.add(HerbNatureAPI.natureLine(nature).withStyle(ChatFormatting.DARK_AQUA));
         lines.add(HerbNatureAPI.traitHint(nature).withStyle(new ChatFormatting[]{ChatFormatting.GRAY, ChatFormatting.ITALIC}));
         List<String> usageKeys = HerbUsageAPI.usageKeys(definition.item());
         if (!usageKeys.isEmpty()) lines.add(HerbUsageAPI.usageLine(usageKeys).withStyle(ChatFormatting.GOLD));
         lines.add(Component.translatable("book.herbcraft.entry.nutrition", definition.nutrition(), String.format("%.1f", definition.saturation())).withStyle(ChatFormatting.GRAY));
         for (HerbEffectEntry effect : definition.effects()) lines.add(preciseEffectLine(effect));
         if (flags.tasted()) {
            lines.add(Component.translatable("knowledge.herbcraft.taste.line", taste(nature)).withStyle(ChatFormatting.GRAY));
            lines.add(Component.translatable("knowledge.herbcraft.feeling.line", Component.translatable("knowledge.herbcraft.feeling." + nature.temperature())).withStyle(ChatFormatting.GRAY));
            appendExperienced(player, key, definition, lines, true);
         }
         for (String route : com.herbcraft.api.KnowledgePracticeRegistry.routes(key)) lines.add(Component.translatable("knowledge.herbcraft.practice.route", Component.translatable("knowledge.herbcraft.route." + route.replace(":", "."))).withStyle(ChatFormatting.GOLD));
         appendClaimCorrections(player, key, lines);
      }
      return lines;
   }

   private static List<Component> foodNatureLines(ServerPlayer player, Item item, String entryId) {
      List<Component> lines = new ArrayList<>();
      String key = CHAPTER_ID + "/" + entryId;
      KnowledgeAPI.Entry entry = KnowledgeAPI.chapter(CHAPTER_ID).map(ch -> ch.entry(entryId)).orElse(null);
      KnowledgeDisplayState display = entry == null ? KnowledgeDisplayState.UNKNOWN : KnowledgeAPI.displayState(player, CHAPTER_ID, entry);
      KnowledgeFlags flags = KnowledgeAPI.flags(player, key);
      NatureProfile nature = HerbNatureAPI.getNatureOrFallback(new ItemStack(item));
      if (display == KnowledgeDisplayState.ENCOUNTERED) {
         lines.add(Component.translatable("knowledge.herbcraft.encountered.description").withStyle(ChatFormatting.GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.line.nature_unknown").withStyle(ChatFormatting.DARK_GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.line.traits_unknown").withStyle(ChatFormatting.DARK_GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.food_nature.codex_hint").withStyle(ChatFormatting.DARK_GRAY));
         return lines;
      }
      if (display == KnowledgeDisplayState.HEARD) {
         lines.add(HerbNatureAPI.natureLine(nature).append(Component.translatable("knowledge.herbcraft.claim.reported").withStyle(ChatFormatting.GRAY)).withStyle(ChatFormatting.DARK_AQUA));
         lines.add(HerbNatureAPI.traitHint(nature).append(Component.translatable("knowledge.herbcraft.claim.reported").withStyle(ChatFormatting.GRAY)).withStyle(ChatFormatting.GRAY));
         appendClaimLines(player, key, lines);
         lines.add(Component.translatable("knowledge.herbcraft.heard.not_tasted").withStyle(ChatFormatting.DARK_GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.food_nature.codex_hint").withStyle(ChatFormatting.DARK_GRAY));
         return lines;
      }
      if (display == KnowledgeDisplayState.TASTED || display == KnowledgeDisplayState.MASTERED) {
         lines.add(HerbNatureAPI.natureLine(nature).append(Component.translatable("knowledge.herbcraft.claim.verified_by_taste").withStyle(ChatFormatting.GREEN)).withStyle(ChatFormatting.DARK_AQUA));
         lines.add(HerbNatureAPI.traitHint(nature).append(Component.translatable("knowledge.herbcraft.claim.verified_by_taste").withStyle(ChatFormatting.GREEN)).withStyle(ChatFormatting.GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.taste.line", taste(nature)).withStyle(ChatFormatting.GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.feeling.line", Component.translatable("knowledge.herbcraft.feeling." + nature.temperature())).withStyle(ChatFormatting.GRAY));
         lines.add(Component.translatable("knowledge.herbcraft.food_nature.note").withStyle(ChatFormatting.DARK_AQUA));
         lines.add(Component.translatable("knowledge.herbcraft.food_nature.codex_hint").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
         if (flags.heard()) {
            appendClaimLines(player, key, lines);
         }
         appendClaimCorrections(player, key, lines);
      }
      return lines;
   }

   private static void appendClaimLines(ServerPlayer player, String key, List<Component> lines) {
      for (KnowledgeClaim claim : KnowledgeRumorRegistry.claims(key)) {
         PlayerClaimMark mark = KnowledgeAPI.claimMark(player, key, claim.id());
         MutableComponent line = Component.literal(mark.symbol() + " ").append(Component.translatable(claim.textKey()));
         line.append(Component.literal(" ")).append(Component.translatable("knowledge.herbcraft.source." + claim.sourceTier().getSerializedName()).withStyle(ChatFormatting.DARK_GRAY));
         line.append(Component.literal(" ")).append(Component.translatable(claim.suspicious() ? "knowledge.herbcraft.claim.suspicious" : "knowledge.herbcraft.claim.reported").withStyle(claim.suspicious() ? ChatFormatting.YELLOW : ChatFormatting.GRAY));
         lines.add(line.withStyle(ChatFormatting.GRAY));
      }
   }

   private static void appendClaimCorrections(ServerPlayer player, String key, List<Component> lines) {
      for (KnowledgeClaim claim : KnowledgeRumorRegistry.claims(key)) {
         if (!claim.truth()) {
            lines.add(Component.translatable("knowledge.herbcraft.mastered.false_claim", Component.translatable(claim.textKey())).withStyle(ChatFormatting.DARK_RED));
            PlayerClaimMark mark = KnowledgeAPI.claimMark(player, key, claim.id());
            if (mark == PlayerClaimMark.THINK_FALSE) lines.add(Component.translatable("knowledge.herbcraft.errata.player_correct").withStyle(ChatFormatting.GREEN));
            if (mark == PlayerClaimMark.THINK_TRUE) lines.add(Component.translatable("knowledge.herbcraft.errata.player_wrong").withStyle(ChatFormatting.RED));
         }
      }
   }

   private static MutableComponent taste(NatureProfile nature) {
      if (nature.tasteFlavors().contains("sweet") && nature.tasteFlavors().contains("bitter")) return Component.translatable("knowledge.herbcraft.taste.sweet_bitter");
      if (nature.tasteFlavors().contains("pungent") && nature.tasteFlavors().contains("sweet")) return Component.translatable("knowledge.herbcraft.taste.pungent_sweet");
      if (nature.tasteFlavors().contains("sour") && nature.tasteFlavors().contains("sweet")) return Component.translatable("knowledge.herbcraft.taste.sour_sweet");
      MutableComponent out = Component.empty(); boolean first = true;
      for (String flavor : nature.tasteFlavors()) { if (!first) out.append(Component.literal("，")); out.append(Component.translatable("knowledge.herbcraft.taste." + flavor)); first = false; }
      return out;
   }

   private static void appendExperienced(ServerPlayer player, String key, HerbDefinition definition, List<Component> lines, boolean precise) {
      java.util.Set<String> experienced = KnowledgeAPI.experiencedEffects(player).getOrDefault(key, java.util.Set.of());
      if (experienced.isEmpty()) { lines.add(Component.translatable("knowledge.herbcraft.tasted.no_effect_observed").withStyle(ChatFormatting.DARK_GRAY)); return; }
      for (HerbEffectEntry effect : definition.effects()) {
         net.minecraft.resources.Identifier id = BuiltInRegistries.MOB_EFFECT.getKey((MobEffect)effect.effect().value());
         if (id != null && experienced.contains(id.toString())) {
            MutableComponent name = Component.translatable(((MobEffect)effect.effect().value()).getDescriptionId());
            lines.add(Component.translatable("knowledge.herbcraft.tasted.experienced_format", name, precise ? Component.literal((effect.durationTicks()/20) + "s") : durationFuzzy(effect.durationTicks())).withStyle(ChatFormatting.BLUE));
         }
      }
   }

   private static MutableComponent durationFuzzy(int ticks) {
      if (ticks <= 60) return Component.translatable("knowledge.herbcraft.duration.instant");
      if (ticks <= 200) return Component.translatable("knowledge.herbcraft.duration.seconds");
      if (ticks <= 600) return Component.translatable("knowledge.herbcraft.duration.moment");
      return Component.translatable("knowledge.herbcraft.duration.long");
   }

   private static Component preciseEffectLine(HerbEffectEntry effect) {
      MutableComponent name = Component.translatable(((MobEffect)effect.effect().value()).getDescriptionId());
      if (effect.amplifier() > 0) name = Component.translatable("potion.withAmplifier", name, Component.translatable("potion.potency." + effect.amplifier()));
      int seconds = effect.durationTicks() / 20;
      MutableComponent line = Component.translatable("potion.withDuration", name, String.format("%d:%02d", seconds / 60, seconds % 60));
      if (effect.chance() < 1.0F) line = line.append(Component.literal(" " + Math.round(effect.chance() * 100.0F) + "%"));
      return line.withStyle(effect.negative() ? ChatFormatting.RED : ChatFormatting.BLUE);
   }

}
