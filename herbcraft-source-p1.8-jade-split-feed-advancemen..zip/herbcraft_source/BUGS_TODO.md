# BUGS_TODO

## Known bugs / risks

| Priority | Area | Item |
|---:|---|---|
| P0 | Alchemy | Source/jar mismatch has caused Mixin crashes. **2026-06-12 P0 pass:** `BrewingStandCatalystMixin.java` restored; built jar now contains the class. Still verify `herbcraft_alchemy.mixins.json` references only existing built classes before every release. |
| P0 | Alchemy | Hundred-Flower Feast / Deadly Hodgepodge catalyst brewing has been reconnected to `BrewingStandBlockEntity` via `BrewingStandCatalystMixin`; server smoke passes. Still needs real interactive client verification in the brewing stand. |
| P0 | Cuisine | Hidden dish items/recipes have disappeared from source during rollback. Verify source and built jar both contain `hundred_flower_feast`, `raw_hundred_flower_feast`, `deadly_hodgepodge`, `raw_deadly_hodgepodge`. |
| P1 | Codex | `百草经总纲` has been requested; verify it is actually registered in `HerbalChapter`, not only present in lang files. |
| P1 | Advancements | Advancement JSON exists in some builds but may be placeholder-like or incorrectly keyed. Needs a dedicated rebuild/trigger pass. |
| P2 | Compat | Jade/REI compatibility is not implemented. |

## TODO / new feature ideas

| Priority | Idea |
|---:|---|
| P0 | Run a real client smoke test, not only Gradle build. |
| P1 | Add exact custom advancement criteria instead of impossible placeholders for complex Herbcraft events. |
| P1 | Implement optional Jade support that respects Codex knowledge tiers. |
| P1 | Add in-game diagnostics or GameTest-style checks for hodgepodge and catalyst brewing. |
| P2 | Improve Codex usage pages after the overview is stable. |
| P2 | Add configurable values for witch potion chance, herb stack thresholds, and immunity duration multipliers. |
