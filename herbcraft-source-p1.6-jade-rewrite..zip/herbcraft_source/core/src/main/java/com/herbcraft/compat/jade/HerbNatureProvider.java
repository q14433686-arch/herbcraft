package com.herbcraft.compat.jade;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.IServerDataProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;

public enum HerbNatureProvider implements IBlockComponentProvider, IServerDataProvider<BlockAccessor> {
   INSTANCE;

   @Override
   public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) {
      Item item = accessor.getBlockState().getBlock().asItem();
      HerbJadeData.appendTooltip(tooltip, accessor.getServerData(), HerbJadeData.isHerb(item));
   }

   @Override
   public void appendServerData(CompoundTag data, BlockAccessor accessor) {
      Item item = accessor.getBlockState().getBlock().asItem();
      if (accessor.getPlayer() instanceof ServerPlayer serverPlayer) {
         HerbJadeData.write(data, serverPlayer, item);
      }
   }

   @Override
   public boolean shouldRequestData(BlockAccessor accessor) {
      return HerbJadeData.isHerb(accessor.getBlockState().getBlock().asItem());
   }

   @Override
   public Identifier getUid() {
      return HerbcraftJadePlugin.HERB_NATURE;
   }
}
