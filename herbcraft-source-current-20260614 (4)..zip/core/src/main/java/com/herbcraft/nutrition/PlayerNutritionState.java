package com.herbcraft.nutrition;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Per-player five-dimension nutrition state with six-state evaluation model.
 */
public final class PlayerNutritionState {
   private final Map<String, Integer> values = new LinkedHashMap<>();
   private long lastDecayTick = 0;
   private long lastCheckTick = 0;
   private long lastWarningTick = 0;
   private int badStateStreak = 0;

   public PlayerNutritionState() {
      NutritionRules rules = NutritionRules.current();
      for (String dim : NutritionProfile.DIMENSIONS) {
         values.put(dim, rules.initialValue);
      }
   }

   public int get(String dim) { return values.getOrDefault(dim, 0); }

   public void setDirect(String dim, int value) {
      values.put(dim, Math.max(0, Math.min(NutritionRules.current().maxValue, value)));
   }

   public void add(String dim, int amount) {
      NutritionRules rules = NutritionRules.current();
      int current = get(dim);
      values.put(dim, Math.min(rules.maxValue, Math.max(0, current + amount)));
   }

   public void addFromProfile(NutritionProfile profile) {
      for (String dim : NutritionProfile.DIMENSIONS) {
         int val = profile.get(dim);
         if (val > 0) add(dim, val);
      }
   }

   public boolean tickDecay(long gameTime) {
      NutritionRules rules = NutritionRules.current();
      if (rules.decayIntervalTicks <= 0) return false;
      if (gameTime - lastDecayTick < rules.decayIntervalTicks) return false;
      lastDecayTick = gameTime;
      boolean changed = false;
      for (String dim : NutritionProfile.DIMENSIONS) {
         int current = get(dim);
         if (current > 0) {
            values.put(dim, Math.max(0, current - rules.decayAmount));
            changed = true;
         }
      }
      return changed;
   }

   /**
    * Six-state evaluation model.
    * Priority: STARVED > IMBALANCED > MALNOURISHED > BALANCED > ABUNDANT > NORMAL
    */
   public NutritionStatus evaluate(long gameTime) {
      NutritionRules rules = NutritionRules.current();
      if (rules.checkIntervalTicks <= 0) return NutritionStatus.NORMAL;
      if (gameTime - lastCheckTick < rules.checkIntervalTicks) return NutritionStatus.NORMAL;
      lastCheckTick = gameTime;

      int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
      String minDim = "grain", maxDim = "grain";
      for (String dim : NutritionProfile.DIMENSIONS) {
         int v = get(dim);
         if (v < min) { min = v; minDim = dim; }
         if (v > max) { max = v; maxDim = dim; }
      }

      // 1. STARVED: all dimensions below malnutrition_low
      boolean allLow = true;
      for (String dim : NutritionProfile.DIMENSIONS) {
         if (get(dim) >= rules.malnutritionLow) { allLow = false; break; }
      }
      if (allLow) { badStateStreak++; return NutritionStatus.STARVED; }

      // 2. IMBALANCED: max > imbalance_high AND min < malnutrition_low
      if (max > rules.imbalanceHigh && min < rules.malnutritionLow) {
         badStateStreak++; return NutritionStatus.IMBALANCED;
      }

      // 3. MALNOURISHED: at least one dim < malnutrition_low
      if (min < rules.malnutritionLow) {
         badStateStreak++; return NutritionStatus.malnourished(minDim);
      }

      // 4. BALANCED: all dims in [full_balance_min, full_balance_max]
      boolean allBalanced = true;
      for (String dim : NutritionProfile.DIMENSIONS) {
         int v = get(dim);
         if (v < rules.fullBalanceMin || v > rules.fullBalanceMax) { allBalanced = false; break; }
      }
      if (allBalanced) { badStateStreak = 0; return NutritionStatus.BALANCED; }

      // 5. ABUNDANT: at least one dim > abundance_threshold AND min >= malnutrition_low
      if (max > rules.abundanceThreshold && min >= rules.malnutritionLow) {
         badStateStreak = 0; return NutritionStatus.abundant(maxDim);
      }

      // 6. NORMAL
      badStateStreak = 0;
      return NutritionStatus.NORMAL;
   }

   /** Check if enough time has passed for a status evaluation. */
   public boolean shouldCheck(long gameTime) {
      NutritionRules rules = NutritionRules.current();
      if (rules.checkIntervalTicks <= 0) return false;
      if (gameTime - lastCheckTick < rules.checkIntervalTicks) return false;
      lastCheckTick = gameTime;
      return true;
   }

   public void incrementBadStreak() { badStateStreak++; }
   public void clearBadStreak() { badStateStreak = 0; }

   public boolean shouldApplyDebuff() {
      return badStateStreak >= NutritionRules.current().badStateGraceChecks;
   }

   public boolean canWarn(long gameTime) {
      NutritionRules rules = NutritionRules.current();
      if (gameTime - lastWarningTick < rules.warningCooldownTicks) return false;
      lastWarningTick = gameTime;
      return true;
   }

   public void resetOnDeath() {
      NutritionRules rules = NutritionRules.current();
      for (String dim : NutritionProfile.DIMENSIONS) {
         values.put(dim, rules.initialValue);
      }
      badStateStreak = 0;
   }

   public Map<String, Integer> snapshot() { return Map.copyOf(values); }

   /**
    * Six nutrition states with associated dimension info.
    */
   public enum NutritionStatus {
      STARVED("nutrition.herbcraft.state.starved", null),
      MALNOURISHED_GRAIN("nutrition.herbcraft.state.malnourished.grain", "grain"),
      MALNOURISHED_FLESH("nutrition.herbcraft.state.malnourished.flesh", "flesh"),
      MALNOURISHED_OIL("nutrition.herbcraft.state.malnourished.oil", "oil"),
      MALNOURISHED_VEGE("nutrition.herbcraft.state.malnourished.vege", "vege"),
      MALNOURISHED_FRUIT("nutrition.herbcraft.state.malnourished.fruit", "fruit"),
      IMBALANCED("nutrition.herbcraft.state.imbalanced", null),
      NORMAL("nutrition.herbcraft.state.normal", null),
      ABUNDANT_GRAIN("nutrition.herbcraft.state.abundant.grain", "grain"),
      ABUNDANT_FLESH("nutrition.herbcraft.state.abundant.flesh", "flesh"),
      ABUNDANT_OIL("nutrition.herbcraft.state.abundant.oil", "oil"),
      ABUNDANT_VEGE("nutrition.herbcraft.state.abundant.vege", "vege"),
      ABUNDANT_FRUIT("nutrition.herbcraft.state.abundant.fruit", "fruit"),
      BALANCED("nutrition.herbcraft.state.balanced", null);

      private final String translationKey;
      private final String dimension;
      NutritionStatus(String key, String dim) { this.translationKey = key; this.dimension = dim; }
      public String translationKey() { return translationKey; }
      public String dimension() { return dimension; }
      public boolean isBad() { return this == STARVED || this.name().startsWith("MALNOURISHED") || this == IMBALANCED; }
      public boolean isGood() { return this == BALANCED || this.name().startsWith("ABUNDANT"); }

      static NutritionStatus malnourished(String dim) {
         return switch (dim) {
            case "grain" -> MALNOURISHED_GRAIN;
            case "flesh" -> MALNOURISHED_FLESH;
            case "oil" -> MALNOURISHED_OIL;
            case "vege" -> MALNOURISHED_VEGE;
            case "fruit" -> MALNOURISHED_FRUIT;
            default -> MALNOURISHED_GRAIN;
         };
      }

      static NutritionStatus abundant(String dim) {
         return switch (dim) {
            case "grain" -> ABUNDANT_GRAIN;
            case "flesh" -> ABUNDANT_FLESH;
            case "oil" -> ABUNDANT_OIL;
            case "vege" -> ABUNDANT_VEGE;
            case "fruit" -> ABUNDANT_FRUIT;
            default -> ABUNDANT_GRAIN;
         };
      }
   }
}
