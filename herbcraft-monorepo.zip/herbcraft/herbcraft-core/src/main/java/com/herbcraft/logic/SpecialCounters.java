package com.herbcraft.logic;

import com.herbcraft.HerbcraftPlayerData;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

public final class SpecialCounters {
	private static final int SECOND = 20;
	private static final int WINDOW = 1200;

	private SpecialCounters() {}

	public static void apply(Player player, Item item, long gameTime) {
		HerbcraftPlayerData data = (HerbcraftPlayerData) player;
		if (item == Items.POPPY) {
			int count = data.herbcraft$incrementWindowCounter("poppy", gameTime, WINDOW);
			player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 12 * SECOND, 0));
			if (count >= 3) player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 10 * SECOND, 0));
		}
		if (item == Items.TORCHFLOWER && data.herbcraft$incrementWindowCounter("torchflower", gameTime, WINDOW) >= 3) {
			player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 30 * SECOND, 0));
		}
		if ((item == Items.SUGAR || item == Items.HONEY_BLOCK) && data.herbcraft$incrementWindowCounter("sugar", gameTime, WINDOW) >= (item == Items.HONEY_BLOCK ? 2 : 4) && EffectResolver.roll(player, 0.50F)) {
			player.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 8 * SECOND, 0));
		}
		if (item == Items.SLIME_BALL && data.herbcraft$incrementWindowCounter("slime", gameTime, WINDOW) >= 3) {
			player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 5 * SECOND, 0));
		}
	}
}
