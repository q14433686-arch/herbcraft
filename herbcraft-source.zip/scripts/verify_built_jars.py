#!/usr/bin/env python3
import json, struct, sys, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
VERSION = '1.1.1'
JARS = {
    f'core/build/libs/herbcraft-{VERSION}.jar': {
        'id': 'herbcraft',
        'version': VERSION,
        'classes': [
            'com/herbcraft/Herbcraft.class',
            'com/herbcraft/knowledge/client/HerbcraftCoreClient.class',
            'com/herbcraft/effect/HerbcraftMobEffects.class',
            'com/herbcraft/effect/NutritionEffectRules.class',
            'com/herbcraft/nutrition/NutritionDebugCommands.class',
        ],
        'resources': [
            'fabric.mod.json',
            'herbcraft.mixins.json',
            'data/herbcraft/herbs.json',
            'data/herbcraft/special_counters.json',
            'data/herbcraft/nutrition_effects.json',
            'data/herbcraft/nutrition_correction_rules.json',
            'data/herbcraft/codex_loot_injections.json',
            'data/herbcraft/environment/drinkable/snowball.json',
            'data/herbcraft/environment/drinkable/honey_block.json',
            'data/herbcraft/tags/item/herb.json',
            'assets/herbcraft/textures/mob_effect/well_nourished.png',
        ],
    },
    f'alchemy/build/libs/herbcraft-alchemy-{VERSION}.jar': {
        'id': 'herbcraft_alchemy',
        'version': VERSION,
        'classes': [
            'com/herbcraft/alchemy/HerbcraftAlchemy.class',
            'com/herbcraft/alchemy/client/HerbcraftAlchemyClient.class',
            'com/herbcraft/alchemy/mixin/ItemCostAdvancedPotionMixin.class',
            'com/herbcraft/alchemy/mixin/BrewingStandCatalystMixin.class',
        ],
        'resources': [
            'fabric.mod.json',
            'herbcraft_alchemy.mixins.json',
            'data/herbcraft_alchemy/essences.json',
            'data/herbcraft_alchemy/potion_bonus_pools.json',
            'data/herbcraft_alchemy/special_potions.json',
            'data/herbcraft_alchemy/coating_rules.json',
            'data/herbcraft_alchemy/witch_loot.json',
            'data/herbcraft_alchemy/codex_loot_injections.json',
            'data/herbcraft/recipe/blank_adhesive.json',
        ],
    },
    f'cuisine/build/libs/herbcraft-cuisine-{VERSION}.jar': {
        'id': 'herbcraft_cuisine',
        'version': VERSION,
        'classes': [
            'com/herbcraft/cuisine/HerbcraftCuisine.class',
            'com/herbcraft/cuisine/client/HerbcraftCuisineClient.class',
            'com/herbcraft/cuisine/recipe/HodgepodgeRecipe.class',
            'com/herbcraft/cuisine/registry/HodgepodgeRules.class',
        ],
        'resources': [
            'fabric.mod.json',
            'data/herbcraft_cuisine/dishes.json',
            'data/herbcraft_cuisine/hodgepodge_rules.json',
            'data/herbcraft_cuisine/codex_loot_injections.json',
            'data/herbcraft_cuisine/environment/drinkable/water_bowl.json',
            'data/herbcraft_cuisine/environment/drinkable/deadly_hodgepodge.json',
            'data/herbcraft_cuisine/recipe/hodgepodge.json',
            'data/herbcraft_cuisine/recipe/raw_hundred_flower_feast.json',
            'data/herbcraft_cuisine/recipe/raw_deadly_hodgepodge.json',
        ],
    },
}

def json_load(zf, n):
    with zf.open(n) as f: return json.load(f)

def major(b):
    assert b[:4] == b'\xca\xfe\xba\xbe'
    return struct.unpack('>H', b[6:8])[0]

errs=[]
for rel, spec in JARS.items():
    p=ROOT/rel
    if not p.exists():
        errs.append(f'missing {rel}'); continue
    with zipfile.ZipFile(p) as zf:
        names=set(zf.namelist())
        mod=json_load(zf,'fabric.mod.json')
        if mod.get('id') != spec['id']:
            errs.append(f'{rel}: id {mod.get("id")} != {spec["id"]}')
        if mod.get('version') != spec['version']:
            errs.append(f'{rel}: version {mod.get("version")} != {spec["version"]}')
        for dep in ['fabricloader','minecraft','java','fabric-api']:
            if dep not in mod.get('depends',{}): errs.append(f'{rel}: missing dep {dep}')
        if spec['id'] in ('herbcraft_alchemy', 'herbcraft_cuisine'):
            if mod.get('depends',{}).get('herbcraft') != f'>={VERSION}':
                errs.append(f'{rel}: addon must depend on herbcraft >={VERSION}')
        for r in spec['resources']:
            if r not in names: errs.append(f'{rel}: missing {r}')
            elif r.endswith('.json'): json_load(zf,r)
        for c in spec['classes']:
            if c not in names: errs.append(f'{rel}: missing {c}')
            elif major(zf.read(c)) != 69: errs.append(f'{rel}: {c} is not Java 25 class version')
if errs:
    print('VERIFY FAILED')
    print('\n'.join('- '+e for e in errs))
    sys.exit(1)
print('VERIFY OK: all built jars contain expected metadata/resources/classes and Java 25 bytecode.')
