package com.herbcraft.advancement;

import com.herbcraft.api.HerbConsumeEvents;
import com.herbcraft.knowledge.CodexItems;
import com.herbcraft.knowledge.KnowledgeInventoryScanner;
import com.herbcraft.registry.HerbEntry;
import com.herbcraft.registry.HerbFoodRegistry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;

public final class HerbcraftAdvancementHooks {
   private HerbcraftAdvancementHooks() {}
   public static void register() {
      HerbConsumeEvents.register(HerbcraftAdvancementHooks::onHerbConsumed);
      KnowledgeInventoryScanner.registerHandler((player, stack) -> {
         if (stack.is(CodexItems.HERBAL_CODEX)) HerbcraftAdvancements.grant(player, "root");
      });
   }
   private static void onHerbConsumed(ServerPlayer player, Item item) {
      HerbcraftAdvancements.grant(player, "first_bite");
      Identifier id = BuiltInRegistries.ITEM.getKey(item);
      if (id != null) {
         String path = id.getPath();
         if (path.contains("grass") || path.contains("fern")) HerbcraftAdvancements.grant(player, "eat_grass");
      }
      HerbEntry entry = HerbFoodRegistry.get(item);
      if (entry != null) {
         if (entry.effects.stream().anyMatch(effect -> !effect.positive()) || !entry.damageEvents.isEmpty()) HerbcraftAdvancements.grant(player, "bitter_medicine");
         if (!entry.removeEffects.isEmpty() || entry.clearPositiveEffects) HerbcraftAdvancements.grant(player, "counter_poison");
      }
   }
}
