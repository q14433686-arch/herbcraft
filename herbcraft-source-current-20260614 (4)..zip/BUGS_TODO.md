# BUGS_TODO

This file is updated for the current `herbcraft_test_20260614_review` test baseline. Older source/jar desync warnings are kept where still relevant, but many previous TODO descriptions were stale.

## Known bugs / risks

| Priority | Area | Item |
|---:|---|---|
| P0 | Client validation | Run a real client smoke test. Server smoke/build cannot validate Codex feel, effect icon readability, Jade overlays, or brewing stand interaction. |
| P0 | Alchemy | Hidden cuisine catalyst brewing is source/build/server-smoke validated, but still needs real client brewing-stand verification: ingredient slot insertion, brew trigger, component preservation, and quality upgrade. |
| P0 | Nutrition UX | The seven nutrition effect icons have been regenerated from vanilla item textures and pass automated checks, but they still need visual approval in the actual effect HUD/inventory. |
| P1 | Nutrition code cleanup | `PlayerNutritionState.evaluate()` contains an older six-state evaluation path that is not the authoritative runtime path. Runtime behavior currently lives in `NutritionManager.evaluateAndApply()`. Consider unifying or removing the stale evaluation method later. |
| P1 | Advancements | Advancement JSON loads and validators pass count checks, but a dedicated reachability/trigger pass is still recommended. |
| P1 | Codex UX | Codex overview is registered, and claim hitbox alignment was fixed, but a real-client pass is still recommended for scrolling, claim markers, and long text. |
| P2 | Animal food validator | `validate_animal_food_tags.py` can fail when `/home/user/cache/minecraft/client-26.1.2.jar` is missing. Update it to use Loom's client jar or provide the cache. |
| P2 | Compat | REI compatibility is not implemented. Jade support exists for Herbcraft knowledge-gated display but still needs real-client config testing. |

## Recently verified / addressed

### Source/jar consistency and hidden cuisine

- `BrewingStandCatalystMixin.java` exists in source and built jar.
- `herbcraft_alchemy.mixins.json` references classes that exist.
- `hundred_flower_feast`, `raw_hundred_flower_feast`, `deadly_hodgepodge`, and `raw_deadly_hodgepodge` exist in source/resources and built jars.
- Hidden dish recipes use water bowl raw recipes followed by cooking routes.
- `百草经总纲` is registered in `HerbalChapter` as the `overview` entry.

### Nutrition/cuisine conflict fix

- NutritionManager no longer uses vanilla negative `MobEffects.WEAKNESS`, `SLOWNESS`, `MINING_FATIGUE`, `HUNGER`, or `NAUSEA` as core malnutrition states.
- Seven custom nutrition effects exist:
  - `grain_deficiency`
  - `flesh_deficiency`
  - `oil_deficiency`
  - `vege_deficiency`
  - `fruit_deficiency`
  - `dietary_imbalance`
  - `well_nourished`
- Severe malnutrition and starved states are sustained until the next nutrition check interval.
- Nutrition evaluation clears stale Herbcraft nutrition effects before reapplying current-state effects.
- `DishItem.clear_all_effects`, `EffectResolver.clearPositiveEffects`, and `HodgepodgeItem.clearPositiveEffects` skip Herbcraft nutrition effects.
- Water bowl retains 15% success chance, clears vanilla nausea, and temporarily relieves dietary imbalance for 60s without repairing nutrition values.
- `/herbcraft nutrition get|set|preset` debug commands exist for OP/gamemaster testing.
- Nutrition effect icons are generated from vanilla item textures by `scripts/generate_nutrition_effect_icons.py`.

## TODO / new feature ideas

| Priority | Idea |
|---:|---|
| P0 | Real-client nutrition test: use `/herbcraft nutrition preset` commands to verify sustained effects, immediate stale-effect cleanup, water relief, and icon appearance. |
| P0 | Real-client brewing catalyst test for Hundred-Flower Feast and Deadly Hodgepodge. |
| P1 | Add a small in-game diagnostics/GameTest path for hodgepodge and catalyst brewing if feasible. |
| P1 | Audit advancement criteria reachability and replace placeholder-like criteria where needed. |
| P1 | Decide whether nutrition profiles should be tuned for main-mod softness after client playtesting; do not harden them prematurely. |
| P2 | Future addon: design `hardcore_nutrition` as a separate module/addon with stricter decay, penalties, and disease-like consequences. |
| P2 | Improve generated nutrition icons manually if the author dislikes the in-game look. |
| P2 | Add configurable values for witch potion chance, herb stack thresholds, nutrition decay, and immunity multipliers. |

## Required validation before any release claim

```bash
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
python3 scripts/check_lang_diff.py
python3 scripts/validate_custom_nutrition_effects_phase8.py
python3 scripts/validate_nutrition_cuisine_immunity_isolation.py
python3 scripts/validate_recipe_isolation.py
python3 scripts/validate_trade_tags.py
python3 scripts/validate_item_textures.py
python3 scripts/validate_task_abcd.py
python3 scripts/validate_extended_features.py
python3 scripts/verify_built_jars.py
```

`validate_animal_food_tags.py` remains useful but may require a vanilla client jar cache.

## Historical notes kept for context

- P1.5/P1.6 knowledge model migration and right-click-start unlock fixes are present.
- P1.7/P1.8/P1.10 Jade/tooltip information gating fixes are present.
- P1.9 flavor/taste split is present; future mechanics must read pharmacological `flavors`, not descriptive `taste_flavors`.
- P1.11 Codex claim marker hitbox alignment is present.
