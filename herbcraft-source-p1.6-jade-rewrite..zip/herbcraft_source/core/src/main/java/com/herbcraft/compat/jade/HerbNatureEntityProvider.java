package com.herbcraft.compat.jade;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import snownee.jade.api.EntityAccessor;
import snownee.jade.api.IEntityComponentProvider;
import snownee.jade.api.IServerDataProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;

public enum HerbNatureEntityProvider implements IEntityComponentProvider, IServerDataProvider<EntityAccessor> {
   INSTANCE;

   @Override
   public void appendTooltip(ITooltip tooltip, EntityAccessor accessor, IPluginConfig config) {
      Entity entity = accessor.getEntity();
      ItemStack stack = entity instanceof ItemEntity itemEntity ? itemEntity.getItem() : ItemStack.EMPTY;
      HerbJadeData.appendTooltip(tooltip, accessor.getServerData(), !stack.isEmpty() && HerbJadeData.isHerb(stack.getItem()));
   }

   @Override
   public void appendServerData(CompoundTag data, EntityAccessor accessor) {
      Entity entity = accessor.getEntity();
      if (entity instanceof ItemEntity itemEntity && accessor.getPlayer() instanceof ServerPlayer serverPlayer) {
         HerbJadeData.write(data, serverPlayer, itemEntity.getItem().getItem());
      }
   }

   @Override
   public boolean shouldRequestData(EntityAccessor accessor) {
      Entity entity = accessor.getEntity();
      return entity instanceof ItemEntity itemEntity && HerbJadeData.isHerb(itemEntity.getItem().getItem());
   }

   @Override
   public Identifier getUid() {
      return HerbcraftJadePlugin.HERB_NATURE_ITEM_ENTITY;
   }
}
