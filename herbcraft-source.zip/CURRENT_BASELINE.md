# CURRENT_BASELINE

This is the short authoritative anchor for the current Herbcraft working state. Every future agent turn that changes source, resources, docs, scripts, validation rules, versions, or release outputs must update this file before reporting completion.

## Current baseline

- Baseline directory: `release_output/herbcraft_test_20260614_review/`
- Source archive: `release_output/herbcraft_test_20260614_review/herbcraft-source-current-20260614.zip`
- Current release/test version: `1.1.1`
- Minecraft: `26.1.2`
- Fabric Loader: `0.19.3+`
- Fabric API: `0.151.0+26.1.2+`
- Java: `25+`
- Gradle Wrapper: `9.4.1`
- Loom: `1.16-SNAPSHOT` resolving as `1.16.3`

## Current output files

The current output set should contain:

- `herbcraft-1.1.1.jar`
- `herbcraft-alchemy-1.1.1.jar`
- `herbcraft-cuisine-1.1.1.jar`
- `herbcraft-source-current-20260614.zip`

Optional client-test artifact currently present in the same directory:

- `herbcraft-p3-startup-food-test-addon-1.0.0.jar` — test addon only, not a public Herbcraft release jar.

Do not use an `output/` directory because platform snapshots exclude directories named `output`. Use `release_output/`.

## Environment/cache notes

Do not delete useful build environment/cache state unless explicitly asked. In particular, preserve:

- Gradle caches where possible.
- `/tmp/herbcraft-jdk25` if present.
- `scripts/setup_jdk25_temurin.sh`.
- `reference_cache/26_1_porting_notes.md`.
- Current `release_output/` baseline.

If JDK 25 is missing, run:

```bash
bash scripts/setup_jdk25_temurin.sh
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
```

## Authoritative current facts

### Versioning

- `build.gradle` sets subproject version to `1.1.1`.
- Core `fabric.mod.json` version is `1.1.1`.
- Alchemy `fabric.mod.json` version is `1.1.1` and depends on `herbcraft >=1.1.1`.
- Cuisine `fabric.mod.json` version is `1.1.1` and depends on `herbcraft >=1.1.1`.

### Core

- Core mod ID: `herbcraft`.
- `herbs.json` drives 96 edible definitions.
- `herb_natures.json` covers 96 nature profiles.
- Herb Codex exists with knowledge states, rumors, claim marks, errata verification, and UI sync.
- `百草经总纲` is registered as `overview` in `HerbalChapter`.
- Jade/tooltip display is knowledge-gated.
- Nutrition is now based on custom Herbcraft effects, not vanilla negative effects.

### Nutrition current state

Seven Herbcraft nutrition effects exist:

- `herbcraft:grain_deficiency` / 谷气亏虚 / block break speed reduction.
- `herbcraft:flesh_deficiency` / 血肉亏虚 / attack damage reduction.
- `herbcraft:oil_deficiency` / 津脂不足 / movement speed reduction.
- `herbcraft:vege_deficiency` / 蔬素不足 / periodic exhaustion.
- `herbcraft:fruit_deficiency` / 津液不足 / light movement speed reduction. The former displayed “fruit” nutrition dimension is now presented as `津液` / `Fluids`.
- `herbcraft:dietary_imbalance` / 饮食失衡 / light movement speed reduction plus periodic exhaustion.
- `herbcraft:well_nourished` / 五养调和 / armor and knockback-resistance bonus.

Current nutrition behavior:

- Warning states remain light/probabilistic.
- Danger states below `malnutrition_low` are sustained until the next nutrition check interval.
- Starved state applies all five deficiency effects in sustained form.
- Confirmed dietary imbalance is grace-gated, then sustained unless recent meals are actively correcting the imbalance.
- Nutrition correction/recent-meal pass is implemented: the last 24 meals are tracked; the last 3600 ticks / 3 minutes form a correction scoring window; correction score threshold is 60; correction now uses `data/herbcraft/nutrition_correction_rules.json` relationship matrix; active correction applies extra high-dimension decay every 200 ticks by 15..45 until target 650. `fruit`/津液/Fluids is decoupled from the ordinary correction matrix: all ordinary fruit correction weights are `0.0`; high `fruit` is non-punitive in the base mod while low 津液 deficiency remains meaningful. If `fruit >= 850`, other non-fruit dimensions above 850 slowly normalize toward 700 by 10 per 200 ticks.
- New client status `correcting` / `饮食回正中` exists for active correction.
- Water bowl keeps a 15% success chance and temporarily relieves dietary imbalance for 60 seconds without repairing nutrition values.
- `/herbcraft nutrition get|set|preset` debug commands exist and require gamemaster permission. Presets now include `correcting_flesh`, `correcting_oil`, `correcting_grain`, and `excess_fruit_nonpunitive`.
- Nutrition effect mechanics and timing are data-backed by `data/herbcraft/nutrition_effects.json`.
- Nutrition effect icons are generated from vanilla item textures by `scripts/generate_nutrition_effect_icons.py`.

### Cuisine

- Cuisine mod ID: `herbcraft_cuisine`.
- Cuisine depends on Core only.
- `dishes.json` currently defines 10 fixed dishes and 22 medicinal/hidden dishes.
- Water bowl exists and can temporarily relieve dietary imbalance on the same 15% success chance as vanilla nausea relief.
- `DishItem.clear_all_effects` skips Herbcraft nutrition effects.
- `HodgepodgeItem.clearPositiveEffects` skips Herbcraft nutrition effects.
- Hidden dishes exist in source and built jars:
  - `hundred_flower_feast`
  - `raw_hundred_flower_feast`
  - `deadly_hodgepodge`
  - `raw_deadly_hodgepodge`

### Alchemy

- Alchemy mod ID: `herbcraft_alchemy`.
- Alchemy depends on Core only.
- 40 current essence definitions are now data-backed by `data/herbcraft_alchemy/essences.json`.
- Static essence fields still exist for compatibility but initialize via `essenceFromJson(...)`.
- Extra essence definitions beyond the 40 compatibility fields are registered from `essences.json` at `AlchemyRegistries.initialize()` time; addons/data packs still need to provide recipes/assets/lang for polished extra entries.
- Potion bonus pools are data-backed by `data/herbcraft_alchemy/potion_bonus_pools.json`.
- Special/T3 potion definitions and the safe witch throw pool are data-backed by `data/herbcraft_alchemy/special_potions.json`.
- Witch loot is data-backed by `data/herbcraft_alchemy/witch_loot.json`.
- Weapon coating rules are data-backed by `data/herbcraft_alchemy/coating_rules.json`.
- Core/alchemy/cuisine Codex page loot injections are JSON-backed by each module's `codex_loot_injections.json`.
- `BrewingStandCatalystMixin.java` exists and builds.
- Hidden cuisine catalyst brewing source exists and preserves potion stack components by copying input stacks and setting only quality.

## Externalized data tables already done

The following formerly Java-hardcoded or partly Java-hardcoded systems are now JSON-backed:

- `data/herbcraft/special_counters.json`
- `data/herbcraft_cuisine/hodgepodge_rules.json`
- `data/herbcraft_alchemy/potion_bonus_pools.json`
- `data/herbcraft_alchemy/essences.json`
- `data/herbcraft/codex_loot_injections.json`
- `data/herbcraft_alchemy/codex_loot_injections.json`
- `data/herbcraft_cuisine/codex_loot_injections.json`
- `data/herbcraft_alchemy/special_potions.json`
- `data/herbcraft_alchemy/coating_rules.json`
- `data/herbcraft_alchemy/witch_loot.json`
- `data/herbcraft/nutrition_effects.json`
- `core/src/main/resources/data/herbcraft/nutrition_profiles.json` now includes `minecraft:milk_bucket` as gentle flesh/oil nutrition and reduces `herbcraft_cuisine:water_bowl` to trace fluids only.
- `data/herbcraft_cuisine/environment/drinkable/*.json` provides optional Homeostatic drinkable data for Cuisine custom edible outputs. Values are balanced against Homeostatic's 20-point water bar; water bowl is `amount 6 / saturation 1.2` with `85%` thirst-effect risk to prevent trivial infinite hydration.
- `data/herbcraft/environment/drinkable/*.json` provides optional Homeostatic drinkable data for selected Core/vanilla Herbcraft edible items not already covered by Homeostatic's known generated vanilla drinkables. Ice/snow/water-adjacent items give meaningful hydration; sweet/sticky/hot/toxic items use `amount 0` plus strong thirst-effect risk instead of negative hydration, because Homeostatic stores negative water internally without clamping to zero.
- First low-risk external extension merge layer is implemented for server data under `data/<namespace>/herbcraft/herb_natures/*.json`, `nutrition_profiles/*.json`, `special_counters/*.json`, `knowledge_rumors/*.json`, and `codex_loot_injections/*.json`. Runtime support is in `ExternalDataResources`, `HerbcraftExternalDataReloadListener`, and the corresponding Core registries/managers.
- Startup-only external herb food registration is implemented for loaded Fabric mod/addon resources under `data/<namespace>/herbcraft/herbs/*.json`. It is scanned by `HerbFoodRegistry.loadExternalStartupResources()` during Herbcraft initialization before `DefaultItemComponentEvents.MODIFY` registration. It is **not** a world datapack `/reload` feature for changing FOOD/CONSUMABLE components.

Validator:

```bash
python3 scripts/validate_externalized_rules.py
```

## Current key validators

Run these after meaningful changes:

```bash
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
python3 scripts/check_lang_diff.py
python3 scripts/validate_custom_nutrition_effects_phase8.py
python3 scripts/validate_nutrition_correction_phase.py
python3 scripts/validate_externalized_rules.py
python3 scripts/validate_essence_resources.py
python3 scripts/validate_homeostatic_compat.py
python3 scripts/validate_nutrition_cuisine_immunity_isolation.py
python3 scripts/validate_recipe_isolation.py
python3 scripts/validate_item_textures.py
python3 scripts/validate_task_abcd.py
python3 scripts/validate_extended_features.py
python3 scripts/validate_trade_tags.py
python3 scripts/validate_external_extension_spec.py
python3 scripts/verify_built_jars.py
```

`validate_animal_food_tags.py` may need a vanilla client jar cache and is not always runnable in the sandbox without extra setup.

## Known remaining work / do not confuse with completed work

Not yet done:

- Author reported local real-client validation passed for the previously requested nutrition, Codex/Jade/UI, brewing catalyst, and related smoke checks with no visible bugs/conflicts.
- Further real-client validation is still useful after future changes, especially for any new dynamic essence/resource-generation work.
- Round-1 Homeostatic compatibility for Herbcraft Cuisine custom edible outputs is implemented as optional data under `data/herbcraft_cuisine/environment/drinkable/` and guarded by `scripts/validate_homeostatic_compat.py`.
- Round-2 Homeostatic compatibility for selected Core/vanilla Herbcraft edible items is implemented as optional data under `data/herbcraft/environment/drinkable/`, with Homeostatic's known vanilla drinkable items intentionally avoided to reduce duplicate/override risk.
- Fully data-driven automatic asset/recipe/lang generation for additional dynamic essences. Current dynamic support registers extra essence items/potions from JSON, but external resource/data files are still needed for a polished addon entry.
- `scripts/generate_essence_resources.py` and `scripts/validate_essence_resources.py` now implement/check the first project-local essence resource generation step.
- `scripts/generate_essence_resources.py` also supports `--scaffold-extension` for one-off standalone essence extension scaffolds, including optional wandering trader trade and Codex rumor skeletons. Scaffold mode now supports multiple source items through `--sources`, optional `--no-trade` / `--no-codex` switches, and `--check-extension` validation for generated or third-party scaffold directories.
- `docs/examples/essence_extension_example/` provides an example essence extension layout.
- `docs/EXTENDING_HERBCRAFT.md` documents the current extension surface and limitations.
- `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` now tracks P1/P2/P3/P4 external extension planning and current implementation status.
- `docs/HOMEOSTATIC_TEMPERATURE_COMPAT_NOTES.md` records P1 Homeostatic temperature research. No Homeostatic temperature gameplay integration is implemented yet.
- `docs/examples/external_extension_compat_pack/` and `scripts/validate_external_extension_spec.py` provide the first example/validator for the P2 external merge layer.
- `docs/examples/startup_herb_food_extension_mod/` provides an example layout for P3 startup-only herb food extension resources.
- `docs/reports/P2_EXTERNAL_DATAPACK_SMOKE_20260615.md` records the successful P2 external datapack server smoke test and the resolved pack metadata warning.
- `docs/reports/P3_STARTUP_HERB_FOOD_SMOKE_20260615.md` records the successful P3 temporary mod startup herb food server smoke test.
- `docs/reports/EXTENSION_CONSISTENCY_REVIEW_20260615.md` records the post-P2/P3 consistency review and next-round recommendation.
- `docs/reports/P3_CLIENT_TEST_CHECKLIST_20260615.md` gives the author a concrete real-client test table for the generated P3 startup food test addon.
- Author reported the P3 real-client test passed fully: the test item was edible/functional, residual page and Herb Codex entries worked, and the item appeared normally in 奇材志 with expected description/lines.
- `docs/reports/NUTRITION_FLUIDS_DESIGN_REVIEW_20260615.md` records the current analysis-only review of the 津液/Fluids excess design issue discovered during survival testing.
- `release_output/herbcraft_test_20260614_review/herbcraft-p3-startup-food-test-addon-1.0.0.jar` is a generated test addon from `docs/examples/startup_herb_food_extension_mod/`; it is not a public release jar.
- `docs/EXTENSION_GENERATOR_PLAN.md` remains the planning reference for future generator/API work and is updated with current implementation status.
- P4 stable Java extension events/API remains deferred and should not be presented as implemented. P3 is implemented only for loaded Fabric mod/addon startup resources, not hot-reloadable world datapacks. External P3 herb items do not automatically gain tag membership; addons should provide item tags if they want tag-based systems such as hodgepodge to accept them.
- Nutrition correction B+E hybrid is implemented, not just discussed. It tracks recent meals and uses amount-weighted correction score to relieve dietary imbalance and accelerate excessive-dimension decay. High 津液/Fluids is non-punitive in the base mod; low 津液 deficiency remains meaningful.
- Author reports the correction configuration is active and has no obvious bug, but current correction speed is too slow. Current implemented timing from 1000 to 650 is approximately 10.9 minutes at threshold score 60, 7.0 minutes at score 160, and 4.7 minutes at the current max cap 12/10s; this is too slow for survival pacing.
- `docs/reports/NUTRITION_CORRECTION_NEXT_IMPLEMENTATION_SPEC_20260615.md` records the design spec, `docs/reports/NUTRITION_CORRECTION_TUNING_MATRIX_PROPOSAL_20260615.md` records the matrix/timing proposal, and `docs/reports/NUTRITION_CORRECTION_IMPLEMENTATION_REPORT_20260615.md` records the implemented matrix tuning: dimension-specific correction matrix, stronger 15..45 per-10s decay, and high-津液 surplus normalization of other excesses toward 700.
- Correction stacking issue is fixed in source/build: `correctionScore` no longer requires the correcting dimension's stored value to be below `correctionTargetValue` 650, and matrix decay plus high-津液 surplus decay are computed from original tick values and stacked before applying. In high flesh + high vege + high fruit scenarios, valid recent matrix meals can now stack with the high-津液 -10 helper instead of being filtered out.
- Coupling issue is fixed in source/build: ordinary correction-matrix `fruit`/津液 weights are now all `0.0`, so fruit-bearing foods no longer suppress `DIETARY_IMBALANCE` through the ordinary correction matrix. 津液 remains active only as low-deficiency, non-punitive high storage, and special high-津液 surplus helper toward 700. See `docs/reports/NUTRITION_FLUIDS_CORRECTION_COUPLING_REVIEW_20260615.md`.

Do not redo completed work unless a new bug is observed.

## Per-turn rule

At the end of every future turn that changes the project, update this file with:

1. What changed this turn.
2. Whether output jars/source zip were updated.
3. Which validations were run.
4. Any new remaining risks.

If this file is not updated after a modifying turn, the next agent may anchor to stale state. That is considered a serious workflow error.

## Last updated

- Date: 2026-06-15
- Change: Implemented 津液/Fluids decoupling from the ordinary correction matrix. Updated `data/herbcraft/nutrition_correction_rules.json` so every ordinary matrix `fruit` weight is `0.0` for grain/flesh/oil/vege correction. 津液 now remains active only as low-fluids deficiency, non-punitive high storage, and the special high-津液 surplus helper toward 700. Updated `scripts/validate_nutrition_correction_phase.py` expectations and related docs/reports, including `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md`, `docs/reports/NUTRITION_FLUIDS_CORRECTION_COUPLING_REVIEW_20260615.md`, and `docs/reports/NUTRITION_CORRECTION_IMPLEMENTATION_REPORT_20260615.md`.
- Output updated: yes, rebuilt jars, copied current `1.1.1` jars into `release_output/herbcraft_test_20260614_review/`, and refreshed `herbcraft-source-current-20260614.zip`. The optional test-only addon jar remains present.
- Last known validations: `JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew --no-daemon build --rerun-tasks` passed. Then language diff, custom nutrition phase8, nutrition correction validator, externalized rules, essence resources, Homeostatic compat, nutrition/cuisine immunity isolation, recipe isolation, item textures, task ABCD, extended features, trade tags, external extension spec validator, and built jar verification all passed.
