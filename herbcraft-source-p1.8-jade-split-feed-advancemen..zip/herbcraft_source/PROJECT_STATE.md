# PROJECT_STATE

This file records the current repository state as honestly as possible after the recent source/jar desynchronization problems.

## Versions

| Module | Mod ID | Version |
|---|---|---:|
| core | `herbcraft` | `1.1.5` |
| alchemy | `herbcraft_alchemy` | `0.2.4` |
| cuisine | `herbcraft_cuisine` | `0.3.5` |

## Implemented / present in source

### Core

- `data/herbcraft/herbs.json` drives raw edible herb definitions.
- Effect immunity system exists:
  - `EffectImmunityManager`
  - `LivingEntityMixin`
  - `HerbcraftAPI.grantEffectImmunity`
  - `HerbcraftAPI.isImmuneToEffect`
- Herb Codex framework exists, with dynamic chapters and tattered pages.
- Animal food/tempt tag validator script exists; actual tag files must be checked before release because this area has been lost during rollbacks before.
- Herb stack code exists; actionbar threshold/fade/overload feedback has been added in some versions, but must be rechecked before release.

### Cuisine

- Water bowl and hodgepodge systems exist.
- Recipe isolation validator exists and should be treated as mandatory.
- Hidden dishes are designed as:
  - `hundred_flower_feast`
  - `raw_hundred_flower_feast`
  - `deadly_hodgepodge`
  - `raw_deadly_hodgepodge`
- Hidden dishes should be water-bowl raw recipes followed by smelting/smoking/campfire cooking.
- Recent issue: hidden dish files have disappeared from source in prior rollbacks even when they existed in release jars. Always inspect source and jar contents.

### Alchemy

- Essence/potion/coating systems exist.
- High-tier potion quality and bonus components exist.
- `ItemCostAdvancedPotionMixin` exists for randomized potion villager trade matching.
- Witch potion and hidden cuisine catalyst work has been attempted.
- 2026-06-12 P0 pass: `BrewingStandCatalystMixin.java` has been restored in source and reconnects hidden cuisine catalysts to brewing stand `isBrewable` / `doBrew`; alchemy server smoke reaches `Done`. Continue checking mixin JSON against built classes before every release.

## Known current risk / not fully trustworthy areas

- Alchemy catalyst brewing is not yet proven in a real client after final source cleanup.
- Advancement files have been generated several times; some are still placeholder-like and need a dedicated correctness pass.
- The Codex overview / 总纲 has been requested but must be verified in source before claiming it exists.
- Release jars and source have gone out of sync multiple times; next AI must build fresh from source and inspect jar contents.

## Validation scripts present

- `scripts/check_lang_diff.py`
- `scripts/validate_recipe_isolation.py`
- `scripts/validate_item_textures.py`
- `scripts/validate_task_abcd.py`
- `scripts/validate_animal_food_tags.py`
- `scripts/validate_extended_features.py`
- `scripts/verify_built_jars.py`

These scripts are useful but not perfect. If source state changes, update validators rather than trusting stale assumptions.
