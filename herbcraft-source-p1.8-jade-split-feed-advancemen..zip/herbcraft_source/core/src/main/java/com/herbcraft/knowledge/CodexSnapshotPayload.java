package com.herbcraft.knowledge;

import com.herbcraft.api.KnowledgeAPI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;

public record CodexSnapshotPayload(List<CodexSnapshotPayload.ChapterSnap> chapters) implements CustomPacketPayload {
   public static final Type<CodexSnapshotPayload> TYPE = new Type(Identifier.fromNamespaceAndPath("herbcraft", "codex_snapshot"));
   public static final StreamCodec<RegistryFriendlyByteBuf, CodexSnapshotPayload> STREAM_CODEC = CustomPacketPayload.codec(
      CodexSnapshotPayload::write, CodexSnapshotPayload::read
   );

   public Type<CodexSnapshotPayload> type() {
      return TYPE;
   }

   public static CodexSnapshotPayload build(ServerPlayer player) {
      List<CodexSnapshotPayload.ChapterSnap> chapters = new ArrayList<>();

      for (KnowledgeAPI.Chapter chapter : KnowledgeAPI.chapters()) {
         Map<String, List<CodexSnapshotPayload.EntrySnap>> bySection = new LinkedHashMap<>();
         chapter.sections().keySet().forEach(sectionIdx -> bySection.put(sectionIdx, new ArrayList<>()));
         bySection.put("", new ArrayList<>());

         for (KnowledgeAPI.Entry entry : chapter.entries()) {
            KnowledgeAPI.State state = KnowledgeAPI.state(player, chapter.id(), entry);
            List<Component> lines = state == KnowledgeAPI.State.UNKNOWN ? List.of() : entry.lines().apply(player, state);
            String sectionId = entry.section() == null ? "" : entry.section();
            bySection.computeIfAbsent(sectionId, key -> new ArrayList<>()).add(new CodexSnapshotPayload.EntrySnap(entry.title(), state.ordinal(), lines));
         }

         List<CodexSnapshotPayload.SectionSnap> sections = new ArrayList<>();
         chapter.sections().forEach((sectionIdx, title) -> {
            List<CodexSnapshotPayload.EntrySnap> entries = bySection.getOrDefault(sectionIdx, List.of());
            if (!entries.isEmpty()) {
               sections.add(new CodexSnapshotPayload.SectionSnap(title, entries));
            }
         });
         List<CodexSnapshotPayload.EntrySnap> unsectioned = bySection.getOrDefault("", List.of());
         if (!unsectioned.isEmpty()) {
            sections.add(new CodexSnapshotPayload.SectionSnap(Component.translatable("book.herbcraft.section.general"), unsectioned));
         }

         chapters.add(new CodexSnapshotPayload.ChapterSnap(chapter.title(), sections));
      }

      return new CodexSnapshotPayload(chapters);
   }

   private void write(RegistryFriendlyByteBuf buf) {
      buf.writeVarInt(this.chapters.size());

      for (CodexSnapshotPayload.ChapterSnap chapter : this.chapters) {
         ComponentSerialization.TRUSTED_STREAM_CODEC.encode(buf, chapter.title());
         buf.writeVarInt(chapter.sections().size());

         for (CodexSnapshotPayload.SectionSnap section : chapter.sections()) {
            ComponentSerialization.TRUSTED_STREAM_CODEC.encode(buf, section.title());
            buf.writeVarInt(section.entries().size());

            for (CodexSnapshotPayload.EntrySnap entry : section.entries()) {
               ComponentSerialization.TRUSTED_STREAM_CODEC.encode(buf, entry.title());
               buf.writeVarInt(entry.state());
               buf.writeVarInt(entry.lines().size());

               for (Component line : entry.lines()) {
                  ComponentSerialization.TRUSTED_STREAM_CODEC.encode(buf, line);
               }
            }
         }
      }
   }

   private static CodexSnapshotPayload read(RegistryFriendlyByteBuf buf) {
      int chapterCount = buf.readVarInt();
      List<CodexSnapshotPayload.ChapterSnap> chapters = new ArrayList<>(chapterCount);

      for (int c = 0; c < chapterCount; c++) {
         Component chapterTitle = (Component)ComponentSerialization.TRUSTED_STREAM_CODEC.decode(buf);
         int sectionCount = buf.readVarInt();
         List<CodexSnapshotPayload.SectionSnap> sections = new ArrayList<>(sectionCount);

         for (int s = 0; s < sectionCount; s++) {
            Component sectionTitle = (Component)ComponentSerialization.TRUSTED_STREAM_CODEC.decode(buf);
            int entryCount = buf.readVarInt();
            List<CodexSnapshotPayload.EntrySnap> entries = new ArrayList<>(entryCount);

            for (int e = 0; e < entryCount; e++) {
               Component entryTitle = (Component)ComponentSerialization.TRUSTED_STREAM_CODEC.decode(buf);
               int state = buf.readVarInt();
               int lineCount = buf.readVarInt();
               List<Component> lines = new ArrayList<>(lineCount);

               for (int l = 0; l < lineCount; l++) {
                  lines.add((Component)ComponentSerialization.TRUSTED_STREAM_CODEC.decode(buf));
               }

               entries.add(new CodexSnapshotPayload.EntrySnap(entryTitle, state, lines));
            }

            sections.add(new CodexSnapshotPayload.SectionSnap(sectionTitle, entries));
         }

         chapters.add(new CodexSnapshotPayload.ChapterSnap(chapterTitle, sections));
      }

      return new CodexSnapshotPayload(chapters);
   }

   public record ChapterSnap(Component title, List<CodexSnapshotPayload.SectionSnap> sections) {
   }

   public record EntrySnap(Component title, int state, List<Component> lines) {
   }

   public record SectionSnap(Component title, List<CodexSnapshotPayload.EntrySnap> entries) {
   }
}
