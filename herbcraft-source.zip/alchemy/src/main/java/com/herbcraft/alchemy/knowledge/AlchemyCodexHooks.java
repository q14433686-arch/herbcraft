package com.herbcraft.alchemy.knowledge;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.herbcraft.alchemy.HerbcraftAlchemy;
import com.herbcraft.knowledge.CodexLoot;
import com.herbcraft.knowledge.CodexLootRules;
import com.herbcraft.knowledge.PageKind;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents.Modify;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.SetComponentsFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;

public final class AlchemyCodexHooks {
   private static final List<CodexLootRules.PageInjection> ALCHEMY_RULES = CodexLootRules.load("data/herbcraft_alchemy/codex_loot_injections.json");
   private static final AlchemyCodexHooks.WitchLootRules WITCH_RULES = loadWitchLootRules();
   private static final ResourceKey<LootTable> WITCH_LOOT = ResourceKey.create(Registries.LOOT_TABLE, Identifier.fromNamespaceAndPath("minecraft", "entities/witch"));

   private AlchemyCodexHooks() {}

   public static void register() {
      LootTableEvents.MODIFY.register((Modify)(key, tableBuilder, source, registries) -> {
         if (!source.isBuiltin()) {
            return;
         }
         for (CodexLootRules.PageInjection rule : ALCHEMY_RULES) {
            if (rule.lootTable().equals(key)) {
               CodexLoot.addTatteredPagePool(tableBuilder, rule.chance(), rule.chapter(), rule.entry(), rule.kind());
            }
         }
         if (key.equals(WITCH_LOOT)) addWitchLoot(tableBuilder);
      });
   }

   private static void addWitchLoot(LootTable.Builder tableBuilder) {
      if (WITCH_RULES.page() != null) {
         CodexLoot.addTatteredPagePool(
            tableBuilder,
            WITCH_RULES.page().chance(),
            WITCH_RULES.page().chapter(),
            WITCH_RULES.page().entry(),
            WITCH_RULES.page().kind()
         );
      }
      if (WITCH_RULES.essenceChance() > 0.0F && !WITCH_RULES.essenceItems().isEmpty()) {
         LootPool.Builder pool = LootPool.lootPool().when(LootItemRandomChanceCondition.randomChance(WITCH_RULES.essenceChance()));
         WITCH_RULES.essenceItems().forEach(item -> pool.add(LootItem.lootTableItem(item)));
         tableBuilder.pool(pool.build());
      }
      if (WITCH_RULES.potionChance() > 0.0F && !WITCH_RULES.potions().isEmpty()) {
         LootPool.Builder pool = LootPool.lootPool().when(LootItemRandomChanceCondition.randomChance(WITCH_RULES.potionChance()));
         for (Holder<Potion> potion : WITCH_RULES.potions()) {
            pool.add(LootItem.lootTableItem(Items.POTION).apply(SetComponentsFunction.setComponent(DataComponents.POTION_CONTENTS, new PotionContents(potion))));
         }
         tableBuilder.pool(pool.build());
      }
   }

   private static WitchLootRules loadWitchLootRules() {
      try (InputStream input = AlchemyCodexHooks.class.getClassLoader().getResourceAsStream("data/herbcraft_alchemy/witch_loot.json")) {
         if (input == null) {
            throw new IllegalStateException("Missing data/herbcraft_alchemy/witch_loot.json");
         }
         JsonObject root = JsonParser.parseReader(new InputStreamReader(input, StandardCharsets.UTF_8)).getAsJsonObject();
         WitchPage page = null;
         if (root.has("page")) {
            JsonObject json = root.getAsJsonObject("page");
            page = new WitchPage(
               json.get("chance").getAsFloat(),
               json.has("chapter") ? json.get("chapter").getAsString() : "alchemy",
               json.has("entry") ? json.get("entry").getAsString() : "",
               json.has("page_kind") ? PageKind.valueOf(json.get("page_kind").getAsString().toUpperCase(Locale.ROOT)) : PageKind.TRADE
            );
         }
         float essenceChance = 0.0F;
         List<Item> essenceItems = new ArrayList<>();
         if (root.has("essence_pool")) {
            JsonObject json = root.getAsJsonObject("essence_pool");
            essenceChance = json.get("chance").getAsFloat();
            for (JsonElement element : json.getAsJsonArray("items")) {
               Identifier id = Identifier.parse(element.getAsString());
               Item item = BuiltInRegistries.ITEM.getValue(id);
               if (item != null) essenceItems.add(item);
            }
         }
         float potionChance = 0.0F;
         List<Holder<Potion>> potions = new ArrayList<>();
         if (root.has("potion_pool")) {
            JsonObject json = root.getAsJsonObject("potion_pool");
            potionChance = json.get("chance").getAsFloat();
            for (JsonElement element : json.getAsJsonArray("potions")) {
               Identifier id = Identifier.parse(element.getAsString());
               BuiltInRegistries.POTION.get(ResourceKey.create(Registries.POTION, id)).ifPresent(holder -> potions.add((Holder<Potion>)holder));
            }
         }
         HerbcraftAlchemy.LOGGER.info("Loaded Herbcraft Alchemy witch loot rules.");
         return new WitchLootRules(page, essenceChance, List.copyOf(essenceItems), potionChance, List.copyOf(potions));
      } catch (Exception e) {
         throw new RuntimeException("Failed to load herbcraft_alchemy witch_loot.json", e);
      }
   }

   private record WitchPage(float chance, String chapter, String entry, PageKind kind) {
   }

   private record WitchLootRules(WitchPage page, float essenceChance, List<Item> essenceItems, float potionChance, List<Holder<Potion>> potions) {
   }
}
