# CURRENT_BASELINE

This is the short authoritative anchor for the current Herbcraft working state. Every future agent turn that changes source, resources, docs, scripts, validation rules, versions, or release outputs must update this file before reporting completion.

## Current baseline

- Local baseline directory: `release_output/herbcraft_test_20260614_review/`
- Source archive: `release_output/herbcraft_test_20260614_review/herbcraft-source-current-20260614.zip`
- Current release/test version: `1.1.3`
- Minecraft: `26.1.2`
- Fabric Loader: `0.19.3+`
- Fabric API: `0.151.0+26.1.2+`
- Java: `25+`
- Gradle Wrapper: `9.4.1`
- Loom: `1.16-SNAPSHOT` resolving as `1.16.3`

## Current output files

The current local output set should contain:

- `herbcraft-1.1.3.jar`
- `herbcraft-alchemy-1.1.3.jar`
- `herbcraft-cuisine-1.1.3.jar`
- `herbcraft-source-current-20260614.zip`

Additional local test artifact:

- `herbcraft-p4-runtime-test-datapack-20260617.zip` — datapack for validating reload-safe P4 metadata integration; not a public release file.

`release_output/` is local/publishing-only and git-ignored. Public jars should be uploaded through GitHub Releases, not committed to the source repository. Do not use a directory literally named `output/`, because platform snapshots exclude it.

## Environment/cache notes

Do not delete useful build environment/cache state unless explicitly asked. In particular, preserve:

- Gradle caches where possible.
- `/tmp/herbcraft-jdk25` if present.
- `scripts/setup_jdk25_temurin.sh`.
- `reference_cache/26_1_porting_notes.md`.
- Current local `release_output/` baseline if it exists; it is git-ignored and regenerable.

If JDK 25 is missing, run:

```bash
bash scripts/setup_jdk25_temurin.sh
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
```

## Authoritative current facts

### Versioning

- `build.gradle` sets subproject version to `1.1.3`.
- Core `fabric.mod.json` version is `1.1.3`.
- Alchemy `fabric.mod.json` version is `1.1.3` and depends on `herbcraft >=1.1.3`.
- Cuisine `fabric.mod.json` version is `1.1.3` and depends on `herbcraft >=1.1.3`.

### Core

- Core mod ID: `herbcraft`.
- `herbs.json` drives 96 edible definitions. P3.10 raw edible food-roll rebalance is implemented: entries may define optional `food_rolls.nutrition` and `food_rolls.saturation`; 70 raw herb entries were tuned so common scenery/flowers/leaves/saplings use probabilistic visible hunger and/or direct hidden saturation instead of stable early food. Post-client tuning made seeds more substantial (`S+2` ordinary seeds, `S+3` melon/pumpkin seeds) and raised sugar cane to stable visible +1 with `saturation_modifier = 1.0` (about +2 hidden saturation). `minecraft:blue_orchid` no longer has a guaranteed `minecraft:saturation` effect.
- `herb_natures.json` covers 96 nature profiles.
- Herb Codex exists with knowledge states, rumors, claim marks, errata verification, and UI sync.
- `百草经总纲` is registered as `overview` in `HerbalChapter`.
- Jade/tooltip display is knowledge-gated.
- Nutrition is now based on custom Herbcraft effects, not vanilla negative effects.
- 食材录 / Ingredient Codex is data-driven by `data/herbcraft/ingredients.json` and contains 39 vanilla food entries. External 食材录 entries can now be added through `data/<namespace>/herbcraft/ingredients/*.json`; non-vanilla entries use namespace-aware Codex IDs to avoid collisions.
- `1.1.3` Codex guidance Phase 2.1/P3.7/P3.9 is implemented: guide entries under 百草经总纲 are data-backed by module-owned `codex_guides.json`; Core owns only Core guide pages while Cuisine/Alchemy own their addon guide pages. 五味/七情 guide lines reveal principle details from persisted player pharmacology discoveries rather than printing exact item nature in the guide. The 五味与性味 and 七情与配伍 guide pages now include plain beginner-facing microcopy explaining that 性味 is herb pharmacology rather than nutrition, and 七情 is recent-herb interaction rather than a fixed recipe list. One-time onboarding hints are data-backed by module-owned `guide_hints.json` files and persist seen IDs on player data. Cuisine/Alchemy now also have module-owned overview sections/sub-guide entries inside `膳房录` and `炼金要术`.
- Pharmacology qi/relation tuning is now data-backed: `pharmacology_rules.json` owns `temperature_values` and ordered `seven_emotion_rules`; current temperature values are cold -15, cool -8, neutral 0, warm 8, hot 15, and qi regresses by 5 every 600 ticks. Core Codex pharmacology guide microcopy has been clarified in both languages without adding new advancements.

### Nutrition current state

Seven Herbcraft nutrition effects exist:

- `herbcraft:grain_deficiency` / 谷气亏虚 / block break speed reduction.
- `herbcraft:flesh_deficiency` / 血肉亏虚 / attack damage reduction.
- `herbcraft:oil_deficiency` / 津脂不足 / movement speed reduction.
- `herbcraft:vege_deficiency` / 蔬素不足 / periodic exhaustion.
- `herbcraft:fruit_deficiency` / 津液不足 / light movement speed reduction. The former displayed “fruit” nutrition dimension is now presented as `津液` / `Fluids`.
- `herbcraft:dietary_imbalance` / 饮食失衡 / light movement speed reduction plus periodic exhaustion.
- `herbcraft:well_nourished` / 五养调和 / armor and knockback-resistance bonus.

Current nutrition behavior:

- Warning states remain light/probabilistic.
- Danger states below `malnutrition_low` are sustained until the next nutrition check interval.
- Starved state applies all five deficiency effects in sustained form.
- Confirmed dietary imbalance is grace-gated, then sustained unless recent meals are actively correcting the imbalance.
- Nutrition correction/recent-meal pass is implemented: the last 24 meals are tracked; the last 3600 ticks / 3 minutes form a correction scoring window; correction score threshold is 60; correction now uses `data/herbcraft/nutrition_correction_rules.json` relationship matrix; active correction applies extra high-dimension decay every 200 ticks by 15..45 until target 650. `fruit`/津液/Fluids is decoupled from the ordinary correction matrix: all ordinary fruit correction weights are `0.0`; high `fruit` is non-punitive in the base mod while low 津液 deficiency remains meaningful. The high-津液 surplus helper now requires at least two non-fruit dimensions above 850 that share a correction-matrix relationship (weight > 0 in either direction) before activating the -10/200t decay toward 700. A single excess dimension alone or two unrelated excess dimensions will not trigger fluid surplus decay.
- New client status `correcting` / `饮食回正中` exists for active correction.
- Water bowl keeps a 15% success chance and temporarily relieves dietary imbalance for 60 seconds without repairing nutrition values.
- `/herbcraft nutrition get|set|preset` debug commands exist and require gamemaster permission. Presets include `correcting_flesh`, `correcting_oil`, `correcting_grain`, `excess_fruit_nonpunitive`, `fluid_surplus_pair`, `fluid_surplus_single`, and `fluid_surplus_unrelated`.
- Nutrition effect mechanics and timing are data-backed by `data/herbcraft/nutrition_effects.json`. Nutrition dimension bands now use `NutritionRules` thresholds (`balancedMin`, `balancedMax`, `imbalanceHigh`) and punitive spread uses `imbalanceSpread`, so future JSON tuning is not bypassed by stale Java literals.
- `NutritionRules.loadFromBundledJson()` fallback for `correction_high_threshold` is now 750, matching `nutrition_rules.json` and `NutritionRules.defaults()`; validators guard against returning to old 850 fallback behavior.
- Nutrition effect icons are generated from vanilla item textures by `scripts/generate_nutrition_effect_icons.py`. The Nutrition panel now uses Codex-style trim/wrap/scissor safeguards so translated status/title/hint/label text cannot protrude outside the panel. English nutrition wording now uses `Greens` rather than `Vege` for the `vege` dimension.

### Cuisine

- Cuisine mod ID: `herbcraft_cuisine`.
- Cuisine depends on Core only.
- `dishes.json` currently defines 10 fixed dishes and 22 medicinal/hidden dishes.
- Water bowl exists and can temporarily relieve dietary imbalance on the same 15% success chance as vanilla nausea relief.
- `DishItem.clear_all_effects` skips Herbcraft nutrition effects.
- `HodgepodgeItem.clearPositiveEffects` skips Herbcraft nutrition effects.
- Hidden dishes exist in source and built jars:
  - `hundred_flower_feast`
  - `raw_hundred_flower_feast`
  - `deadly_hodgepodge`
  - `raw_deadly_hodgepodge`

### Alchemy

- Alchemy mod ID: `herbcraft_alchemy`.
- Alchemy depends on Core only.
- 40 current essence definitions are now data-backed by `data/herbcraft_alchemy/essences.json`.
- Static essence fields still exist for compatibility but initialize via `essenceFromJson(...)`.
- Extra essence definitions beyond the 40 compatibility fields are registered from `essences.json` at `AlchemyRegistries.initialize()` time; addons/data packs still need to provide recipes/assets/lang for polished extra entries.
- Potion bonus pools are data-backed by `data/herbcraft_alchemy/potion_bonus_pools.json`.
- Special/T3 potion definitions and the safe witch throw pool are data-backed by `data/herbcraft_alchemy/special_potions.json`.
- Witch loot is data-backed by `data/herbcraft_alchemy/witch_loot.json`.
- Weapon coating rules are data-backed by `data/herbcraft_alchemy/coating_rules.json`.
- Core/alchemy/cuisine Codex page loot injections are JSON-backed by each module's `codex_loot_injections.json`.
- `BrewingStandCatalystMixin.java` exists and builds.
- Hidden cuisine catalyst brewing source exists and preserves potion stack components by copying input stacks and setting only quality.

## Externalized data tables already done

The following formerly Java-hardcoded or partly Java-hardcoded systems are now JSON-backed:

- `data/herbcraft/special_counters.json`
- `data/herbcraft_cuisine/hodgepodge_rules.json`
- `data/herbcraft_alchemy/potion_bonus_pools.json`
- `data/herbcraft_alchemy/essences.json`
- `data/herbcraft/codex_loot_injections.json`
- `data/herbcraft_alchemy/codex_loot_injections.json`
- `data/herbcraft_cuisine/codex_loot_injections.json`
- `data/herbcraft_alchemy/special_potions.json`
- `data/herbcraft_alchemy/coating_rules.json`
- `data/herbcraft_alchemy/witch_loot.json`
- `data/herbcraft/nutrition_effects.json`
- `data/herbcraft/ingredients.json`
- `data/herbcraft/codex_guides.json`
- `data/herbcraft_cuisine/codex_guides.json`
- `data/herbcraft_alchemy/codex_guides.json`
- `data/herbcraft/guide_hints.json`
- `data/herbcraft_cuisine/guide_hints.json`
- `data/herbcraft_alchemy/guide_hints.json`
- `data/herbcraft/nutrition_correction_rules.json`
- `data/herbcraft/pharmacology_rules.json`
- `core/src/main/resources/data/herbcraft/nutrition_profiles.json` contains 162 nutrition profiles scaled to 0.6x for balanced pacing. `minecraft:milk_bucket` provides gentle flesh/oil nutrition (`flesh:14, oil:10`); `herbcraft_cuisine:water_bowl` provides trace fluids only (`fruit:5`).
- `data/herbcraft_cuisine/environment/drinkable/*.json` provides optional Homeostatic drinkable data for Cuisine custom edible outputs. Values are balanced against Homeostatic's 20-point water bar; water bowl is `amount 6 / saturation 1.2` with `85%` thirst-effect risk to prevent trivial infinite hydration.
- `data/herbcraft/environment/drinkable/*.json` provides optional Homeostatic drinkable data for selected Core/vanilla Herbcraft edible items not already covered by Homeostatic's known generated vanilla drinkables. Ice/snow/water-adjacent items give meaningful hydration; `minecraft:sugar_cane` is anchored at Homeostatic `amount 3 / saturation 0.5`; sweet/sticky/hot/toxic items use `amount 0` plus strong thirst-effect risk instead of negative hydration, because Homeostatic stores negative water internally without clamping to zero.
- First low-risk external extension merge layer is implemented for server data under `data/<namespace>/herbcraft/herb_natures/*.json`, `nutrition_profiles/*.json`, `ingredients/*.json`, `special_counters/*.json`, `knowledge_rumors/*.json`, and `codex_loot_injections/*.json`. Runtime support is in `ExternalDataResources`, `HerbcraftExternalDataReloadListener`, and the corresponding Core registries/managers. Server-authoritative nutrition profiles, nature profiles, and ingredient entry IDs sync to clients through `HerbcraftDataSyncPayload` / `HerbcraftDataSyncManager`. External `special_counters` now use dynamic per-player counter storage keyed by counter ID rather than four hardcoded counters.
- Startup-only external herb food registration is implemented for loaded Fabric mod/addon resources under `data/<namespace>/herbcraft/herbs/*.json`. It is scanned by `HerbFoodRegistry.loadExternalStartupResources()` during Herbcraft initialization before `DefaultItemComponentEvents.MODIFY` registration. It supports optional `food_rolls` fields for probabilistic visible hunger/direct hidden saturation settlement. It is **not** a world datapack `/reload` feature for changing FOOD/CONSUMABLE components.
- Food-mod compatibility draft work for Farmer's Delight Refabricated, More Delight, and Reg's More Foods is tracked in `docs/reports/EXTERNAL_INGREDIENTS_CLIENT_SYNC_GENERATOR_API_20260616.md`. Rounds 1-5 are complete for the current decision. Author client testing passed for Farmer's Delight Refabricated + More Delight, and RMF was removed due datapack-driven item identity / vanilla-item collision risk. Reference generated datapack is kept under `docs/compat_drafts/food_mods_26_1_2/generated_pack/`, sourced from `compat_review_round5_farmer_moredelight.csv`, with 108 nutrition profiles, 108 ingredient entries, 5 herb nature entries, and 0 knowledge rumors. It is reference material only; the published route is built-in Core compat in `1.1.3`, because older jars do not have the food-nature bridge. The same Farmer+More data is bundled into Herbcraft Core under `data/farmers_moredelight_herbcraft/herbcraft/`, and a generic food-nature pharmacology bridge lets explicit nature+nutrition ordinary foods participate in pharmacology without overriding target mod food components. 百草志 registers these nature-bearing foods under `药食志` after tasting, while 食材录 keeps nutrition. Food-nature items are also wired into Herbcraft item tooltips, Jade item/entity display, and the 五味/七情 guide discovery counters.
- P4.1-P4.5 are complete for the read/event extension boundary. `docs/JSON_EXTENSION_SPEC_1_1_3.md` is the authoritative JSON schema/boundary reference, `HerbcraftDataAPI` exposes read-only Java queries, `HerbcraftEvents` exposes observational events, examples live under `docs/examples/`, and `docs/reports/P4_EXTENSION_READINESS_1_1_3_20260617.md` summarizes 1.1.3 extension readiness. Java write/registration APIs remain deferred. `docs/reports/DATAPACK_RUNTIME_COMPAT_VERIFICATION_20260617.md` records the final source-level verification that reload-safe datapack metadata can integrate with recognition, UI/display, nutrition, food-nature pharmacology, and external special counters when the required surfaces are present.

Validator:

```bash
python3 scripts/validate_externalized_rules.py
```

## Current key validators

Run these after meaningful changes:

```bash
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
python3 scripts/check_lang_diff.py
python3 scripts/validate_custom_nutrition_effects_phase8.py
python3 scripts/validate_nutrition_correction_phase.py
python3 scripts/validate_externalized_rules.py
python3 scripts/validate_raw_herb_food_balance.py
python3 scripts/validate_essence_resources.py
python3 scripts/validate_homeostatic_compat.py
python3 scripts/validate_nutrition_cuisine_immunity_isolation.py
python3 scripts/validate_recipe_isolation.py
python3 scripts/validate_item_textures.py
python3 scripts/validate_task_abcd.py
python3 scripts/validate_extended_features.py
python3 scripts/validate_trade_tags.py
python3 scripts/validate_external_extension_spec.py
python3 scripts/validate_animal_food_tags.py
python3 scripts/validate_catalyst_mixin.py
python3 scripts/validate_nature_jade.py
python3 scripts/validate_p1_codex_advancements.py
python3 scripts/verify_built_jars.py
```

`validate_animal_food_tags.py` now searches the explicit `/home/user/cache/minecraft/client-26.1.2.jar`, Loom's downloaded client/merged jars, or `HERBCRAFT_VANILLA_CLIENT_JAR`. Run a Gradle build first if no vanilla jar cache exists.

## Known remaining work / do not confuse with completed work

Not yet done:

- Author reported local real-client validation passed for the previously requested nutrition, Codex/Jade/UI, brewing catalyst, and related smoke checks with no visible bugs/conflicts.
- Further real-client validation is still useful after future changes, especially for any new dynamic essence/resource-generation work.
- Round-1 Homeostatic compatibility for Herbcraft Cuisine custom edible outputs is implemented as optional data under `data/herbcraft_cuisine/environment/drinkable/` and guarded by `scripts/validate_homeostatic_compat.py`.
- Round-2 Homeostatic compatibility for selected Core/vanilla Herbcraft edible items is implemented as optional data under `data/herbcraft/environment/drinkable/`, with Homeostatic's known vanilla drinkable items intentionally avoided to reduce duplicate/override risk.
- Fully data-driven automatic asset/recipe/lang generation for additional dynamic essences. Current dynamic support registers extra essence items/potions from JSON, but external resource/data files are still needed for a polished addon entry.
- `scripts/generate_essence_resources.py` and `scripts/validate_essence_resources.py` now implement/check the first project-local essence resource generation step.
- `scripts/generate_essence_resources.py` also supports `--scaffold-extension` for one-off standalone essence extension scaffolds, including optional wandering trader trade and Codex rumor skeletons. Scaffold mode now supports multiple source items through `--sources`, optional `--no-trade` / `--no-codex` switches, and `--check-extension` validation for generated or third-party scaffold directories.
- `docs/examples/essence_extension_example/` provides an example essence extension layout.
- `docs/EXTENDING_HERBCRAFT.md` documents the current extension surface and limitations. `docs/PUBLIC_EXTENSION_API_DESIGN.md` records the P4 Java API design draft; it is not an implemented stable API yet.
- `docs/DOCUMENTATION_INDEX.md` maps current authoritative docs versus historical reports/release-copy snapshots so future agents do not anchor to stale files.
- `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` now tracks P1/P2/P3/P4 external extension planning and current implementation status.
- `docs/HOMEOSTATIC_TEMPERATURE_COMPAT_NOTES.md` records P1 Homeostatic temperature research. No Homeostatic temperature gameplay integration is implemented yet.
- `docs/examples/external_extension_compat_pack/` and `scripts/validate_external_extension_spec.py` provide the first example/validator for the P2 external merge layer.
- `docs/examples/startup_herb_food_extension_mod/` provides an example layout for P3 startup-only herb food extension resources.
- `docs/reports/P2_EXTERNAL_DATAPACK_SMOKE_20260615.md` records the successful P2 external datapack server smoke test and the resolved pack metadata warning.
- `docs/reports/P3_STARTUP_HERB_FOOD_SMOKE_20260615.md` records the successful P3 temporary mod startup herb food server smoke test.
- `docs/reports/EXTENSION_CONSISTENCY_REVIEW_20260615.md` records the post-P2/P3 consistency review and next-round recommendation.
- `docs/reports/P3_CLIENT_TEST_CHECKLIST_20260615.md` gives the author a concrete real-client test table for the generated P3 startup food test addon.
- Author reported the P3 real-client test passed fully: the test item was edible/functional, residual page and Herb Codex entries worked, and the item appeared normally in 奇材志 with expected description/lines.
- `docs/reports/NUTRITION_FLUIDS_DESIGN_REVIEW_20260615.md` records the current analysis-only review of the 津液/Fluids excess design issue discovered during survival testing.
- `release_output/herbcraft_test_20260614_review/herbcraft-p3-startup-food-test-addon-1.0.0.jar` is a generated test addon from `docs/examples/startup_herb_food_extension_mod/`; it is not a public release jar.
- `docs/EXTENSION_GENERATOR_PLAN.md` remains the planning reference for future generator/API work and is updated with current implementation status.
- P4 stable Java extension events/API remains deferred and should not be presented as implemented. P3 is implemented only for loaded Fabric mod/addon startup resources, not hot-reloadable world datapacks. External P3 herb items do not automatically gain tag membership; addons should provide item tags if they want tag-based systems such as hodgepodge to accept them.
- Nutrition correction B+E hybrid is implemented, not just discussed. It tracks recent meals and uses amount-weighted correction score to relieve dietary imbalance and accelerate excessive-dimension decay. High 津液/Fluids is non-punitive in the base mod; low 津液 deficiency remains meaningful.
- Historical correction-speed concern has been addressed by the current 750 correction threshold plus 15..45 per-10s decay range and graduated half-speed behavior for 750-849. Real-client tuning is still useful, but do not quote the old 4..12 or 12/10s timing as current.
- `docs/reports/NUTRITION_CORRECTION_NEXT_IMPLEMENTATION_SPEC_20260615.md` records the design spec, `docs/reports/NUTRITION_CORRECTION_TUNING_MATRIX_PROPOSAL_20260615.md` records the matrix/timing proposal, and `docs/reports/NUTRITION_CORRECTION_IMPLEMENTATION_REPORT_20260615.md` records the implemented matrix tuning: dimension-specific correction matrix, stronger 15..45 per-10s decay, and high-津液 surplus normalization of other excesses toward 700.
- Correction stacking issue is fixed in source/build: `correctionScore` no longer requires the correcting dimension's stored value to be below `correctionTargetValue` 650, and matrix decay plus high-津液 surplus decay are computed from original tick values and stacked before applying. In high flesh + high vege + high fruit scenarios, valid recent matrix meals can now stack with the high-津液 -10 helper instead of being filtered out.
- Coupling issue is fixed in source/build: ordinary correction-matrix `fruit`/津液 weights are now all `0.0`, so fruit-bearing foods no longer suppress `DIETARY_IMBALANCE` through the ordinary correction matrix. 津液 remains active only as low-deficiency, non-punitive high storage, and high-津液 surplus helper (requires at least two related non-fruit excess dimensions before activating decay toward 700). See `docs/reports/NUTRITION_FLUIDS_CORRECTION_COUPLING_REVIEW_20260615.md`.
- P3.10 raw Herbcraft edible hunger/saturation rebalance is implemented in source/build and guarded by `scripts/validate_raw_herb_food_balance.py`. A client-feedback pass strengthened seeds and sugar cane after the first rollout felt too weak. It still needs real-client retesting, especially stronger seeds, sugar cane +1 visible/about +2 hidden saturation with Homeostatic amount 3, raw kelp short relief, common forage spam, and leaves at full hunger. Core pharmacology guide microcopy has also been clarified in the Codex rather than adding extra advancements. Cuisine hidden-catalyst Codex wording now explicitly says Alchemy linkage requires the Alchemy chapter/module (`炼金分册` / `Alchemy chapter`).
- Documentation/source consistency audit is recorded in `docs/reports/DOCS_AND_SOURCE_CONSISTENCY_AUDIT_20260616.md`; it updated current handoff docs, marked historical docs, and fixed data-backed nutrition threshold/spread usage in Java.

Do not redo completed work unless a new bug is observed.

## Per-turn rule

At the end of every future turn that changes the project, update this file with:

1. What changed this turn.
2. Whether output jars/source zip were updated.
3. Which validations were run.
4. Any new remaining risks.

If this file is not updated after a modifying turn, the next agent may anchor to stale state. That is considered a serious workflow error.

## Last updated

- Date: 2026-06-18
- Change: Role alignment frozen per user instruction (User: Lead Game Planner / Design Architect; Agent: Lead Professional Mod Developer executing 100% of codebase, AST verifications, and Gradle operations). Addressed vital technical errata regarding the item registry matching logic (`resolveHerbalItemId`): fully documented that traversal operates entirely in RAM (`Local RAM Memory`) within the JVM, executing zero network requests and causing zero lag or TPS regressions (`0.01ms` on-demand execution). Transitioned to Yansheng (`严生`) Mode B kickoff, soliciting Planner's acceptance criteria for visual UI concepts, pathological wound/temp interactions, and explicit requests for immediate Fabric subproject provisioning. E.g. fully validated AST/AST logic and automated test suite. Authored `docs/reports/GAME_PLANNER_AND_DEVELOPER_COLLABORATION_SPEC_20260618.md`.
- Output updated: no source code or jar content changed this turn; source archive (`herbcraft-source-current-20260614.zip`) refreshed to include the grand collaboration spec.
- Validations/checks this turn: Gradle build passed successfully (`BUILD SUCCESSFUL`). `validate_codex_hitboxes.py`, `check_lang_diff.py`, `validate_custom_nutrition_effects_phase8.py`, `validate_nutrition_correction_phase.py`, `validate_externalized_rules.py`, `validate_raw_herb_food_balance.py`, `validate_essence_resources.py`, `validate_homeostatic_compat.py`, `validate_nutrition_cuisine_immunity_isolation.py`, `validate_recipe_isolation.py`, `validate_item_textures.py`, `validate_task_abcd.py`, `validate_extended_features.py`, `validate_trade_tags.py`, `validate_external_extension_spec.py`, `validate_animal_food_tags.py`, `validate_catalyst_mixin.py`, `validate_p1_codex_advancements.py`, `validate_nature_jade.py`, and `verify_built_jars.py` — all passed 100%.
- Remaining risks: Client testing needed to confirm: (1) errata options and claim marks are fully interactive and update correctly upon click; (2) Light/Dark theme toggle and readability; (3) item icons and nature flavor tags rendering in Codex; (4) interactive scrollbars; (5) Farmer+More built-in compat integration; (6) P3.10 raw herb probability rolls and seed/sugarcane survival feel. Awaiting user/Planner creative specifications for Yansheng design and subproject setup.

### Previous update

- Date: 2026-06-18
- Change: Identified and fixed a major UI logic bug in `CodexScreen.java` where clicking on errata (勘误) options / claim marks produced no reaction in-game. Root cause: `maxRightScroll(...)` called `contentHeight(...)` which contained an erroneous `this.claimHitboxes.clear()` call, wiping out all claim hitboxes at the end of every rendering frame and during `mouseClicked` evaluations. Fixed by removing `this.claimHitboxes.clear()` from `contentHeight`, implementing robust multi-line wrapped hitbox height computation in `renderRightPanel`, and adding strict screen-area scissor bounds checks in `mouseClicked`. Authored `docs/reports/CODEX_CLAIM_HITBOX_BUGFIX_20260618.md` and added `scripts/validate_codex_hitboxes.py`. E.g. fully verified environment setup, AST/AST logic, and automated validation suite.
- Output updated: yes. All three jars (`herbcraft-1.1.3.jar`, `herbcraft-alchemy-1.1.3.jar`, `herbcraft-cuisine-1.1.3.jar`) and source zip (`herbcraft-source-current-20260614.zip`) rebuilt and refreshed.
- Validations/checks this turn: Gradle build passed successfully (`BUILD SUCCESSFUL`). `validate_codex_hitboxes.py`, `check_lang_diff.py`, `validate_custom_nutrition_effects_phase8.py`, `validate_nutrition_correction_phase.py`, `validate_externalized_rules.py`, `validate_raw_herb_food_balance.py`, `validate_essence_resources.py`, `validate_homeostatic_compat.py`, `validate_nutrition_cuisine_immunity_isolation.py`, `validate_recipe_isolation.py`, `validate_item_textures.py`, `validate_task_abcd.py`, `validate_extended_features.py`, `validate_trade_tags.py`, `validate_external_extension_spec.py`, `validate_animal_food_tags.py`, `validate_catalyst_mixin.py`, `validate_p1_codex_advancements.py`, `validate_nature_jade.py`, and `verify_built_jars.py` — all passed.
- Remaining risks: Client testing needed to confirm: (1) errata options and claim marks are fully interactive and update correctly upon click; (2) Light/Dark theme toggle and readability; (3) item icons and nature flavor tags rendering in Codex; (4) interactive scrollbars; (5) Farmer+More built-in compat integration; (6) P3.10 raw herb probability rolls and seed/sugarcane survival feel. Awaiting user confirmation for the next development action.

### Previous update

- Date: 2026-06-17
- Change: UI data-driven Layer 1+2 implementation. Layer 1: Added `codex_theme.json`, `nutrition_theme.json`, `CodexTheme.java`, `NutritionTheme.java`, and theme reload listener. All hardcoded UI constants now read from JSON. Layer 2: Extended `CodexSnapshotPayload.EntrySnap` with `itemId`, `temperature`, `flavors` fields; added item icon rendering and nature flavor tag rendering in the Codex right panel (both disabled by default, enable in theme JSON). Refactored `CodexScreen.java` and `NutritionPanelScreen.java` to use theme. Nutrition panel supports dynamic dimension count with auto-scaling. All new features disabled by default to preserve current visual behavior. Author decisions recorded in `docs/reports/DECISIONS_UI_AND_HARDCORE_MOD_20260617.md`.
- Output updated: yes. All three jars rebuilt and refreshed. Source zip refreshed.
- Validations/checks this turn: Gradle build passed. `check_lang_diff.py`, `validate_externalized_rules.py`, `validate_external_extension_spec.py`, `validate_nutrition_correction_phase.py`, `validate_p1_codex_advancements.py`, `validate_raw_herb_food_balance.py`, `validate_custom_nutrition_effects_phase8.py`, `validate_nature_jade.py`, `validate_catalyst_mixin.py`, `verify_built_jars.py` — all passed.
- Remaining risks: Client testing needed to confirm: (1) item icons render correctly next to entry titles across all chapters; (2) nature flavor tags display with correct colors; (3) scrollbars work on both panels; (4) completion badge counts are accurate; (5) nutrition panel threshold marks are visible. Before public upload, do final release text/platform review. Next step: art direction discussion with author → AI texture generation → beautification activation.

### Previous update

- Date: 2026-06-17
- Change: Deep discussion on UI data-driven architecture, Codex beautification spec, and hardcore mod direction. Added `docs/reports/UI_DATADRIVEN_AND_HARDCORE_MOD_DEEP_DISCUSSION_20260617.md` with three-layer data-driven UI plan (theme JSON / component registry / declarative layout), pixel-level Codex texture/layout spec (10+ textures, item icons, nature tags, breadcrumb, scrollbar, search), hardcore mod positioning (recommended: independent core mod `严生` + Herbcraft compat bridge, not pure addon), health slider concept (0-100, 5 anchor zones), seasonal herb interaction, and cocoa_fat confirmed as placeholder only. No source code or jars changed.
- Output updated: no. Documentation/report-only pass; jars and source zip unchanged from the previous validated state.
- Validations/checks this turn: `check_lang_diff.py`, `validate_externalized_rules.py`, `validate_external_extension_spec.py`, `validate_nutrition_correction_phase.py`, `validate_p1_codex_advancements.py`, `validate_raw_herb_food_balance.py` — all passed. `generate_agent_brief.py --write` regenerated. No build needed (no source changes).
- Remaining risks: Before public upload, the author should do final release text/platform review. UI data-driven conversion and Codex beautification are recommended for 1.2.0 but not blockers for 1.1.3 release. Hardcore mod architecture (Mode B: independent core + bridge) requires separate project setup when ready to proceed.
