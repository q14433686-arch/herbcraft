# AI_ONBOARDING

This is the mandatory entry document for the next AI agent working on Herbcraft.

## Absolute first step

Before editing code, you must:

1. Read these files:
   - `README.md`
   - `AI_ONBOARDING.md`
   - `PROJECT_STATE.md`
   - `NEXT_TASK.md`
   - `CHANGE_IMPACT.md`
   - `BUGS_TODO.md`
   - `SOURCE_REVIEW_2026-06-14.md` if present
   - `docs/PROJECT_SUMMARY.md` if present, but treat it as historical context because parts are now stale.
2. Inspect the actual source tree and resources. Do **not** trust old TODO/NEXT notes, chat summaries, or release jars blindly.
3. Produce a **接手状态报告** using the template below.
4. Wait for the author to confirm before coding, unless the author explicitly says to proceed immediately.

## Locked environment

- Minecraft `26.1.2`
- Fabric Loader `0.19.3`
- Fabric API `0.151.0+26.1.2`
- Java `25`
- Gradle Wrapper `9.4.1`
- Fabric Loom `1.16-SNAPSHOT` / resolves as `1.16.3`
- Mojang official mappings

If the sandbox lacks JDK 25, use:

```bash
bash scripts/setup_jdk25_temurin.sh
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
```

26.1 notes are cached in:

- `reference_cache/26_1_porting_notes.md`

## Output/baseline convention

The current test baseline is kept under:

```text
release_output/herbcraft_test_20260614_review/
```

It should contain exactly the current useful release set:

- `herbcraft-1.1.0.jar`
- `herbcraft-alchemy-1.1.0.jar`
- `herbcraft-cuisine-1.1.0.jar`
- `herbcraft-source-current-20260614.zip`

The platform excludes directories named `output`, so use `release_output/`. Keep only one current baseline unless the author explicitly asks for N/N-1 retention.

## Three design philosophies

1. **Stable IDs are sacred.** Do not rename existing IDs casually.
2. **Information is earned.** Tooltips, Jade, Codex pages, rumors, claim marks, recipe hints, and usage hints must respect knowledge tiers.
3. **Modules must remain independent.** Core must not depend on alchemy or cuisine; addons depend on core only.

## Absolute architecture rules

- No old `TradeOfferHelper`; use 26.1 data-driven villager trade JSON and tags.
- No full vanilla loot table replacement; use Fabric loot events and guard with `source.isBuiltin()`.
- No hard dependency on Jade/REI unless optional compat setup is intentional.
- Do not use deprecated `appendHoverText`; use current tooltip APIs such as Fabric item tooltip callbacks.
- Do not scatter important balance constants as random Java literals when they belong in JSON/config. If temporary Java constants are used, document them and add validators.
- For brewing, remember: vanilla/Fabric `addMix` can reset output stack components. If preserving components, copy the input `ItemStack` and modify only the intended component.
- Nutrition effects are now custom Herbcraft `MobEffect`s. Do not reintroduce vanilla `WEAKNESS`, `SLOWNESS`, `MINING_FATIGUE`, `HUNGER`, `NAUSEA`, or hidden `RESISTANCE` as NutritionManager's core state effects.
- Cuisine/medicine clearing must not remove Herbcraft nutrition effects. Use `HerbcraftMobEffects.isNutritionEffect(...)` checks.

## Current important state

### Core nutrition system

Nutrition has been heavily updated in this test baseline:

- Seven Herbcraft nutrition effects exist:
  - `herbcraft:grain_deficiency` / 谷气亏虚
  - `herbcraft:flesh_deficiency` / 血肉亏虚
  - `herbcraft:oil_deficiency` / 津脂不足
  - `herbcraft:vege_deficiency` / 蔬素不足
  - `herbcraft:fruit_deficiency` / 津液不足
  - `herbcraft:dietary_imbalance` / 饮食失衡
  - `herbcraft:well_nourished` / 五养调和
- NutritionManager uses those custom effects instead of vanilla negative effects.
- Serious malnutrition (`< malnutrition_low`) and starved states are sustained until the next nutrition check interval, not random short flashes.
- Warning states remain light/probabilistic.
- `well_nourished` replaces the old hidden vanilla resistance reward and currently gives `+3 armor` and `+12% knockback resistance` through attributes.
- Water bowl still has only 15% success chance; on success it clears vanilla nausea and temporarily relieves `dietary_imbalance` for 60 seconds without repairing nutrition values.
- Debug commands exist: `/herbcraft nutrition get|set|preset ...` and require gamemaster permission.
- Nutrition icons are generated from vanilla item textures by `scripts/generate_nutrition_effect_icons.py`.

### Verified current source state

- Hidden cuisine dishes exist in source and built jars.
- `BrewingStandCatalystMixin.java` exists and builds.
- `herbcraft_alchemy.mixins.json` currently references classes that exist.
- `百草经总纲` is registered in `HerbalChapter`, not only in lang files.
- A core server smoke reaches `Done` with the current nutrition changes.

## Required 接手状态报告 format

```md
# 接手状态报告

## 1. 我已阅读的文件
- README.md
- AI_ONBOARDING.md
- PROJECT_STATE.md
- NEXT_TASK.md
- CHANGE_IMPACT.md
- BUGS_TODO.md
- SOURCE_REVIEW_2026-06-14.md
- docs/PROJECT_SUMMARY.md
- 其他：...

## 2. 当前环境确认
- Minecraft:
- Fabric Loader:
- Fabric API:
- Java:
- Gradle/Loom:

## 3. 当前源码真实状态
### core
- ...
### alchemy
- ...
### cuisine
- ...

## 4. 我发现的风险点 / 明显不一致
- ...

## 5. 我建议下一步做什么
- ...

## 6. 开始编码前需要作者确认的问题
- ...
```

## Minimum validation commands before releasing

```bash
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
python3 scripts/check_lang_diff.py
python3 scripts/validate_custom_nutrition_effects_phase8.py
python3 scripts/validate_nutrition_cuisine_immunity_isolation.py
python3 scripts/validate_recipe_isolation.py
python3 scripts/validate_item_textures.py
python3 scripts/validate_task_abcd.py
python3 scripts/validate_extended_features.py
python3 scripts/validate_trade_tags.py
python3 scripts/verify_built_jars.py
```

`validate_animal_food_tags.py` may fail in sandboxes without `/home/user/cache/minecraft/client-26.1.2.jar`; either provide that cache or update the validator to use Loom's downloaded client jar.

Do not claim success if required checks were not run or if they fail.
