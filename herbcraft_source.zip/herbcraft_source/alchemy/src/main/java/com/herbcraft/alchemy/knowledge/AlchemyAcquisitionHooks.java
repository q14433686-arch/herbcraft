package com.herbcraft.alchemy.knowledge;

import com.herbcraft.alchemy.coating.CoatingComponents;
import com.herbcraft.alchemy.coating.WeaponCoating;
import com.herbcraft.alchemy.registry.AlchemyRegistries;
import com.herbcraft.api.KnowledgeManager;
import com.herbcraft.api.KnowledgeAPI.State;
import com.herbcraft.knowledge.KnowledgeInventoryScanner;
import java.util.Optional;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.alchemy.PotionContents;

public final class AlchemyAcquisitionHooks {
   private AlchemyAcquisitionHooks() {
   }

   public static void register() {
      KnowledgeInventoryScanner.registerHandler(AlchemyAcquisitionHooks::onStack);
   }

   private static void onStack(ServerPlayer player, ItemStack stack) {
      Optional<AlchemyRegistries.EssenceInfo> essence = AlchemyRegistries.essenceInfo(stack.getItem());
      if (essence.isPresent()) {
         String id = essence.get().id();
         KnowledgeManager.unlock(player, "alchemy", "essence_" + id, State.MASTERED);
         KnowledgeManager.unlock(player, "alchemy", "potion_" + id, State.HEARD);
      } else {
         PotionContents contents = (PotionContents)stack.get(DataComponents.POTION_CONTENTS);
         if (contents != null) {
            contents.potion().flatMap(holder -> holder.unwrapKey()).ifPresent(key -> {
               if ("herbcraft".equals(key.identifier().getNamespace())) {
                  String potionName = key.identifier().getPath();
                  String base = stripModifierSuffix(potionName);
                  KnowledgeManager.unlock(player, "alchemy", "potion_" + base, State.MASTERED);
               }
            });
         }

         WeaponCoating coating = (WeaponCoating)stack.get(CoatingComponents.WEAPON_COATING);
         if (coating != null) {
            KnowledgeManager.unlock(player, "alchemy", "coating_" + coating.essenceId(), State.MASTERED);
         }
      }
   }

   private static String stripModifierSuffix(String potionName) {
      for (String suffix : new String[]{"_long", "_strong", "_clarified", "_murky"}) {
         if (potionName.endsWith(suffix)) {
            return potionName.substring(0, potionName.length() - suffix.length());
         }
      }

      return potionName;
   }
}
