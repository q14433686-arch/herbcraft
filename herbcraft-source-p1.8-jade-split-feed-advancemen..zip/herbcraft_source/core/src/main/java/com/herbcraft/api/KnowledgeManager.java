package com.herbcraft.api;

import com.herbcraft.advancement.HerbcraftAdvancements;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.crafting.Recipe;

public final class KnowledgeManager {
   private KnowledgeManager() {
   }

   public static void awardRecipes(ServerPlayer player, List<ResourceKey<Recipe<?>>> keys) {
      if (!keys.isEmpty()) {
         player.awardRecipesByKey(keys);
      }
   }

   public static boolean unlock(ServerPlayer player, String chapterId, String entryId, KnowledgeAPI.State target) {
      if (target == KnowledgeAPI.State.UNKNOWN) {
         return false;
      } else {
         KnowledgeAPI.Chapter chapter = KnowledgeAPI.chapter(chapterId).orElse(null);
         if (chapter == null) {
            return false;
         } else {
            KnowledgeAPI.Entry entry = chapter.entry(entryId);
            if (entry == null) {
               return false;
            } else {
               KnowledgeAPI.State current = KnowledgeAPI.state(player, chapterId, entry);
               if (current.ordinal() >= target.ordinal()) {
                  return false;
               } else {
                  KnowledgeAPI.knowledge(player).put(chapterId + "/" + entryId, target.ordinal());
                  awardKnowledgeAdvancements(player, chapterId, target);
                  String key = target == KnowledgeAPI.State.MASTERED ? "message.herbcraft.knowledge.mastered" : "message.herbcraft.knowledge.heard";
                  player.sendOverlayMessage(Component.translatable(key, new Object[]{entry.title().copy().withStyle(ChatFormatting.GREEN)}));
                  return true;
               }
            }
         }
      }
   }

   private static void awardKnowledgeAdvancements(ServerPlayer player, String chapterId, KnowledgeAPI.State target) {
      if (target == KnowledgeAPI.State.HEARD) HerbcraftAdvancements.grant(player, "first_page");
      if (target == KnowledgeAPI.State.MASTERED) {
         HerbcraftAdvancements.grant(player, "master_first_entry");
         int mastered = 0;
         int herbalTotal = 0;
         int herbalMastered = 0;
         for (KnowledgeAPI.Chapter chapter : KnowledgeAPI.chapters()) {
            for (KnowledgeAPI.Entry knownEntry : chapter.entries()) {
               if ("overview".equals(knownEntry.id())) continue;
               KnowledgeAPI.State state = KnowledgeAPI.state(player, chapter.id(), knownEntry);
               if (state == KnowledgeAPI.State.MASTERED) {
                  mastered++;
                  if ("herbal".equals(chapter.id())) herbalMastered++;
               }
               if ("herbal".equals(chapter.id())) herbalTotal++;
            }
         }
         if (mastered >= 25) HerbcraftAdvancements.grant(player, "master_25_entries");
         if (herbalTotal > 0 && herbalMastered >= herbalTotal) HerbcraftAdvancements.grant(player, "master_all_core");
      }
   }

}
