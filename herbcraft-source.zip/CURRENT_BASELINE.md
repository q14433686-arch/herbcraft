# CURRENT_BASELINE

This is the short authoritative anchor for the current Herbcraft working state. Every future agent turn that changes source, resources, docs, scripts, validation rules, versions, or release outputs must update this file before reporting completion.

## Current baseline

- Baseline directory: `release_output/herbcraft_test_20260614_review/`
- Source archive: `release_output/herbcraft_test_20260614_review/herbcraft-source-current-20260614.zip`
- Current release/test version: `1.1.1`
- Minecraft: `26.1.2`
- Fabric Loader: `0.19.3+`
- Fabric API: `0.151.0+26.1.2+`
- Java: `25+`
- Gradle Wrapper: `9.4.1`
- Loom: `1.16-SNAPSHOT` resolving as `1.16.3`

## Current output files

The current output set should contain:

- `herbcraft-1.1.1.jar`
- `herbcraft-alchemy-1.1.1.jar`
- `herbcraft-cuisine-1.1.1.jar`
- `herbcraft-source-current-20260614.zip`

Optional client-test artifact currently present in the same directory:

- `herbcraft-p3-startup-food-test-addon-1.0.0.jar` — test addon only, not a public Herbcraft release jar.

Do not use an `output/` directory because platform snapshots exclude directories named `output`. Use `release_output/`.

## Environment/cache notes

Do not delete useful build environment/cache state unless explicitly asked. In particular, preserve:

- Gradle caches where possible.
- `/tmp/herbcraft-jdk25` if present.
- `scripts/setup_jdk25_temurin.sh`.
- `reference_cache/26_1_porting_notes.md`.
- Current `release_output/` baseline.

If JDK 25 is missing, run:

```bash
bash scripts/setup_jdk25_temurin.sh
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
```

## Authoritative current facts

### Versioning

- `build.gradle` sets subproject version to `1.1.1`.
- Core `fabric.mod.json` version is `1.1.1`.
- Alchemy `fabric.mod.json` version is `1.1.1` and depends on `herbcraft >=1.1.1`.
- Cuisine `fabric.mod.json` version is `1.1.1` and depends on `herbcraft >=1.1.1`.

### Core

- Core mod ID: `herbcraft`.
- `herbs.json` drives 96 edible definitions.
- `herb_natures.json` covers 96 nature profiles.
- Herb Codex exists with knowledge states, rumors, claim marks, errata verification, and UI sync.
- `百草经总纲` is registered as `overview` in `HerbalChapter`.
- Jade/tooltip display is knowledge-gated.
- Nutrition is now based on custom Herbcraft effects, not vanilla negative effects.

### Nutrition current state

Seven Herbcraft nutrition effects exist:

- `herbcraft:grain_deficiency` / 谷气亏虚 / block break speed reduction.
- `herbcraft:flesh_deficiency` / 血肉亏虚 / attack damage reduction.
- `herbcraft:oil_deficiency` / 津脂不足 / movement speed reduction.
- `herbcraft:vege_deficiency` / 蔬素不足 / periodic exhaustion.
- `herbcraft:fruit_deficiency` / 津液不足 / light movement speed reduction. The former displayed “fruit” nutrition dimension is now presented as `津液` / `Fluids`.
- `herbcraft:dietary_imbalance` / 饮食失衡 / light movement speed reduction plus periodic exhaustion.
- `herbcraft:well_nourished` / 五养调和 / armor and knockback-resistance bonus.

Current nutrition behavior:

- Warning states remain light/probabilistic.
- Danger states below `malnutrition_low` are sustained until the next nutrition check interval.
- Starved state applies all five deficiency effects in sustained form.
- Confirmed dietary imbalance is grace-gated, then sustained unless recent meals are actively correcting the imbalance.
- Nutrition correction/recent-meal pass is implemented: the last 24 meals are tracked; the last 3600 ticks / 3 minutes form a correction scoring window; correction score threshold is 60; correction now uses `data/herbcraft/nutrition_correction_rules.json` relationship matrix; active correction applies extra high-dimension decay every 200 ticks by 15..45 until target 650. `fruit`/津液/Fluids is decoupled from the ordinary correction matrix: all ordinary fruit correction weights are `0.0`; high `fruit` is non-punitive in the base mod while low 津液 deficiency remains meaningful. The high-津液 surplus helper now requires at least two non-fruit dimensions above 850 that share a correction-matrix relationship (weight > 0 in either direction) before activating the -10/200t decay toward 700. A single excess dimension alone or two unrelated excess dimensions will not trigger fluid surplus decay.
- New client status `correcting` / `饮食回正中` exists for active correction.
- Water bowl keeps a 15% success chance and temporarily relieves dietary imbalance for 60 seconds without repairing nutrition values.
- `/herbcraft nutrition get|set|preset` debug commands exist and require gamemaster permission. Presets include `correcting_flesh`, `correcting_oil`, `correcting_grain`, `excess_fruit_nonpunitive`, `fluid_surplus_pair`, `fluid_surplus_single`, and `fluid_surplus_unrelated`.
- Nutrition effect mechanics and timing are data-backed by `data/herbcraft/nutrition_effects.json`.
- Nutrition effect icons are generated from vanilla item textures by `scripts/generate_nutrition_effect_icons.py`.

### Cuisine

- Cuisine mod ID: `herbcraft_cuisine`.
- Cuisine depends on Core only.
- `dishes.json` currently defines 10 fixed dishes and 22 medicinal/hidden dishes.
- Water bowl exists and can temporarily relieve dietary imbalance on the same 15% success chance as vanilla nausea relief.
- `DishItem.clear_all_effects` skips Herbcraft nutrition effects.
- `HodgepodgeItem.clearPositiveEffects` skips Herbcraft nutrition effects.
- Hidden dishes exist in source and built jars:
  - `hundred_flower_feast`
  - `raw_hundred_flower_feast`
  - `deadly_hodgepodge`
  - `raw_deadly_hodgepodge`

### Alchemy

- Alchemy mod ID: `herbcraft_alchemy`.
- Alchemy depends on Core only.
- 40 current essence definitions are now data-backed by `data/herbcraft_alchemy/essences.json`.
- Static essence fields still exist for compatibility but initialize via `essenceFromJson(...)`.
- Extra essence definitions beyond the 40 compatibility fields are registered from `essences.json` at `AlchemyRegistries.initialize()` time; addons/data packs still need to provide recipes/assets/lang for polished extra entries.
- Potion bonus pools are data-backed by `data/herbcraft_alchemy/potion_bonus_pools.json`.
- Special/T3 potion definitions and the safe witch throw pool are data-backed by `data/herbcraft_alchemy/special_potions.json`.
- Witch loot is data-backed by `data/herbcraft_alchemy/witch_loot.json`.
- Weapon coating rules are data-backed by `data/herbcraft_alchemy/coating_rules.json`.
- Core/alchemy/cuisine Codex page loot injections are JSON-backed by each module's `codex_loot_injections.json`.
- `BrewingStandCatalystMixin.java` exists and builds.
- Hidden cuisine catalyst brewing source exists and preserves potion stack components by copying input stacks and setting only quality.

## Externalized data tables already done

The following formerly Java-hardcoded or partly Java-hardcoded systems are now JSON-backed:

- `data/herbcraft/special_counters.json`
- `data/herbcraft_cuisine/hodgepodge_rules.json`
- `data/herbcraft_alchemy/potion_bonus_pools.json`
- `data/herbcraft_alchemy/essences.json`
- `data/herbcraft/codex_loot_injections.json`
- `data/herbcraft_alchemy/codex_loot_injections.json`
- `data/herbcraft_cuisine/codex_loot_injections.json`
- `data/herbcraft_alchemy/special_potions.json`
- `data/herbcraft_alchemy/coating_rules.json`
- `data/herbcraft_alchemy/witch_loot.json`
- `data/herbcraft/nutrition_effects.json`
- `data/herbcraft/ingredients.json`
- `data/herbcraft/nutrition_correction_rules.json`
- `data/herbcraft/pharmacology_rules.json`
- `core/src/main/resources/data/herbcraft/nutrition_profiles.json` contains 162 nutrition profiles scaled to 0.6x for balanced pacing. `minecraft:milk_bucket` provides gentle flesh/oil nutrition (`flesh:14, oil:10`); `herbcraft_cuisine:water_bowl` provides trace fluids only (`fruit:5`).
- `data/herbcraft_cuisine/environment/drinkable/*.json` provides optional Homeostatic drinkable data for Cuisine custom edible outputs. Values are balanced against Homeostatic's 20-point water bar; water bowl is `amount 6 / saturation 1.2` with `85%` thirst-effect risk to prevent trivial infinite hydration.
- `data/herbcraft/environment/drinkable/*.json` provides optional Homeostatic drinkable data for selected Core/vanilla Herbcraft edible items not already covered by Homeostatic's known generated vanilla drinkables. Ice/snow/water-adjacent items give meaningful hydration; sweet/sticky/hot/toxic items use `amount 0` plus strong thirst-effect risk instead of negative hydration, because Homeostatic stores negative water internally without clamping to zero.
- First low-risk external extension merge layer is implemented for server data under `data/<namespace>/herbcraft/herb_natures/*.json`, `nutrition_profiles/*.json`, `special_counters/*.json`, `knowledge_rumors/*.json`, and `codex_loot_injections/*.json`. Runtime support is in `ExternalDataResources`, `HerbcraftExternalDataReloadListener`, and the corresponding Core registries/managers.
- Startup-only external herb food registration is implemented for loaded Fabric mod/addon resources under `data/<namespace>/herbcraft/herbs/*.json`. It is scanned by `HerbFoodRegistry.loadExternalStartupResources()` during Herbcraft initialization before `DefaultItemComponentEvents.MODIFY` registration. It is **not** a world datapack `/reload` feature for changing FOOD/CONSUMABLE components.

Validator:

```bash
python3 scripts/validate_externalized_rules.py
```

## Current key validators

Run these after meaningful changes:

```bash
JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks
python3 scripts/check_lang_diff.py
python3 scripts/validate_custom_nutrition_effects_phase8.py
python3 scripts/validate_nutrition_correction_phase.py
python3 scripts/validate_externalized_rules.py
python3 scripts/validate_essence_resources.py
python3 scripts/validate_homeostatic_compat.py
python3 scripts/validate_nutrition_cuisine_immunity_isolation.py
python3 scripts/validate_recipe_isolation.py
python3 scripts/validate_item_textures.py
python3 scripts/validate_task_abcd.py
python3 scripts/validate_extended_features.py
python3 scripts/validate_trade_tags.py
python3 scripts/validate_external_extension_spec.py
python3 scripts/verify_built_jars.py
```

`validate_animal_food_tags.py` may need a vanilla client jar cache and is not always runnable in the sandbox without extra setup.

## Known remaining work / do not confuse with completed work

Not yet done:

- Author reported local real-client validation passed for the previously requested nutrition, Codex/Jade/UI, brewing catalyst, and related smoke checks with no visible bugs/conflicts.
- Further real-client validation is still useful after future changes, especially for any new dynamic essence/resource-generation work.
- Round-1 Homeostatic compatibility for Herbcraft Cuisine custom edible outputs is implemented as optional data under `data/herbcraft_cuisine/environment/drinkable/` and guarded by `scripts/validate_homeostatic_compat.py`.
- Round-2 Homeostatic compatibility for selected Core/vanilla Herbcraft edible items is implemented as optional data under `data/herbcraft/environment/drinkable/`, with Homeostatic's known vanilla drinkable items intentionally avoided to reduce duplicate/override risk.
- Fully data-driven automatic asset/recipe/lang generation for additional dynamic essences. Current dynamic support registers extra essence items/potions from JSON, but external resource/data files are still needed for a polished addon entry.
- `scripts/generate_essence_resources.py` and `scripts/validate_essence_resources.py` now implement/check the first project-local essence resource generation step.
- `scripts/generate_essence_resources.py` also supports `--scaffold-extension` for one-off standalone essence extension scaffolds, including optional wandering trader trade and Codex rumor skeletons. Scaffold mode now supports multiple source items through `--sources`, optional `--no-trade` / `--no-codex` switches, and `--check-extension` validation for generated or third-party scaffold directories.
- `docs/examples/essence_extension_example/` provides an example essence extension layout.
- `docs/EXTENDING_HERBCRAFT.md` documents the current extension surface and limitations.
- `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` now tracks P1/P2/P3/P4 external extension planning and current implementation status.
- `docs/HOMEOSTATIC_TEMPERATURE_COMPAT_NOTES.md` records P1 Homeostatic temperature research. No Homeostatic temperature gameplay integration is implemented yet.
- `docs/examples/external_extension_compat_pack/` and `scripts/validate_external_extension_spec.py` provide the first example/validator for the P2 external merge layer.
- `docs/examples/startup_herb_food_extension_mod/` provides an example layout for P3 startup-only herb food extension resources.
- `docs/reports/P2_EXTERNAL_DATAPACK_SMOKE_20260615.md` records the successful P2 external datapack server smoke test and the resolved pack metadata warning.
- `docs/reports/P3_STARTUP_HERB_FOOD_SMOKE_20260615.md` records the successful P3 temporary mod startup herb food server smoke test.
- `docs/reports/EXTENSION_CONSISTENCY_REVIEW_20260615.md` records the post-P2/P3 consistency review and next-round recommendation.
- `docs/reports/P3_CLIENT_TEST_CHECKLIST_20260615.md` gives the author a concrete real-client test table for the generated P3 startup food test addon.
- Author reported the P3 real-client test passed fully: the test item was edible/functional, residual page and Herb Codex entries worked, and the item appeared normally in 奇材志 with expected description/lines.
- `docs/reports/NUTRITION_FLUIDS_DESIGN_REVIEW_20260615.md` records the current analysis-only review of the 津液/Fluids excess design issue discovered during survival testing.
- `release_output/herbcraft_test_20260614_review/herbcraft-p3-startup-food-test-addon-1.0.0.jar` is a generated test addon from `docs/examples/startup_herb_food_extension_mod/`; it is not a public release jar.
- `docs/EXTENSION_GENERATOR_PLAN.md` remains the planning reference for future generator/API work and is updated with current implementation status.
- P4 stable Java extension events/API remains deferred and should not be presented as implemented. P3 is implemented only for loaded Fabric mod/addon startup resources, not hot-reloadable world datapacks. External P3 herb items do not automatically gain tag membership; addons should provide item tags if they want tag-based systems such as hodgepodge to accept them.
- Nutrition correction B+E hybrid is implemented, not just discussed. It tracks recent meals and uses amount-weighted correction score to relieve dietary imbalance and accelerate excessive-dimension decay. High 津液/Fluids is non-punitive in the base mod; low 津液 deficiency remains meaningful.
- Author reports the correction configuration is active and has no obvious bug, but current correction speed is too slow. Current implemented timing from 1000 to 650 is approximately 10.9 minutes at threshold score 60, 7.0 minutes at score 160, and 4.7 minutes at the current max cap 12/10s; this is too slow for survival pacing.
- `docs/reports/NUTRITION_CORRECTION_NEXT_IMPLEMENTATION_SPEC_20260615.md` records the design spec, `docs/reports/NUTRITION_CORRECTION_TUNING_MATRIX_PROPOSAL_20260615.md` records the matrix/timing proposal, and `docs/reports/NUTRITION_CORRECTION_IMPLEMENTATION_REPORT_20260615.md` records the implemented matrix tuning: dimension-specific correction matrix, stronger 15..45 per-10s decay, and high-津液 surplus normalization of other excesses toward 700.
- Correction stacking issue is fixed in source/build: `correctionScore` no longer requires the correcting dimension's stored value to be below `correctionTargetValue` 650, and matrix decay plus high-津液 surplus decay are computed from original tick values and stacked before applying. In high flesh + high vege + high fruit scenarios, valid recent matrix meals can now stack with the high-津液 -10 helper instead of being filtered out.
- Coupling issue is fixed in source/build: ordinary correction-matrix `fruit`/津液 weights are now all `0.0`, so fruit-bearing foods no longer suppress `DIETARY_IMBALANCE` through the ordinary correction matrix. 津液 remains active only as low-deficiency, non-punitive high storage, and high-津液 surplus helper (requires at least two related non-fruit excess dimensions before activating decay toward 700). See `docs/reports/NUTRITION_FLUIDS_CORRECTION_COUPLING_REVIEW_20260615.md`.

Do not redo completed work unless a new bug is observed.

## Per-turn rule

At the end of every future turn that changes the project, update this file with:

1. What changed this turn.
2. Whether output jars/source zip were updated.
3. Which validations were run.
4. Any new remaining risks.

If this file is not updated after a modifying turn, the next agent may anchor to stale state. That is considered a serious workflow error.

## Last updated

- Date: 2026-06-16
- Change: Fixed typo "食材録" (Japanese 録) → "食材录" (Chinese 录) across 8 documentation files. Verified no other wrong kanji, no stale threshold values, no inconsistent naming. All lang files already had the correct character.
- Output updated: yes. Source zip refreshed. Jars unchanged (no code changes).
- Last known validations: all 15 passed in previous sub-turn; no code changes since.
  - Rules confirmed from three sources:
    - `PROJECT_SUMMARY.md` 铁律 #1: "`herbs.json` 是草药数值唯一真相源" — JSON is the single source of truth for content data.
    - `PROJECT_SUMMARY.md` 铁律 #4: "任何数值不得以字面量散落在 Java 里" — no balance constants as Java literals.
    - `README.md`: "Data first, code second."
    - `DATA_DRIVEN_ARCHITECTURE.md`: "Java owns mechanics; JSON owns content, balance values."
  - Verified: all content data (herb definitions, nutrition profiles, correction weights, ingredients chapter entries, essences, dishes, counters, effects, etc.) are JSON-driven. Java contains only mechanism code, fallback defaults (matching JSON values), and structural IDs.
  - The only violation found and fixed in this session was `IngredientsChapter.java` hardcoding 39 items — now refactored to `ingredients.json`.
  - Updated docs: `PROJECT_STATE.md` (ingredients chapter, 0.6x scaling, threshold 750, fluid surplus), `AI_ONBOARDING.md` (ingredients chapter + nutrition tuning sections), `README.md` (core module description), `BUGS_TODO.md` (data-driven table list, recent fixes, validation list), `NEXT_TASK.md` (current recommended task), `CHANGE_IMPACT.md` (ingredients chapter checklist), `CHANGELOG.md` (2026-06-16 entries), `docs/EXTENDING_HERBCRAFT.md` (ingredients.json), `docs/DATA_DRIVEN_ARCHITECTURE.md` (ingredients.json row), `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` (P3.5, 0.6x note, surplus condition, internal file list).
- Output updated: yes. Source zip refreshed with all documentation updates. Jars unchanged (no code changes this sub-turn).
  - Created `data/herbcraft/ingredients.json` with `schema_version`, `sections` list, and 39 `entries` (each with `item` and `section`).
  - Rewrote `IngredientsChapter.java` to load entirely from JSON via `loadFromJson()`. Zero `Items.*` references remain. Adding/removing/reclassifying foods is now a pure JSON edit.
  - Mechanism code unchanged: `NutritionManager.onFoodConsumed()` hook, inventory scanner hook, `NutritionItemTooltips` gating — these remain Java because they are mechanics, not content.
  - `ingredients.json` is now the 18th data-driven JSON file in the project.
- Output updated: yes. BUILD SUCCESSFUL, all 15 validators passed. Jars and source zip refreshed.
- Last known validations: Gradle build, language diff, custom nutrition phase8, nutrition correction, externalized rules, nutrition/cuisine immunity isolation, recipe isolation, item textures, task ABCD, extended features, trade tags, essence resources, Homeostatic compat, external extension spec, animal food tags, and built jar verification — all 15 passed. `ingredients.json` confirmed present in built core jar.
  - **Bug 1 (tooltip不显示)**: `NutritionItemTooltips` checks `KnowledgeClientCache.state("ingredients", path)`, requiring state ≥ 4 (MASTERED). But `displayState()` determines state from `KnowledgeFlags` (encountered/heard/tasted/practiced), NOT from the Entry's `mastered()` predicate. Since nothing ever calls `markTasted`/`markEncountered`/`markPracticed` for ingredients entries, flags are always empty → state is always UNKNOWN(0) → tooltip never shows.
  - **Bug 2 (百草经不显示条目)**: Same root cause. `KnowledgeSyncPayload.buildStates()` calls `KnowledgeAPI.displayState()` which reads `KnowledgeFlags`. Since no code marks flags for ingredients entries, all entries are synced as UNKNOWN → CodexScreen shows them as "???" or hidden.
  - **Bug 3 (吃了也不认识)**: `EffectResolver.markTasted` only runs for items in `HerbFoodRegistry`. Vanilla foods (cooked_beef etc.) are NOT in `HerbFoodRegistry`, so eating them never triggers any knowledge flag update for the ingredients chapter.
  - **Root cause summary**: IngredientsChapter registered entries with `mastered = hasEaten()` predicate, but `displayState()` ignores Entry predicates entirely — it only reads `KnowledgeFlags` which must be set by explicit `KnowledgeAPI.mark*()` calls. The chapter needs a hook into vanilla food consumption to call `markTasted`/`markEncountered` for ingredients entries.
  - **Fix applied**:
    1. Added `IngredientsChapter.hasEntry(path)` static query method.
    2. In `NutritionManager.onFoodConsumed()`: when a food with an ingredients entry is consumed, calls `markEncountered` + `markTasted` + `markPracticed` → `displayState()` returns MASTERED → Codex shows nutrition, tooltip shows nutrition.
    3. In `Herbcraft.java` KnowledgeInventoryScanner handler: also marks `encountered` for ingredients items when they enter inventory → Codex shows the item as ENCOUNTERED (name visible, but "尚未品尝" until eaten).
    4. In `NutritionItemTooltips.java`: lowered threshold from state≥4 to state≥3 (TASTED or MASTERED) for vanilla food tooltip display.
  - Full knowledge lifecycle for ingredients items: pick up → ENCOUNTERED (name visible in Codex, no nutrition) → eat → MASTERED (nutrition visible in Codex + tooltip).
- Output updated: yes. BUILD SUCCESSFUL, all 15 validators passed. Jars and source zip refreshed.
  - Analyzed the problem of nutrition values rising too fast (6 cooked_beef from 50% to 91%).
  - Computed scaling options (0.4x/0.5x/0.6x/current) against vanilla eating pace.
  - Author approved 0.6x. Applied to all 162 nutrition profiles in `nutrition_profiles.json`.
  - Before: `cooked_beef` flesh=69 → 4 eats to correction threshold (750), 6 eats to excess (850).
  - After: `cooked_beef` flesh=41 → 7 eats to correction, 9 eats to excess. 30 min of only-steak eating stays at ~69%.
  - Updated `validate_custom_nutrition_effects_phase8.py` to match new water_bowl (`fruit:5`) and milk_bucket (`flesh:14, oil:10`) values.
- Output updated: yes. Rebuilt (BUILD SUCCESSFUL). All three jars and source zip refreshed.
- Last known validations: Gradle build, all 15 validators passed.
  - Fixed `correcting_grain`/`correcting_flesh`/`correcting_oil` presets: non-target dimensions were 400-450 (40%-45%), now 500-550 (50%-55%) to represent a natural "one thing excess" state.
  - No other same-type bugs found (systematic review of all 22 presets confirmed).
  - Updated `NEXT_TASK.md`: added fluid surplus presets to test list, updated surplus helper description to reflect correction-matrix relationship requirement.
  - Updated `CURRENT_BASELINE.md`: preset list now includes `fluid_surplus_pair/single/unrelated`, surplus helper description updated.
  - Updated `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md`: surplus helper condition already updated in prior turn.
  - Confirmed no stale descriptions remain in `AI_ONBOARDING.md`, `PROJECT_STATE.md`, `CHANGE_IMPACT.md`, or `BUGS_TODO.md`.
  - **Lowered `correction_high_threshold` from 850 to 750** in both `nutrition_rules.json` and `NutritionRules.defaults()`. This fixes the "dead zone" where dimensions at 750-849 (75%-84%) had zero accelerated correction — only passive -2/min applied, taking ~95 minutes to decay from 840 to 650. Now the matrix correction system activates at 750+, so eating corrective foods (e.g. vege to reduce flesh) works in this range.
  - **Graduated decay**: `correctionDecayAmount` now halves the decay rate when the dimension is below `imbalanceHigh` (850). So 750-849 gets half-speed correction (~8/10s) while 850+ keeps full-speed (~15/10s). This prevents the newly-lowered threshold from making moderate excess disappear too fast.
  - Punitive debuffs (`hasPunitiveImbalance`) still require `> imbalanceHigh` (850) — unchanged.
  - Fluid surplus still requires `>= fluidSurplusThreshold` (850) — unchanged.
  - Updated `scripts/validate_nutrition_correction_phase.py` to expect threshold 750.
- Output updated: yes. Rebuilt (BUILD SUCCESSFUL). All three jars and source zip refreshed.
- Last known validations: Gradle build, all 15 validators passed.
  1. Added `data/herbcraft/nutrition_correction_rules.json` and `data/herbcraft/pharmacology_rules.json` to `docs/DATA_DRIVEN_ARCHITECTURE.md`, `PROJECT_STATE.md`, `CURRENT_BASELINE.md` externalized tables list, and `docs/EXTENDING_HERBCRAFT.md`. These two data-driven JSON files were already in source but not documented.
  2. Deleted redundant `core/src/main/resources/data/herbcraft/tags/items/` directory (plural `items/` is the old MC path; 26.1 uses singular `tags/item/`). Content was identical duplicates of `tags/item/edible_saplings.json` and `tags/item/edible_seeds.json`.
  3. Fixed `NutritionRules.defaultCorrectionWeights()` Java fallback defaults to match current `nutrition_correction_rules.json`: all `fruit` weights changed from non-zero (0.35/0.80/0.80/0.40) to `0.0` to stay in sync with the 津液 decoupling change. This only affects the fallback path when JSON loading fails.
- Output updated: yes. `JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks` passed (BUILD SUCCESSFUL). Copied `herbcraft-1.1.1.jar`, `herbcraft-alchemy-1.1.1.jar`, `herbcraft-cuisine-1.1.1.jar` into `release_output/herbcraft_test_20260614_review/`. Regenerated `herbcraft-source-current-20260614.zip` (1196 files, includes all source, docs, scripts, resources). Verified `tags/items/` absent from built jar; `tags/item/` correct.
  4. Expanded `reference_cache/26_1_porting_notes.md` with comprehensive 26.1 API details.
  5. Copied Loom's merged MC jar to `/home/user/cache/minecraft/client-26.1.2.jar` for `validate_animal_food_tags.py`.
  6. **Fluid surplus helper condition tightening**: Modified `PlayerNutritionState` so that the high-津液 surplus decay (fruit >= 850, other dims > 850, -10/200t toward 700) now requires at least two non-fruit excess dimensions that share a correction-matrix relationship (weight > 0 in `nutrition_correction_rules.json`). Previously it unconditionally decayed *any* non-fruit dimension above 850. Now: single excess dim → no decay; two unrelated excess dims (e.g. flesh + oil, which have 0.0 weight in both directions) → no decay; two related excess dims (e.g. flesh + vege, which have 1.6/1.2 weights) → both decay. This prevents the surplus helper from activating in cases where the excess has no structural basis for correction.
  7. Added three debug presets: `fluid_surplus_pair` (flesh+vege+fruit=900, should activate), `fluid_surplus_single` (flesh+fruit=900, should NOT activate), `fluid_surplus_unrelated` (flesh+oil+fruit=900, should NOT activate).
  8. Updated `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` with the new fluid surplus condition.
- Output updated: yes. Rebuilt with `JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks` (BUILD SUCCESSFUL). All three jars and source zip refreshed in `release_output/herbcraft_test_20260614_review/`.
- Last known validations: Gradle build, language diff, custom nutrition phase8, nutrition correction, externalized rules, essence resources, Homeostatic compat, nutrition/cuisine immunity isolation, recipe isolation, item textures, task ABCD, extended features, trade tags, external extension spec, built jar verification, and animal food tags — all 15 passed.

### Previous update

- Date: 2026-06-15
- Change: Implemented 津液/Fluids decoupling from the ordinary correction matrix. Updated `data/herbcraft/nutrition_correction_rules.json` so every ordinary matrix `fruit` weight is `0.0` for grain/flesh/oil/vege correction. 津液 now remains active only as low-fluids deficiency, non-punitive high storage, and the special high-津液 surplus helper toward 700. Updated `scripts/validate_nutrition_correction_phase.py` expectations and related docs/reports, including `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md`, `docs/reports/NUTRITION_FLUIDS_CORRECTION_COUPLING_REVIEW_20260615.md`, and `docs/reports/NUTRITION_CORRECTION_IMPLEMENTATION_REPORT_20260615.md`.
- Output updated: yes, rebuilt jars, copied current `1.1.1` jars into `release_output/herbcraft_test_20260614_review/`, and refreshed `herbcraft-source-current-20260614.zip`. The optional test-only addon jar remains present.
- Last known validations: `JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew --no-daemon build --rerun-tasks` passed. Then language diff, custom nutrition phase8, nutrition correction validator, externalized rules, essence resources, Homeostatic compat, nutrition/cuisine immunity isolation, recipe isolation, item textures, task ABCD, extended features, trade tags, external extension spec validator, and built jar verification all passed.
