# CHANGELOG

## 2026-06-16 1.1.2 packaging and Cuisine catalyst wording

### Changed

- Bumped all three modules from `1.1.1` to `1.1.2` in Gradle and `fabric.mod.json`; Alchemy/Cuisine now depend on `herbcraft >=1.1.2`.
- Updated `scripts/verify_built_jars.py` for the `1.1.2` jar names and metadata.
- Updated current handoff/docs to describe the source line as packaged `1.1.2` while preserving the required source zip name `herbcraft-source-current-20260614.zip`.
- Clarified the Cuisine Codex page `隐秘菜肴与炼金催化` / `Hidden Meals and Catalysts`: alchemy catalyst linkage now explicitly says the Alchemy chapter/module must be present (`炼金分册` / `Alchemy chapter`).
- Strengthened `validate_p1_codex_advancements.py` so the Cuisine hidden catalyst guide keeps that Alchemy-module requirement visible in both Chinese and English.

### Validation

- Gradle build passed with Java 25. Full validator suite passed, including updated Cuisine hidden-catalyst wording validation and built-jar verification for `1.1.2` metadata/resources/classes.

## 2026-06-16 documentation/source consistency audit

### Added

- Added `docs/DOCUMENTATION_INDEX.md` to separate current authoritative docs from historical reports/release-copy snapshots.
- Added `docs/reports/DOCS_AND_SOURCE_CONSISTENCY_AUDIT_20260616.md` recording the documentation and source audit pass.

### Changed

- Updated current handoff and planning docs (`README.md`, `AI_ONBOARDING.md`, `PROJECT_STATE.md`, `NEXT_TASK.md`, `BUGS_TODO.md`, `CHANGE_IMPACT.md`, `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md`, `docs/HOMEOSTATIC_COMPAT.md`, `docs/NEW_PLAYER_GUIDANCE_1_1_2_DESIGN.md`, and roadmap docs) so they no longer describe implemented P3.10/Codex guidance work as pending.
- Marked historical documents and release-copy snapshots with clear warnings so future maintainers do not treat old design notes as current source truth.
- Tightened nutrition rule consistency: `NutritionManager` now uses `NutritionRules.balancedMin`, `balancedMax`, and `imbalanceHigh` for dimension bands; `PlayerNutritionState` now uses `NutritionRules.imbalanceSpread` instead of a hardcoded `500`. Removed the old unused `applyFluidSurplusDecay` helper.
- Strengthened validators so new Codex guide line2 text and data-backed nutrition thresholds/spread are guarded.

### Validation

- Gradle build passed with Java 25. Full validator suite passed, including updated nutrition correction consistency validation, Codex guide validation, raw herb balance validation, Homeostatic compat validation, language parity, and built-jar verification.

## 2026-06-16 Codex pharmacology guide microcopy

### Changed

- Added plain beginner-facing explanatory lines to the Core Codex guide pages `五味与性味` / `Nature and Flavors` and `七情与配伍` / `Relations Between Herbs`.
- The new wording clarifies that 性味 is not nutrition: heat/cold can accumulate or harmonize, while flavors gently adjust effect chance, duration, strength, and side effects.
- The 七情 wording now says directly that relations are short-window interactions between recently eaten herbs, not a fixed recipe list, and that triggered relations leave recent examples in the Codex.
- Kept this guidance inside the Codex rather than adding new advancements, preserving advancements as route signs and the Codex as the teaching surface.

### Validation

- Gradle build passed with Java 25. Full validator suite passed, including language parity, P1 Codex guide validation, and built-jar verification.

## 2026-06-16 seed and sugar cane food-roll feel tuning

### Changed

- Increased seed hidden-saturation roll amounts after client testing showed the first P3.10 values were too weak: wheat/beetroot/torchflower seeds now roll `S+2.0`, while melon/pumpkin seeds roll `S+3.0` to reflect their oilier identity.
- Increased `minecraft:pitcher_pod` stable saturation modifier to `1.0`, making its stable +1 visible hunger feel like a rarer pod rather than a barely lasting nibble.
- Increased `minecraft:sugar_cane` saturation modifier to `1.0`: it still restores only +1 visible hunger, but now gives about +2 hidden saturation points.
- Confirmed current Homeostatic sugar cane hydration data is already `amount 3`; updated `validate_homeostatic_compat.py` to anchor this value so it cannot regress to 1.
- Added `docs/reports/HERB_FOOD_SEED_SUGARCANE_TUNING_20260616.md`.

### Validation

- Gradle build passed with Java 25. Full validator suite passed, including updated raw herb food balance validation and Homeostatic sugar cane hydration anchor.

## 2026-06-16 raw herb food-roll rebalance implementation

### Added

- Added data-backed `food_rolls` support to Herbcraft herb food definitions. `food_rolls.nutrition` adds probabilistic visible hunger after vanilla consumption, while `food_rolls.saturation` adds direct hidden saturation with vanilla-style clamping to the current food level.
- Added `scripts/validate_raw_herb_food_balance.py` to guard the P3.10 raw forage balance and verify Java support, JSON roll shape, exact tuned values, common-forage no-stable-visible rules, and the blue orchid saturation-effect fix.
- Added `docs/reports/HERB_FOOD_ROLLS_IMPLEMENTATION_REPORT_20260616.md` documenting the implementation and exact balance classes.

### Changed

- Rebalanced 70 raw Herbcraft edible entries in `data/herbcraft/herbs.json` according to the approved probability direction: wildflowers, petals, ferns, common flowers, leaves, saplings, seeds, aquatic plants, sugar/fiber plants, sticky materials, and selected foodlike exceptions.
- Very common scenery/forage now mostly has `nutrition = 0`, `saturation_modifier = 0.0`, and small probability rolls instead of stable visible hunger.
- Leaves and sticky materials now lean toward hidden-saturation rolls rather than visible hunger.
- Sugar cane and raw kelp remain stable visible-hunger exceptions, but with very low stable saturation.
- Removed the guaranteed `minecraft:saturation` effect from `minecraft:blue_orchid` so it no longer bypasses the food-roll balance model.

### Validation

- Gradle build passed with Java 25. Full validator suite passed, including `scripts/validate_raw_herb_food_balance.py`, language parity, nutrition/correction/externalized rules, Homeostatic compat, recipe/item checks, trade tags, P1 Codex validation, and built-jar verification.

## 2026-06-16 raw herb probability parameter review

### Documented

- Added `docs/reports/HERB_FOOD_PROBABILITY_PARAMETER_REVIEW_20260616.md` and `docs/reports/raw_herb_food_current_values_20260616.csv` after re-checking current raw herb food source, nutrition profiles, herb natures, and 26.1 `FoodData` / `SaturationMobEffect` behavior.
- Refined the raw Herbcraft hunger/saturation rebalance from broad classes into per-item probability ranges, distinguishing scenery nibble, fiber forage, common flowers, seeds, aquatic raw plants, quick sugar, sticky fullness, medicinal-only, and bulk/processed exceptions.
- Recorded that `minecraft:saturation` effects on `minecraft:blue_orchid` and `minecraft:dried_kelp_block` must be considered in any later food-roll implementation, because they restore visible food outside base `nutrition` / `saturation_modifier`.
- No code or gameplay data implementation in this turn.

## 2026-06-16 raw herb hunger/saturation balance review

### Documented

- Added `docs/reports/HERB_FOOD_HUNGER_SATURATION_REBALANCE_REVIEW_20260616.md` after source-auditing `herbs.json`, `HerbFoodRegistry`, `HerbEntry`, and the post-consumption settlement flow.
- Identified common forage classes whose stable visible hunger may undermine early survival food progression: wildflowers, petals, ferns, leaves, saplings, seeds, and some aquatic plants.
- Proposed a data-backed `food_rolls` model for probabilistic visible hunger and/or hidden saturation restoration while keeping existing `nutrition` / `saturation_modifier` as stable vanilla base values.
- Recommended first implementation batches and validator coverage, while deferring hard-core multi-dimension fluid/vitamin/mineral/fiber split to a future addon.

## 2026-06-16 Cuisine/Alchemy module guide implementation

### Added

- Added module-owned overview guide entries inside `膳房录` and `炼金要术` using the existing data-backed `codex_guides.json` system.
- Cuisine now has `overview` guide entries for: 膳房总述, 水碗与药膳, 固定菜与准备, 百草盅, 清除与免疫, 隐秘菜肴与炼金催化.
- Alchemy now has `overview` guide entries for: 炼金总述, 精华, 草药药水, 澄清与浊化, 品质与余韵, 武器淬层, 女巫与浊毒.

### Changed

- `膳房与药膳` and `炼金与精华` remain short gateway pages under `百草经总纲`; the deeper route teaching now lives in each module's own chapter.
- Module guide pages use existing advancement completion and representative entry knowledge state for staged clarity without adding new save data or revealing hidden recipes too early.

### Validation

- Gradle build and full validator suite passed.

## 2026-06-16 Cuisine/Alchemy guide copy spec

### Documented

- Added `docs/reports/CUISINE_ALCHEMY_GUIDE_COPY_PHASE3_9_SPEC_20260616.md` after deeper source/recipe review of Cuisine and Alchemy.
- The spec keeps `膳房与药膳` and `炼金与精华` as short gateway pages under 百草经总纲, and proposes module-owned overview sections/sub-guide entries inside `膳房录` and `炼金要术`.
- Proposed staged, non-spoiling copy for Cuisine topics: 膳房总述, 水碗与药膳, 固定菜与准备, 百草盅, 清除与免疫, 隐秘菜肴与炼金催化.
- Proposed staged, non-spoiling copy for Alchemy topics: 炼金总述, 精华, 草药药水, 澄清与浊化, 品质与余韵, 武器淬层, 女巫与浊毒.

## 2026-06-16 Cuisine/Alchemy guidance direction discussion

### Documented

- Added `docs/reports/CUISINE_ALCHEMY_GUIDANCE_DIRECTION_20260616.md` after checking current Cuisine/Alchemy guide, hint, advancement, and chapter source.
- Recommended keeping `膳房与药膳` / `炼金与精华` as short gateway pages under 百草经总纲, while adding module-owned overview sections and guide subentries inside `膳房录` and `炼金要术` if more guidance is desired.
- Updated `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` to track this as P3.9 discussion/spec candidate.

## 2026-06-16 pharmacology temperature/relation data pass

### Added

- Added data-backed `temperature_values` to `data/herbcraft/pharmacology_rules.json`. Current values: `cold -15`, `cool -8`, `neutral 0`, `warm 8`, `hot 15`.
- Added data-backed ordered `seven_emotion_rules` to `pharmacology_rules.json`, preserving the current relation priority while allowing future tuning without Java edits.

### Changed

- `PharmacologyResolver` now reads temperature values and 七情 relation conditions/priority from `PharmacologyRules` instead of hardcoding them.
- Tuned qi regression interval from `1200` ticks to `600` ticks. Exact hot/cold now builds toward same-qi more slowly and recovers less stickily.
- Updated validators so temperature values and seven-emotion rules are checked as externalized data.

### Validation

- Gradle build and full validator suite passed.

## 2026-06-16 guide hints and pharmacology review

### Added

- Added data-backed one-time guide hints via module-owned JSON files:
  - `data/herbcraft/guide_hints.json`
  - `data/herbcraft_cuisine/guide_hints.json`
  - `data/herbcraft_alchemy/guide_hints.json`
- Added `GuideHintManager` and persisted seen-hint IDs on player data.
- Added first-hint triggers for first herb bite, first Codex open, first page read, first ingredient tasted, first correction, first water bowl, first dish, and first essence.
- Added `seven_single` / 单行 discovery and guide display.
- Added `docs/reports/PHARMACOLOGY_BALANCE_AND_RELATION_REVIEW_20260616.md` analyzing qi accumulation speed and relation coverage.

### Changed

- Guide hints remain module-owned: Core hints in Core, Cuisine hints in Cuisine, Alchemy hints in Alchemy.
- Validators now cover guide hints, `GuideHintManager`, persisted seen-hint storage, and built-jar guide hint resources.

### Validation

- Gradle build and full validator suite passed.

## 2026-06-16 pharmacology test matrix

### Documented

- Added `docs/reports/PHARMACOLOGY_SEVEN_EMOTION_TEST_MATRIX_20260616.md` after source-auditing `PharmacologyResolver`.
- The report confirms `XIANG_XU`, `XIANG_SHI`, `XIANG_SHA`, `XIANG_WEI`, `XIANG_E`, and `XIANG_FAN` are recorded for Codex discovery. `SINGLE` exists mechanically but is not currently recorded/displayed.
- Added concrete item-pair tables for client testing all 七情 relations and common 五味/温性 principle lines.

## 2026-06-16 next-project direction after Phase 2.1

### Planned

- Added planning report for the next `1.1.2` steps after Phase 2.1: client-test module combinations, then implement a small data-backed one-time hint system if Phase 2.1 passes.
- Proposed module-owned `guide_hints.json` files plus a `GuideHintManager` with persisted seen-hint IDs for first herb bite, first Codex open, first page read, first ingredient tasted, first correction, Cuisine water bowl/dish hints, and Alchemy first essence hint.
- Reaffirmed that P4 API, 药引子, Homeostatic temperature gameplay, and Hardcore Nutrition should wait until `1.1.2` guidance polish is stable.

### Docs

- Added `docs/reports/NEXT_PROJECT_DIRECTION_1_1_2_AFTER_PHASE2_1_20260616.md`.
- Updated `NEXT_TASK.md` and `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` to track P3.7 one-time guide hints as the next candidate after Phase 2.1 client verification.

## 2026-06-16 Codex guidance Phase 2.1 implementation

### Added

- Added data-backed Codex guide registration via module-owned JSON files:
  - `data/herbcraft/codex_guides.json`
  - `data/herbcraft_cuisine/codex_guides.json`
  - `data/herbcraft_alchemy/codex_guides.json`
- Added `CodexGuideRegistry` to load guide entries from JSON and bind them to Java line providers.
- Added pharmacology principle discovery persistence to `PlayerPharmacologyState`, storing latest item pair + count for flavor, temperature, and seven-emotion discoveries.
- Added progressive guide lines for flavor, temperature, and seven-emotion principles.

### Changed

- Core no longer owns or registers `膳房与药膳` / `炼金与精华`. Cuisine and Alchemy register their own guide entries only when their modules are installed.
- `五味与性味` no longer prints exact first tasted item/nature in the system guide. Exact item nature remains in the item entry; the guide reveals broader principles from player discoveries.
- Strengthened validators and built-jar checks for data-driven guide files, module ownership, and pharmacology discovery hooks.

### Validation

- Gradle build and full validator suite passed.

## 2026-06-16 Codex guidance Phase 2.1 implementation spec

### Planned

- Drafted the Phase 2.1 plan to make Codex guide registration data-driven via module-owned JSON files instead of Core hardcoding the guide list.
- Proposed `data/herbcraft/codex_guides.json`, `data/herbcraft_cuisine/codex_guides.json`, and `data/herbcraft_alchemy/codex_guides.json`.
- Specified that Cuisine/Alchemy guide entries should only appear when their addon module is loaded.
- Specified player principle discovery tracking for 七情 / flavor / temperature learning, storing latest item pair + count so the Codex can remind the player which eaten items triggered a relation.
- Wrote proposed Chinese and English guide copy for progressive 五味/性味 and 七情 reveal lines.

### Docs

- Added `docs/reports/CODEX_GUIDANCE_PHASE2_1_IMPLEMENTATION_SPEC_20260616.md`.
- Updated `docs/NEW_PLAYER_GUIDANCE_1_1_2_DESIGN.md`, `NEXT_TASK.md`, and `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` to point to the new implementation spec.

## 2026-06-16 Codex guidance Phase 2 review

### Reviewed

- Author client-tested the new Codex guide pages: all 9 guide entries appear under `百草经总纲`, and text renders normally.
- Source/client review identified two issues before Phase 2 should be treated as release-ready:
  - `膳房与药膳` and `炼金与精华` are currently registered unconditionally by Core and still appear when their addon modules are absent.
  - `五味与性味` currently displays exact first tasted item/nature in the guide page; this should be softened so exact item data remains in the item entry and principle meanings unlock through experience.

### Documented

- Added `docs/reports/CODEX_GUIDANCE_PHASE2_CLIENT_REVIEW_20260616.md` with source audit, design analysis, and recommended fixes.
- Updated `docs/NEW_PLAYER_GUIDANCE_1_1_2_DESIGN.md`, `NEXT_TASK.md`, and `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` to mark Phase 2.1 fixes as the next priority before one-time hints.

## 2026-06-16 1.1.2 onboarding phase 2 Codex guides

### Added

- Added always-visible guide subentries under `百草经总纲` / Herbal Codex overview:
  - 认识草木 / Knowing Wild Herbs
  - 听闻、亲尝与谙熟 / Rumor, Tasting, Mastery
  - 五味与性味 / Nature and Flavors
  - 七情与配伍 / Relations Between Herbs
  - 药性蓄积 / Medicinal Momentum
  - 膳房与药膳 / Cuisine and Medicinal Meals
  - 炼金与精华 / Alchemy and Essences
  - 食材录与五养 / Ingredient Codex and Nutrition
  - 残页与校勘 / Pages and Errata
- Added a 食材录 overview entry explaining that ordinary ingredients do not use herb pharmacology but still affect long-term nutrition.

### Changed

- Guide entries start vague and become clearer using existing player progress: tasted herb count, first tasted herb nature, discovered flavor count, herb-stack/cuisine/alchemy advancements, tasted ingredient count, heard claims, and verified claims.
- `KnowledgeAPI` now treats entries whose IDs start with `guide_` as always visible, similar to `overview`, so guide pages cannot be consumed by random tattered-page targeting and do not require knowledge flags.
- Updated `docs/NEW_PLAYER_GUIDANCE_1_1_2_DESIGN.md`, `NEXT_TASK.md`, and `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` to mark Phase 2 implemented and one-time hints as the next design candidate.

### Validation

- Gradle build and the full validator set passed, including strengthened P1 Codex/advancement validation for guide entries and 食材录 overview.

## 2026-06-16 1.1.2 onboarding phase 1 text polish

### Changed

- Rewrote the four-line `百草经总纲` / Herbal Codex overview to explain risk, rumor, tasting/practice, the three paths, 食材录, and the nutrition panel more clearly.
- Updated Core advancement descriptions so the dedicated advancement page reads more like route signs instead of only trophies. This fixes the root advancement wording so it no longer implies the player already owns a Codex.
- Updated Cuisine and Alchemy advancement descriptions with light route guidance while preserving hidden recipe and knowledge gates.
- Polished 食材录 wording to clarify that ordinary foods do not carry herb nature but still nourish long-term.
- Recorded Phase-1 implementation status in `docs/NEW_PLAYER_GUIDANCE_1_1_2_DESIGN.md`, updated `NEXT_TASK.md`, and updated `docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md` P3.6 tracking.

### Validation

- `JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 bash ./gradlew --no-daemon -Dorg.gradle.jvmargs='-Xmx1g -Dfile.encoding=UTF-8' build --rerun-tasks`, `python3 scripts/check_lang_diff.py`, and `python3 scripts/verify_built_jars.py` passed.

## 2026-06-16 P0 consistency pass

### Changed

- Added `release_output/` to `.gitignore` so local release/test artifacts are not accidentally committed.
- Marked `docs/PROJECT_SUMMARY.md` and `SOURCE_REVIEW_2026-06-14.md` as historical/superseded context.
- Updated `PROJECT_STATE.md`, `AI_ONBOARDING.md`, and `BUGS_TODO.md` to reflect current correction threshold/fallback and validator behavior.

### Fixed

- Fixed `NutritionRules.loadFromBundledJson()` fallback for `correction_high_threshold` from stale `850` to current `750`, matching `nutrition_rules.json` and `NutritionRules.defaults()`. This only affects missing-field fallback behavior.
- Updated validators that still looked for `1.0.0` built jars to derive the current jar version from `fabric.mod.json`.
- Updated `validate_animal_food_tags.py` to use Loom's downloaded Minecraft client/merged jar or `HERBCRAFT_VANILLA_CLIENT_JAR`, not only `/home/user/cache/minecraft/client-26.1.2.jar`.

### Validation

- `validate_nutrition_correction_phase.py` now checks the 750 fallback and zero-`fruit` correction fallback matrix.
- `validate_externalized_rules.py` now covers `ingredients.json` and `pharmacology_rules.json`.
- `verify_built_jars.py` now checks `ingredients.json`, `pharmacology_rules.json`, `IngredientsChapter.class`, and `PharmacologyRules.class` in the built core jar.

## 2026-06-16 nutrition tuning, ingredients chapter, data-driven cleanup

### Added

- Added 食材录 (Ingredient Codex) chapter: 39 vanilla foods in 6 sections (meat/seafood/grain/fruit/soup/special), data-driven from `data/herbcraft/ingredients.json`. Knowledge gated by eating: pick up → ENCOUNTERED, eat → MASTERED with fuzzy nutrition display.
- Added three fluid surplus debug presets: `fluid_surplus_pair`, `fluid_surplus_single`, `fluid_surplus_unrelated`.
- Added `data/herbcraft/ingredients.json` as the 18th data-driven JSON file.
- Added `IngredientsChapter.hasEntry()` for knowledge flag hooks.
- Added knowledge flag hooks in `NutritionManager.onFoodConsumed()` and `KnowledgeInventoryScanner` for vanilla food items.
- Added `data/herbcraft/nutrition_correction_rules.json` and `data/herbcraft/pharmacology_rules.json` to documentation (`DATA_DRIVEN_ARCHITECTURE.md`, `PROJECT_STATE.md`, `EXTENDING_HERBCRAFT.md`).

### Changed

- Scaled all 162 nutrition profiles to 0.6x for balanced pacing. `cooked_beef` flesh 69→41, `bread` grain 60→36. Players now need ~7 eats to reach correction threshold and ~9 to reach excess debuffs.
- Lowered `correction_high_threshold` from 850 to 750. Matrix correction now activates at 75% instead of 85%, eliminating the "dead zone" where 750-849 had only passive -2/min decay.
- Added graduated decay in `correctionDecayAmount()`: 750-849 uses half-speed, 850+ uses full-speed.
- Tightened fluid surplus helper: now requires at least two non-fruit excess dimensions (>850) that share a correction-matrix relationship. Single excess or unrelated excess no longer triggers surplus decay.
- Fixed `correcting_grain`/`correcting_flesh`/`correcting_oil` debug presets: non-target dimensions raised from 400-450 to 500-550.
- Synced `NutritionRules.defaultCorrectionWeights()` Java fallback defaults with `nutrition_correction_rules.json` (all fruit weights 0.0).
- Vanilla food tooltip nutrition now gated behind eating (ingredients chapter state).
- Expanded `reference_cache/26_1_porting_notes.md` with comprehensive 26.1 API details.

### Fixed

- Deleted redundant `core/data/herbcraft/tags/items/` (plural, old MC path); only `tags/item/` (singular, 26.1 path) remains.
- Fixed IngredientsChapter knowledge flags never being set (root cause: `displayState()` reads `KnowledgeFlags`, not Entry predicates).

### Removed

- Removed hardcoded `Items.*` entries from `IngredientsChapter.java`; replaced with JSON-driven `ingredients.json` loader.

## 2026-06-14 test baseline review / nutrition integration pass

### Added

- Added optional round-1 Homeostatic drinkable compatibility data for 33 Herbcraft Cuisine custom edible outputs and round-2 Homeostatic drinkable compatibility data for selected Core/vanilla Herbcraft edible items; added/updated `scripts/validate_homeostatic_compat.py`.
- Added `docs/HOMEOSTATIC_COMPAT_NOTES.md` and `docs/HARDCORE_NUTRITION_ADDON_PLAN.md` for future compatibility/addon planning.
- Added `scripts/generate_essence_resources.py` and `scripts/validate_essence_resources.py` for project-local essence resource coverage checks, missing skeleton generation, standalone `--scaffold-extension` example pack creation, and `--check-extension` scaffold validation.
- Added `docs/examples/essence_extension_example/` and `docs/EXTENDING_HERBCRAFT.md` to document the current extension workflow.
- Externalized several Java rule tables into JSON for easier maintenance: special counters, hodgepodge rules, alchemy essence definitions, advanced potion bonus pools, Codex loot injections, special/T3 potion definitions, the safe witch throw pool, witch loot, weapon coating rules, and nutrition effect mechanics/timing.
- Added `scripts/validate_externalized_rules.py` to guard those externalized rule tables.
- Added dynamic extra essence registration support for JSON entries beyond the current compatibility static fields.
- Added `SOURCE_REVIEW_2026-06-14.md`, a source-based feature summary of the current test baseline.
- Added `reference_cache/26_1_porting_notes.md` with Fabric/Minecraft 26.1 development notes.
- Added `scripts/setup_jdk25_temurin.sh` for temporary JDK 25 setup in sandboxes.
- Added release baseline output under `release_output/herbcraft_test_20260614_review/`.
- Added seven Herbcraft custom nutrition effects:
  - `herbcraft:grain_deficiency` / 谷气亏虚
  - `herbcraft:flesh_deficiency` / 血肉亏虚
  - `herbcraft:oil_deficiency` / 津脂不足
  - `herbcraft:vege_deficiency` / 蔬素不足
  - `herbcraft:fruit_deficiency` / 津液不足
  - `herbcraft:dietary_imbalance` / 饮食失衡
  - `herbcraft:well_nourished` / 五养调和
- Added mechanics for nutrition effects:
  - grain deficiency reduces block break speed;
  - flesh deficiency reduces attack damage;
  - oil deficiency reduces movement speed;
  - vege deficiency periodically increases exhaustion;
  - fruit deficiency lightly reduces movement speed;
  - dietary imbalance lightly reduces movement speed and periodically increases exhaustion;
  - well nourished gives armor and knockback resistance.
- Added `/herbcraft nutrition get|set|preset` debug commands gated behind gamemaster permission.
- Added `scripts/generate_nutrition_effect_icons.py` to generate nutrition effect icons from vanilla item textures.
- Added `scripts/validate_custom_nutrition_effects_phase8.py`; older phase validators now wrap to the current validator.

### Changed

- Updated Homeostatic compatibility to avoid negative Homeostatic `amount` values after client testing showed below-zero internal water can keep dehydration active after partial recovery; thirst-risk foods now use stronger thirst-effect chances/durations instead.
- Marked selected drink-like Cuisine dishes as `can_always_eat` so they can hydrate when the hunger bar is full.
- Rebalanced Homeostatic compatibility values against its 20-point water bar: stronger cuisine hydration, water bowl 85% thirst-effect risk, and meaningful negative hydration for sweet/sticky/hot/toxic Core edibles.
- Added gentle milk bucket nutrition (`flesh`/`oil`), reduced water bowl nutrition to trace fluids, and renamed the displayed fruit nutrition dimension to `津液` / `Fluids`.
- NutritionManager now uses Herbcraft custom effects instead of vanilla `WEAKNESS`, `SLOWNESS`, `MINING_FATIGUE`, `HUNGER`, `NAUSEA`, and hidden vanilla `RESISTANCE` for core nutrition states.
- Serious malnutrition and starved states are now sustained through the next nutrition evaluation instead of random short flashes.
- Nutrition evaluation now clears stale Herbcraft nutrition effects before applying the current nutrition state, so commands/food can remove old nutrition effects immediately.
- Confirmed dietary imbalance remains grace-gated, but once confirmed is sustained through the next nutrition evaluation.
- Warning states remain short/probabilistic to keep main-mod nutrition non-hardcore.
- Water bowl still has a 15% success chance, but on success now also temporarily relieves dietary imbalance for 60 seconds without repairing nutrition values.
- Cuisine/medicine clearing paths now skip Herbcraft nutrition effects.
- Nutrition effect icons were replaced with vanilla-derived item icons plus deficiency/down-arrow or positive/up-arrow overlays.
- Updated handoff docs: `AI_ONBOARDING.md`, `PROJECT_STATE.md`, `NEXT_TASK.md`, and `BUGS_TODO.md`.

### Fixed

- Removed stale PlayerNutritionState.evaluate / NutritionStatus logic so NutritionManager.evaluateAndApply is the sole authoritative runtime nutrition evaluation path.
- Fixed the conflict where medicinal cuisine/effect immunities could suppress NutritionManager's vanilla-effect-based debuffs.
- Fixed stale nutrition effects remaining after debug commands or corrective food changed nutrition values.
- Fixed severe malnutrition feeling like a random, short cosmetic flicker.
- Fixed the migrated grain danger path that previously applied `grain_deficiency` twice due to direct vanilla-effect ID replacement.

### Verified

- `JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks` passes.
- Language key parity passes.
- Custom nutrition phase 8 validator passes.
- Recipe isolation, item texture, task A/B/C/D, extended feature, and built-jar validators pass.
- Core server smoke reaches `Done` after the nutrition and icon updates.

## 2026-06-12

### Added

- Added responsive Herb Codex text layout with wrapping, scrolling and left-panel ellipsis trimming.
- Added creative tab variants for tattered pages in earlier stage, preserved in this release line.
- Added last meal death flavor message.
- Added centralized consume sound resolver for herbs and cuisine items.
- Added validation scripts for villager trade tags and language key diffs.

### Fixed

- Fixed long Codex text overflowing in English and other long-text languages.
- Fixed language key parity between `zh_cn` and `en_us`.
- Verified all data-driven villager trades are referenced by trade tags with `replace=false`.

### Builds

- Historical listed builds may not match the current test-baseline jar names. Current local test outputs are staged under `release_output/herbcraft_test_20260614_review/`, which is git-ignored/local-only.
