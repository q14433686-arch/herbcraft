# CHANGELOG

## 2026-06-14 test baseline review / nutrition integration pass

### Added

- Added `SOURCE_REVIEW_2026-06-14.md`, a source-based feature summary of the current test baseline.
- Added `reference_cache/26_1_porting_notes.md` with Fabric/Minecraft 26.1 development notes.
- Added `scripts/setup_jdk25_temurin.sh` for temporary JDK 25 setup in sandboxes.
- Added release baseline output under `release_output/herbcraft_test_20260614_review/`.
- Added seven Herbcraft custom nutrition effects:
  - `herbcraft:grain_deficiency` / 谷气亏虚
  - `herbcraft:flesh_deficiency` / 血肉亏虚
  - `herbcraft:oil_deficiency` / 津脂不足
  - `herbcraft:vege_deficiency` / 蔬素不足
  - `herbcraft:fruit_deficiency` / 津液不足
  - `herbcraft:dietary_imbalance` / 饮食失衡
  - `herbcraft:well_nourished` / 五养调和
- Added mechanics for nutrition effects:
  - grain deficiency reduces block break speed;
  - flesh deficiency reduces attack damage;
  - oil deficiency reduces movement speed;
  - vege deficiency periodically increases exhaustion;
  - fruit deficiency lightly reduces movement speed;
  - dietary imbalance lightly reduces movement speed and periodically increases exhaustion;
  - well nourished gives armor and knockback resistance.
- Added `/herbcraft nutrition get|set|preset` debug commands gated behind gamemaster permission.
- Added `scripts/generate_nutrition_effect_icons.py` to generate nutrition effect icons from vanilla item textures.
- Added `scripts/validate_custom_nutrition_effects_phase8.py`; older phase validators now wrap to the current validator.

### Changed

- NutritionManager now uses Herbcraft custom effects instead of vanilla `WEAKNESS`, `SLOWNESS`, `MINING_FATIGUE`, `HUNGER`, `NAUSEA`, and hidden vanilla `RESISTANCE` for core nutrition states.
- Serious malnutrition and starved states are now sustained through the next nutrition evaluation instead of random short flashes.
- Nutrition evaluation now clears stale Herbcraft nutrition effects before applying the current nutrition state, so commands/food can remove old nutrition effects immediately.
- Confirmed dietary imbalance remains grace-gated, but once confirmed is sustained through the next nutrition evaluation.
- Warning states remain short/probabilistic to keep main-mod nutrition non-hardcore.
- Water bowl still has a 15% success chance, but on success now also temporarily relieves dietary imbalance for 60 seconds without repairing nutrition values.
- Cuisine/medicine clearing paths now skip Herbcraft nutrition effects.
- Nutrition effect icons were replaced with vanilla-derived item icons plus deficiency/down-arrow or positive/up-arrow overlays.
- Updated handoff docs: `AI_ONBOARDING.md`, `PROJECT_STATE.md`, `NEXT_TASK.md`, and `BUGS_TODO.md`.

### Fixed

- Fixed the conflict where medicinal cuisine/effect immunities could suppress NutritionManager's vanilla-effect-based debuffs.
- Fixed stale nutrition effects remaining after debug commands or corrective food changed nutrition values.
- Fixed severe malnutrition feeling like a random, short cosmetic flicker.
- Fixed the migrated grain danger path that previously applied `grain_deficiency` twice due to direct vanilla-effect ID replacement.

### Verified

- `JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks` passes.
- Language key parity passes.
- Custom nutrition phase 8 validator passes.
- Recipe isolation, item texture, task A/B/C/D, extended feature, and built-jar validators pass.
- Core server smoke reaches `Done` after the nutrition and icon updates.

## 2026-06-12

### Added

- Added responsive Herb Codex text layout with wrapping, scrolling and left-panel ellipsis trimming.
- Added creative tab variants for tattered pages in earlier stage, preserved in this release line.
- Added last meal death flavor message.
- Added centralized consume sound resolver for herbs and cuisine items.
- Added validation scripts for villager trade tags and language key diffs.

### Fixed

- Fixed long Codex text overflowing in English and other long-text languages.
- Fixed language key parity between `zh_cn` and `en_us`.
- Verified all data-driven villager trades are referenced by trade tags with `replace=false`.

### Builds

- Historical listed builds may not match the current test-baseline jar names. Current test outputs are under `release_output/herbcraft_test_20260614_review/`.
