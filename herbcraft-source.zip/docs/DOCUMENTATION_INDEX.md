# Herbcraft Documentation Index

Status: current documentation map for the packaged `1.1.3` source line.  
Last updated: 2026-06-17

Use this file to avoid treating historical design notes as the current source of truth.

For future AI/helper sessions, the shortest safe handoff is:

```bash
python3 scripts/generate_agent_brief.py --write
```

then read `docs/reports/CURRENT_AGENT_BRIEF.md`.

## 1. Authoritative current-state anchors

Read these first when taking over the project:

```text
AGENT_BRIEF.md
CURRENT_BASELINE.md
README.md
AI_ONBOARDING.md
PROJECT_STATE.md
NEXT_TASK.md
CHANGELOG.md
docs/DATA_DRIVEN_ARCHITECTURE.md
docs/EXTENDING_HERBCRAFT.md
docs/AI_COLLABORATION_GUIDE.md
docs/ADDON_AUTHOR_QUICKSTART_1_1_3.md
docs/HERBCRAFT_FULL_SYSTEM_WIKI_1_1_3.md
docs/wiki/README.md
docs/JSON_EXTENSION_SPEC_1_1_3.md
docs/EXTERNAL_EXTENSION_SPEC_DRAFT.md
docs/PUBLIC_EXTENSION_API_DESIGN.md
reference_cache/26_1_porting_notes.md
```

Important rule:

```text
Current user request > current source > current documentation > older memory or old reports.
```

## 2. Current release/upload copy

Use these for current `1.1.3` platform descriptions and version changelogs:

```text
docs/RELEASE_PAGE_COPY_1.1.3.md        # Modrinth / CurseForge, English first
docs/MCMOD_RELEASE_COPY_1.1.3.md       # MC百科 / MCMOD, Chinese community copy
```

## 3. Current implementation reports / design references

These reports describe implemented or recently tuned systems that are part of the current working tree:

```text
docs/reports/NUTRITION_CORRECTION_IMPLEMENTATION_REPORT_20260615.md
docs/reports/PHARMACOLOGY_BALANCE_AND_RELATION_REVIEW_20260616.md
docs/reports/PHARMACOLOGY_SEVEN_EMOTION_TEST_MATRIX_20260616.md
docs/reports/HERB_FOOD_ROLLS_IMPLEMENTATION_REPORT_20260616.md
docs/reports/HERB_FOOD_SEED_SUGARCANE_TUNING_20260616.md
docs/reports/CODEX_GUIDANCE_PHASE2_1_IMPLEMENTATION_SPEC_20260616.md
docs/reports/CUISINE_ALCHEMY_GUIDE_COPY_PHASE3_9_SPEC_20260616.md
docs/reports/EXTERNAL_INGREDIENTS_CLIENT_SYNC_GENERATOR_API_20260616.md
docs/reports/FARMER_MORE_BUILTIN_COMPAT_AND_NATURE_BRIDGE_20260617.md
docs/reports/FOOD_NATURE_DISPLAY_AND_GUIDE_FIX_20260617.md
docs/reports/P4_2_READONLY_JAVA_API_20260617.md
docs/reports/P4_3_EVENT_API_20260617.md
docs/reports/P4_4_EXAMPLES_20260617.md
docs/reports/P4_EXTENSION_READINESS_1_1_3_20260617.md
docs/reports/EDGE_REGRESSION_REVIEW_20260617.md
docs/reports/EDGE_P1_P2_FIXES_20260617.md
docs/reports/DATAPACK_RUNTIME_COMPAT_VERIFICATION_20260617.md
```

Current key facts from these reports:

- Codex guide entries and one-time guide hints are data-backed and module-owned.
- Pharmacology temperature values and ordered seven-emotion rules are data-backed in `pharmacology_rules.json`.
- Raw herb `food_rolls` are implemented for bundled/startup herb food data.
- Common forage no longer acts as reliable early food.
- Seeds were strengthened after client testing: ordinary seeds roll `S+2`, melon/pumpkin seeds roll `S+3`.
- Sugar cane remains +1 visible hunger, now gives about +2 hidden saturation, and Homeostatic hydration is anchored at amount 3.
- 五味/七情 Codex guide pages now include plain beginner-facing microcopy.
- Food-mod compatibility Rounds 1-5 are tracked under `docs/compat_drafts/food_mods_26_1_2/`; author client testing passed for Farmer's Delight + More Delight, RMF was removed, current generated pack is `generated_pack/`, source table is `compat_review_round5_farmer_moredelight.csv`, final Chinese nature table is `ROUND5_FINAL_CHINESE_NATURE_TABLE.md`, and final report is `ROUND5_CLIENT_TEST_REPORT.md`.
- Farmer's Delight + More Delight data is also bundled into Core as optional data under `data/farmers_moredelight_herbcraft/herbcraft/`, and a generic food-nature pharmacology bridge lets explicit nature+nutrition ordinary foods participate in nature pharmacology without overriding target food components. Tasted nature-bearing foods appear in 百草志 `药食志`; nutrition remains in 食材录.
- P4.1-P4.5 are complete for the read/event extension boundary: JSON spec, read-only Java API, observational event API, examples, validators, and readiness report. Write/registration APIs remain deferred.
- Full system Wiki draft for `1.1.3` is `docs/HERBCRAFT_FULL_SYSTEM_WIKI_1_1_3.md`; it explains Codex, 食材录, 药食志, raw herb eating, 药性回旋, 性味/五味/特质/气机/七情, nutrition, Cuisine, Alchemy, compatibility, and extension boundaries.
- AI/developer handoff prompt guide is `docs/AI_COLLABORATION_GUIDE.md`; addon author quickstart is `docs/ADDON_AUTHOR_QUICKSTART_1_1_3.md`; canonical future Wiki source lives under `docs/wiki/`.
- P4 datapack runtime verification report is `docs/reports/DATAPACK_RUNTIME_COMPAT_VERIFICATION_20260617.md`; test datapack zip is `release_output/herbcraft_test_20260614_review/herbcraft-p4-runtime-test-datapack-20260617.zip`.

## 4. Current extension/addon examples

```text
docs/examples/external_extension_compat_pack/
docs/examples/herbcraft_readonly_event_addon/
docs/examples/startup_herb_food_extension_mod/
docs/examples/essence_extension_example/
```

Validators:

```text
scripts/validate_external_extension_spec.py
scripts/validate_essence_resources.py
scripts/generate_essence_resources.py --check
scripts/generate_compat_pack.py
```

## 5. Homeostatic documents

Current practical reference:

```text
docs/HOMEOSTATIC_COMPAT.md
```

Historical/research references:

```text
docs/HOMEOSTATIC_COMPAT_DESIGN.md
docs/HOMEOSTATIC_COMPAT_NOTES.md
docs/HOMEOSTATIC_TEMPERATURE_COMPAT_NOTES.md
```

Notes:

- Thirst/drinkable data compatibility is implemented.
- Do not use negative Homeostatic `amount` values.
- Sugar cane Homeostatic hydration is currently `amount 3 / saturation 0.5`.
- Temperature gameplay integration is not implemented.

## 6. Historical documents retained for context

The following files are useful history but must not be treated as current authoritative state without source verification:

```text
SOURCE_REVIEW_2026-06-14.md
docs/PROJECT_SUMMARY.md
docs/Herbcraft_1.1.0_Combined_Mod_Page.md
docs/Herbcraft_1.1.0_Combined_Mod_Page.md
docs/Herbcraft_1.1.1_Combined_Mod_Page.md
docs/RELEASE_PAGE_COPY_1.1.0.md
docs/RELEASE_PAGE_COPY_1.1.1.md
docs/reports/P1_*.md
docs/reports/STAGE*.md
docs/reports/RUN_REPORT_2026-06-12.md
```

Why:

- Some describe old jar names or pre-`1.1.3` polish state.
- Some predate data-backed Codex guides, `food_rolls`, guide hints, pharmacology rule externalization, or current nutrition correction tuning.
- Some are public release copy snapshots and should remain as historical copy, not source-state documentation.

## 7. Future idea / planning documents

These are idea banks, not implementation truth:

```text
docs/HERBCRAFT_FUTURE_IDEAS_AND_1_1_2_ROADMAP.md
docs/HARDCORE_NUTRITION_ADDON_PLAN.md
docs/EXTENSION_GENERATOR_PLAN.md
```

When implementing from them:

1. Re-read current source first.
2. Check `CURRENT_BASELINE.md` and `NEXT_TASK.md`.
3. Write or update a validator if the feature affects data or runtime behavior.
4. Refresh the source zip after documentation/source changes.

## 8. Release output convention

Current local baseline path remains:

```text
release_output/herbcraft_test_20260614_review/herbcraft-source-current-20260614.zip
```

Do not rename this source zip or output folder unless the author explicitly asks.

`release_output/` is local/publishing-only and git-ignored. Public jars should be uploaded through GitHub Releases/platforms, not committed to source.
