# `data/herbcraft/herbs.json` schema draft

This is the M1 migration schema for Herbcraft Core.

The current file is generated from `Herbcraft.java` and is not yet the authoritative runtime source. The next M1 step is to replace hardcoded `entry(Items.X, ...)` registration with a loader that reads this JSON.

## Root

```json
{
  "schema_version": 1,
  "note": "...",
  "herbs": []
}
```

## Herb entry

```json
{
  "item": "minecraft:dandelion",
  "nutrition": 1,
  "saturation_modifier": 0.3,
  "consume_seconds": 1.6,
  "medicinal": false,
  "stack_group": true,
  "remove_effects": ["minecraft:poison"],
  "effects": [],
  "damage_events": [],
  "heal_events": [],
  "flags": [],
  "counter": "poppy"
}
```

## Fields

| Field | Type | Meaning |
| --- | --- | --- |
| `item` | string | Vanilla item ID. |
| `nutrition` | int | Food nutrition value. |
| `saturation_modifier` | float | Food saturation modifier. |
| `consume_seconds` | float | Consumable duration. |
| `medicinal` | boolean | Equivalent to v3.0 药用 / always edible. |
| `stack_group` | boolean | Participates in herb_stack. |
| `remove_effects` | string[] | Effects removed before applying new effects. |
| `effects` | object[] | Potion-like effects to roll/apply. |
| `damage_events` | object[] | Physical/magic damage events. |
| `heal_events` | object[] | Instant healing approximation. |
| `flags` | string[] | Special behavior flags. |
| `counter` | string | Special counter key. |

## Effect entry

```json
{
  "effect": "minecraft:regeneration",
  "chance": 0.2,
  "amplifier": 0,
  "duration_seconds": 4,
  "positive": true
}
```

or:

```json
{
  "effect": "minecraft:saturation",
  "chance": 1.0,
  "amplifier": 0,
  "duration_ticks": 10,
  "positive": true
}
```

## Flags

Current generated flags:

- `clearPositiveEffects`
- `extinguish`
- `bucketRemainder`
- `drink`
- `shortUseProjectile`

These will probably become stable lowercase identifiers in the final data-driven implementation, e.g. `clear_positive_effects`, `bucket_remainder`, etc.
