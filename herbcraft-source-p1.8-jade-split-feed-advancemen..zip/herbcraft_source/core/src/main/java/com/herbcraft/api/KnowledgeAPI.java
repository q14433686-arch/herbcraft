package com.herbcraft.api;

import com.herbcraft.HerbcraftPlayerData;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class KnowledgeAPI {
   private static final Map<String, KnowledgeAPI.Chapter> CHAPTERS = new LinkedHashMap<>();
   private static long registrationCounter = 0L;

   private KnowledgeAPI() {
   }

   public static synchronized KnowledgeAPI.Chapter registerChapter(String id, Component title, int sortPriority) {
      return CHAPTERS.computeIfAbsent(id, key -> new KnowledgeAPI.Chapter(key, title, sortPriority, registrationCounter++));
   }

   public static synchronized KnowledgeAPI.Chapter registerChapter(String id, Component title) {
      return registerChapter(id, title, 1000);
   }

   public static synchronized void registerSection(String chapterId, String sectionId, Component title) {
      KnowledgeAPI.Chapter chapter = CHAPTERS.get(chapterId);
      if (chapter == null) {
         throw new IllegalStateException("Unknown knowledge chapter: " + chapterId);
      } else {
         chapter.sections.putIfAbsent(sectionId, title);
      }
   }

   public static synchronized void registerEntry(String chapterId, KnowledgeAPI.Entry entry) {
      KnowledgeAPI.Chapter chapter = CHAPTERS.get(chapterId);
      if (chapter == null) {
         throw new IllegalStateException("Unknown knowledge chapter: " + chapterId);
      } else if (entry.section() != null && !chapter.sections.containsKey(entry.section())) {
         throw new IllegalStateException("Unknown section " + entry.section() + " in chapter " + chapterId);
      } else {
         chapter.entries.put(entry.id(), entry);
      }
   }

   public static List<KnowledgeAPI.Chapter> chapters() {
      List<KnowledgeAPI.Chapter> sorted = new ArrayList<>(CHAPTERS.values());
      sorted.sort(Comparator.comparingInt(KnowledgeAPI.Chapter::sortPriority).thenComparingLong(chapter -> chapter.registrationIndex));
      return sorted;
   }

   public static Optional<KnowledgeAPI.Chapter> chapter(String id) {
      return Optional.ofNullable(CHAPTERS.get(id));
   }

   public static KnowledgeAPI.State state(ServerPlayer player, String chapterId, KnowledgeAPI.Entry entry) {
      Integer stored = knowledge(player).get(chapterId + "/" + entry.id());
      if (stored != null && stored >= 2) {
         return KnowledgeAPI.State.MASTERED;
      } else if (entry.mastered() != null && entry.mastered().test(player)) {
         return KnowledgeAPI.State.MASTERED;
      } else if (stored != null && stored >= 1) {
         return KnowledgeAPI.State.HEARD;
      } else {
         return entry.heard() != null && entry.heard().test(player) ? KnowledgeAPI.State.HEARD : KnowledgeAPI.State.UNKNOWN;
      }
   }

   public static boolean hear(ServerPlayer player, String chapterId, String entryId) {
      KnowledgeAPI.Chapter chapter = CHAPTERS.get(chapterId);
      if (chapter == null) {
         return false;
      } else {
         KnowledgeAPI.Entry entry = chapter.entries.get(entryId);
         if (entry == null) {
            return false;
         } else if (state(player, chapterId, entry) != KnowledgeAPI.State.UNKNOWN) {
            return false;
         } else {
            knowledge(player).put(chapterId + "/" + entryId, 1);
            return true;
         }
      }
   }

   public static Optional<KnowledgeAPI.Entry> hearRandomUnknown(ServerPlayer player, String chapterId) {
      KnowledgeAPI.Chapter chapter = CHAPTERS.get(chapterId);
      if (chapter == null) {
         return Optional.empty();
      } else {
         List<KnowledgeAPI.Entry> unknown = new ArrayList<>();

         for (KnowledgeAPI.Entry entry : chapter.entries.values()) {
            if (state(player, chapterId, entry) == KnowledgeAPI.State.UNKNOWN) {
               unknown.add(entry);
            }
         }

         if (unknown.isEmpty()) {
            return Optional.empty();
         } else {
            KnowledgeAPI.Entry picked = unknown.get(player.getRandom().nextInt(unknown.size()));
            knowledge(player).put(chapterId + "/" + picked.id(), 1);
            return Optional.of(picked);
         }
      }
   }

   public static Map<String, Integer> knowledge(ServerPlayer player) {
      return ((HerbcraftPlayerData)player).herbcraft$knowledge();
   }

   public static final class Chapter {
      private final String id;
      private final Component title;
      private final int sortPriority;
      private final long registrationIndex;
      private final Map<String, Component> sections = new LinkedHashMap<>();
      private final Map<String, KnowledgeAPI.Entry> entries = new LinkedHashMap<>();

      private Chapter(String id, Component title, int sortPriority, long registrationIndex) {
         this.id = id;
         this.title = title;
         this.sortPriority = sortPriority;
         this.registrationIndex = registrationIndex;
      }

      public String id() {
         return this.id;
      }

      public Component title() {
         return this.title;
      }

      public int sortPriority() {
         return this.sortPriority;
      }

      public Map<String, Component> sections() {
         return this.sections;
      }

      public Collection<KnowledgeAPI.Entry> entries() {
         return this.entries.values();
      }

      public KnowledgeAPI.Entry entry(String entryId) {
         return this.entries.get(entryId);
      }
   }

   public record Entry(
      String id,
      String section,
      Component title,
      BiFunction<ServerPlayer, KnowledgeAPI.State, List<Component>> lines,
      Predicate<ServerPlayer> mastered,
      Predicate<ServerPlayer> heard
   ) {
   }

   public static enum State {
      UNKNOWN,
      HEARD,
      MASTERED;
   }
}
