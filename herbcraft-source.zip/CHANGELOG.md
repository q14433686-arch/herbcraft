# CHANGELOG

## 2026-06-16 nutrition tuning, ingredients chapter, data-driven cleanup

### Added

- Added 食材录 (Ingredient Codex) chapter: 39 vanilla foods in 6 sections (meat/seafood/grain/fruit/soup/special), data-driven from `data/herbcraft/ingredients.json`. Knowledge gated by eating: pick up → ENCOUNTERED, eat → MASTERED with fuzzy nutrition display.
- Added three fluid surplus debug presets: `fluid_surplus_pair`, `fluid_surplus_single`, `fluid_surplus_unrelated`.
- Added `data/herbcraft/ingredients.json` as the 18th data-driven JSON file.
- Added `IngredientsChapter.hasEntry()` for knowledge flag hooks.
- Added knowledge flag hooks in `NutritionManager.onFoodConsumed()` and `KnowledgeInventoryScanner` for vanilla food items.
- Added `data/herbcraft/nutrition_correction_rules.json` and `data/herbcraft/pharmacology_rules.json` to documentation (`DATA_DRIVEN_ARCHITECTURE.md`, `PROJECT_STATE.md`, `EXTENDING_HERBCRAFT.md`).

### Changed

- Scaled all 162 nutrition profiles to 0.6x for balanced pacing. `cooked_beef` flesh 69→41, `bread` grain 60→36. Players now need ~7 eats to reach correction threshold and ~9 to reach excess debuffs.
- Lowered `correction_high_threshold` from 850 to 750. Matrix correction now activates at 75% instead of 85%, eliminating the "dead zone" where 750-849 had only passive -2/min decay.
- Added graduated decay in `correctionDecayAmount()`: 750-849 uses half-speed, 850+ uses full-speed.
- Tightened fluid surplus helper: now requires at least two non-fruit excess dimensions (>850) that share a correction-matrix relationship. Single excess or unrelated excess no longer triggers surplus decay.
- Fixed `correcting_grain`/`correcting_flesh`/`correcting_oil` debug presets: non-target dimensions raised from 400-450 to 500-550.
- Synced `NutritionRules.defaultCorrectionWeights()` Java fallback defaults with `nutrition_correction_rules.json` (all fruit weights 0.0).
- Vanilla food tooltip nutrition now gated behind eating (ingredients chapter state).
- Expanded `reference_cache/26_1_porting_notes.md` with comprehensive 26.1 API details.

### Fixed

- Deleted redundant `core/data/herbcraft/tags/items/` (plural, old MC path); only `tags/item/` (singular, 26.1 path) remains.
- Fixed IngredientsChapter knowledge flags never being set (root cause: `displayState()` reads `KnowledgeFlags`, not Entry predicates).

### Removed

- Removed hardcoded `Items.*` entries from `IngredientsChapter.java`; replaced with JSON-driven `ingredients.json` loader.

## 2026-06-14 test baseline review / nutrition integration pass

### Added

- Added optional round-1 Homeostatic drinkable compatibility data for 33 Herbcraft Cuisine custom edible outputs and round-2 Homeostatic drinkable compatibility data for selected Core/vanilla Herbcraft edible items; added/updated `scripts/validate_homeostatic_compat.py`.
- Added `docs/HOMEOSTATIC_COMPAT_NOTES.md` and `docs/HARDCORE_NUTRITION_ADDON_PLAN.md` for future compatibility/addon planning.
- Added `scripts/generate_essence_resources.py` and `scripts/validate_essence_resources.py` for project-local essence resource coverage checks, missing skeleton generation, standalone `--scaffold-extension` example pack creation, and `--check-extension` scaffold validation.
- Added `docs/examples/essence_extension_example/` and `docs/EXTENDING_HERBCRAFT.md` to document the current extension workflow.
- Externalized several Java rule tables into JSON for easier maintenance: special counters, hodgepodge rules, alchemy essence definitions, advanced potion bonus pools, Codex loot injections, special/T3 potion definitions, the safe witch throw pool, witch loot, weapon coating rules, and nutrition effect mechanics/timing.
- Added `scripts/validate_externalized_rules.py` to guard those externalized rule tables.
- Added dynamic extra essence registration support for JSON entries beyond the current compatibility static fields.
- Added `SOURCE_REVIEW_2026-06-14.md`, a source-based feature summary of the current test baseline.
- Added `reference_cache/26_1_porting_notes.md` with Fabric/Minecraft 26.1 development notes.
- Added `scripts/setup_jdk25_temurin.sh` for temporary JDK 25 setup in sandboxes.
- Added release baseline output under `release_output/herbcraft_test_20260614_review/`.
- Added seven Herbcraft custom nutrition effects:
  - `herbcraft:grain_deficiency` / 谷气亏虚
  - `herbcraft:flesh_deficiency` / 血肉亏虚
  - `herbcraft:oil_deficiency` / 津脂不足
  - `herbcraft:vege_deficiency` / 蔬素不足
  - `herbcraft:fruit_deficiency` / 津液不足
  - `herbcraft:dietary_imbalance` / 饮食失衡
  - `herbcraft:well_nourished` / 五养调和
- Added mechanics for nutrition effects:
  - grain deficiency reduces block break speed;
  - flesh deficiency reduces attack damage;
  - oil deficiency reduces movement speed;
  - vege deficiency periodically increases exhaustion;
  - fruit deficiency lightly reduces movement speed;
  - dietary imbalance lightly reduces movement speed and periodically increases exhaustion;
  - well nourished gives armor and knockback resistance.
- Added `/herbcraft nutrition get|set|preset` debug commands gated behind gamemaster permission.
- Added `scripts/generate_nutrition_effect_icons.py` to generate nutrition effect icons from vanilla item textures.
- Added `scripts/validate_custom_nutrition_effects_phase8.py`; older phase validators now wrap to the current validator.

### Changed

- Updated Homeostatic compatibility to avoid negative Homeostatic `amount` values after client testing showed below-zero internal water can keep dehydration active after partial recovery; thirst-risk foods now use stronger thirst-effect chances/durations instead.
- Marked selected drink-like Cuisine dishes as `can_always_eat` so they can hydrate when the hunger bar is full.
- Rebalanced Homeostatic compatibility values against its 20-point water bar: stronger cuisine hydration, water bowl 85% thirst-effect risk, and meaningful negative hydration for sweet/sticky/hot/toxic Core edibles.
- Added gentle milk bucket nutrition (`flesh`/`oil`), reduced water bowl nutrition to trace fluids, and renamed the displayed fruit nutrition dimension to `津液` / `Fluids`.
- NutritionManager now uses Herbcraft custom effects instead of vanilla `WEAKNESS`, `SLOWNESS`, `MINING_FATIGUE`, `HUNGER`, `NAUSEA`, and hidden vanilla `RESISTANCE` for core nutrition states.
- Serious malnutrition and starved states are now sustained through the next nutrition evaluation instead of random short flashes.
- Nutrition evaluation now clears stale Herbcraft nutrition effects before applying the current nutrition state, so commands/food can remove old nutrition effects immediately.
- Confirmed dietary imbalance remains grace-gated, but once confirmed is sustained through the next nutrition evaluation.
- Warning states remain short/probabilistic to keep main-mod nutrition non-hardcore.
- Water bowl still has a 15% success chance, but on success now also temporarily relieves dietary imbalance for 60 seconds without repairing nutrition values.
- Cuisine/medicine clearing paths now skip Herbcraft nutrition effects.
- Nutrition effect icons were replaced with vanilla-derived item icons plus deficiency/down-arrow or positive/up-arrow overlays.
- Updated handoff docs: `AI_ONBOARDING.md`, `PROJECT_STATE.md`, `NEXT_TASK.md`, and `BUGS_TODO.md`.

### Fixed

- Removed stale PlayerNutritionState.evaluate / NutritionStatus logic so NutritionManager.evaluateAndApply is the sole authoritative runtime nutrition evaluation path.
- Fixed the conflict where medicinal cuisine/effect immunities could suppress NutritionManager's vanilla-effect-based debuffs.
- Fixed stale nutrition effects remaining after debug commands or corrective food changed nutrition values.
- Fixed severe malnutrition feeling like a random, short cosmetic flicker.
- Fixed the migrated grain danger path that previously applied `grain_deficiency` twice due to direct vanilla-effect ID replacement.

### Verified

- `JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks` passes.
- Language key parity passes.
- Custom nutrition phase 8 validator passes.
- Recipe isolation, item texture, task A/B/C/D, extended feature, and built-jar validators pass.
- Core server smoke reaches `Done` after the nutrition and icon updates.

## 2026-06-12

### Added

- Added responsive Herb Codex text layout with wrapping, scrolling and left-panel ellipsis trimming.
- Added creative tab variants for tattered pages in earlier stage, preserved in this release line.
- Added last meal death flavor message.
- Added centralized consume sound resolver for herbs and cuisine items.
- Added validation scripts for villager trade tags and language key diffs.

### Fixed

- Fixed long Codex text overflowing in English and other long-text languages.
- Fixed language key parity between `zh_cn` and `en_us`.
- Verified all data-driven villager trades are referenced by trade tags with `replace=false`.

### Builds

- Historical listed builds may not match the current test-baseline jar names. Current test outputs are under `release_output/herbcraft_test_20260614_review/`.
