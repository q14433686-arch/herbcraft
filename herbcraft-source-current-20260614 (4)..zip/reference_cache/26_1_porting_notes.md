# 26.1 / Fabric 开发参考缓存

缓存时间：2026-06-14

> 这是给 Herbcraft 测试版维护用的快速参考，不替代实时查 API。遇到 26.1 细节、Fabric API 命名、Mixin 目标签名、数据驱动交易、配方序列化等不确定点时，应重新联网查证或直接检查本地反编译/Gradle 缓存。

## 已确认的外部参考

1. Fabric 官方《Fabric for Minecraft 26.1》：https://fabricmc.net/2026/03/14/261.html
   - 26.1 使用 Mojang 官方名；Yarn 不再作为 Fabric 官方支持的 26.1 映射。
   - 需要 Java 25。
   - 旧 `fabric` mod id 依赖不可用，应依赖 `fabric-api`。
   - `fabric-loot-api-v2` 被移除，应使用 v3。
   - 26.1 的村民交易/流浪商人交易是数据驱动；新增路径 `data/<namespace>/villager_trade`，并通过 `data/minecraft/tags/villager_trade/<profession>` 挂入职业/等级交易池。
   - 自定义 `RecipeSerializer` 现在以 `MapCodec` + `StreamCodec` 为核心。
   - `ItemStackTemplate` 替代许多早期可直接创建 `ItemStack` 的位置；世界加载前不要访问未绑定组件。

2. Minecraft 官方 26.1 Snapshot 1：
   https://www.minecraft.net/en-us/article/minecraft-26-1-snapshot-1
   - 原版说明了村民/流浪商人交易数据驱动化，并给出 trade JSON 示例。

## 本项目当前采用方式

- Gradle：`net.fabricmc.fabric-loom`，Java 25，Mojang official names。
- 交易：源码中使用 `data/*/villager_trade/**.json` + `data/minecraft/tags/villager_trade/**.json`，没有使用旧 `TradeOfferHelper`。
- 配方：`HodgepodgeRecipe`、`CoatingSmithingRecipe` 均按 26.1 风格注册 `RecipeSerializer(MapCodec, StreamCodec)`。
- 组件：药水品质、药水 bonus、武器淬层、百草盅内容均使用 DataComponentType。
- Loot：core 使用 Fabric loot v3 事件路径。

## 后续规则

- 若涉及 26.1 API 细节：先查此文件，再查官方页面/源码/API。
- 若目标签名不确定：用 Gradle 缓存或 mcsrc.dev / 反编译源码核验后再改 Mixin。
- 不把搜索结果当成源码事实；最终仍以本项目源码、构建、启动验证为准。
