package com.herbcraft.mixin;

import com.herbcraft.HerbcraftPlayerData;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Player.class)
public abstract class PlayerMixin implements HerbcraftPlayerData {
   @Unique
   private int herbcraft$herbStack;
   @Unique
   private long herbcraft$herbExpiresAt;
   @Unique
   private int herbcraft$poppyCount;
   @Unique
   private long herbcraft$poppyExpiresAt;
   @Unique
   private int herbcraft$torchflowerCount;
   @Unique
   private long herbcraft$torchflowerExpiresAt;
   @Unique
   private int herbcraft$sugarCount;
   @Unique
   private long herbcraft$sugarExpiresAt;
   @Unique
   private int herbcraft$slimeCount;
   @Unique
   private long herbcraft$slimeExpiresAt;
   @Unique
   private final Map<String, Integer> herbcraft$knowledgeMap = new HashMap<>();

   @Override
   public Map<String, Integer> herbcraft$knowledge() {
      return this.herbcraft$knowledgeMap;
   }

   @Override
   public int herbcraft$getHerbStack(long gameTime) {
      if (gameTime > this.herbcraft$herbExpiresAt) {
         this.herbcraft$herbStack = 0;
      }

      return this.herbcraft$herbStack;
   }

   @Override
   public int herbcraft$addHerbStack(long gameTime) {
      if (gameTime > this.herbcraft$herbExpiresAt) {
         this.herbcraft$herbStack = 0;
      }

      this.herbcraft$herbStack++;
      this.herbcraft$herbExpiresAt = gameTime + 1200L;
      return this.herbcraft$herbStack;
   }

   @Override
   public void herbcraft$clearHerbStack() {
      this.herbcraft$herbStack = 0;
      this.herbcraft$herbExpiresAt = 0L;
   }

   @Override
   public int herbcraft$incrementWindowCounter(String counter, long gameTime, int windowTicks) {
      if ("poppy".equals(counter)) {
         if (gameTime > this.herbcraft$poppyExpiresAt) {
            this.herbcraft$poppyCount = 0;
         }

         this.herbcraft$poppyCount++;
         this.herbcraft$poppyExpiresAt = gameTime + windowTicks;
         return this.herbcraft$poppyCount;
      } else if ("torchflower".equals(counter)) {
         if (gameTime > this.herbcraft$torchflowerExpiresAt) {
            this.herbcraft$torchflowerCount = 0;
         }

         this.herbcraft$torchflowerCount++;
         this.herbcraft$torchflowerExpiresAt = gameTime + windowTicks;
         return this.herbcraft$torchflowerCount;
      } else if ("sugar".equals(counter)) {
         if (gameTime > this.herbcraft$sugarExpiresAt) {
            this.herbcraft$sugarCount = 0;
         }

         this.herbcraft$sugarCount++;
         this.herbcraft$sugarExpiresAt = gameTime + windowTicks;
         return this.herbcraft$sugarCount;
      } else if ("slime".equals(counter)) {
         if (gameTime > this.herbcraft$slimeExpiresAt) {
            this.herbcraft$slimeCount = 0;
         }

         this.herbcraft$slimeCount++;
         this.herbcraft$slimeExpiresAt = gameTime + windowTicks;
         return this.herbcraft$slimeCount;
      } else {
         return 0;
      }
   }

   @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
   private void herbcraft$writeData(ValueOutput output, CallbackInfo ci) {
      output.putInt("HerbcraftHerbStack", this.herbcraft$herbStack);
      output.putLong("HerbcraftHerbExpiresAt", this.herbcraft$herbExpiresAt);
      output.putInt("HerbcraftPoppyCount", this.herbcraft$poppyCount);
      output.putLong("HerbcraftPoppyExpiresAt", this.herbcraft$poppyExpiresAt);
      output.putInt("HerbcraftTorchflowerCount", this.herbcraft$torchflowerCount);
      output.putLong("HerbcraftTorchflowerExpiresAt", this.herbcraft$torchflowerExpiresAt);
      output.putInt("HerbcraftSugarCount", this.herbcraft$sugarCount);
      output.putLong("HerbcraftSugarExpiresAt", this.herbcraft$sugarExpiresAt);
      output.putInt("HerbcraftSlimeCount", this.herbcraft$slimeCount);
      output.putLong("HerbcraftSlimeExpiresAt", this.herbcraft$slimeExpiresAt);
      StringBuilder builder = new StringBuilder();
      this.herbcraft$knowledgeMap.forEach((key, state) -> {
         if (builder.length() > 0) {
            builder.append(';');
         }

         builder.append(key).append(':').append(state);
      });
      output.putString("HerbcraftKnowledge", builder.toString());
   }

   @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
   private void herbcraft$readData(ValueInput input, CallbackInfo ci) {
      this.herbcraft$herbStack = input.getIntOr("HerbcraftHerbStack", 0);
      this.herbcraft$herbExpiresAt = input.getLongOr("HerbcraftHerbExpiresAt", 0L);
      this.herbcraft$poppyCount = input.getIntOr("HerbcraftPoppyCount", 0);
      this.herbcraft$poppyExpiresAt = input.getLongOr("HerbcraftPoppyExpiresAt", 0L);
      this.herbcraft$torchflowerCount = input.getIntOr("HerbcraftTorchflowerCount", 0);
      this.herbcraft$torchflowerExpiresAt = input.getLongOr("HerbcraftTorchflowerExpiresAt", 0L);
      this.herbcraft$sugarCount = input.getIntOr("HerbcraftSugarCount", 0);
      this.herbcraft$sugarExpiresAt = input.getLongOr("HerbcraftSugarExpiresAt", 0L);
      this.herbcraft$slimeCount = input.getIntOr("HerbcraftSlimeCount", 0);
      this.herbcraft$slimeExpiresAt = input.getLongOr("HerbcraftSlimeExpiresAt", 0L);
      this.herbcraft$knowledgeMap.clear();
      String knowledge = input.getStringOr("HerbcraftKnowledge", "");
      if (!knowledge.isEmpty()) {
         for (String entry : knowledge.split(";")) {
            int split = entry.lastIndexOf(58);
            if (split > 0) {
               try {
                  this.herbcraft$knowledgeMap.put(entry.substring(0, split), Integer.parseInt(entry.substring(split + 1)));
               } catch (NumberFormatException var10) {
               }
            }
         }
      }
   }

   @Inject(method = "die", at = @At("TAIL"))
   private void herbcraft$clearOnDeath(DamageSource damageSource, CallbackInfo ci) {
      this.herbcraft$clearHerbStack();
   }
}
