# Example Herbcraft External Extension Compat Pack

This is a documentation-only example for the P2 external data merge layer.

It demonstrates future/additive paths under:

```text
data/example_compat/herbcraft/herb_natures/*.json
data/example_compat/herbcraft/nutrition_profiles/*.json
data/example_compat/herbcraft/special_counters/*.json
data/example_compat/herbcraft/knowledge_rumors/*.json
data/example_compat/herbcraft/codex_loot_injections/*.json
```

The example intentionally uses vanilla item IDs so the schema can be validated in the Herbcraft source tree without depending on another mod.
