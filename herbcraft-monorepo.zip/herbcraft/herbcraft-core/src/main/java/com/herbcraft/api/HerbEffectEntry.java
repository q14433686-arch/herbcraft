package com.herbcraft.api;

import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;

/** A read-only public description of one edible herb effect. */
public record HerbEffectEntry(
		Holder<MobEffect> effect,
		int amplifier,
		int durationTicks,
		float chance,
		boolean negative
) {}
