# NEXT_TASK

## Recommended next task: in-game verification pass for hodgepodge crafting and Codex UI

The next most valuable task is not a large new feature. It is a focused in-game verification pass for the newest fixes.

## Why this is next

Recent work changed client UI rendering and restored the data-driven custom hodgepodge recipe. Both compile and pass static checks, but they need real client/world validation.

## Scope

1. Launch a real client with:
   - `herbcraft-1.1.5.jar`
   - `herbcraft-alchemy-0.2.4.jar`
   - `herbcraft-cuisine-0.3.5.jar`
2. Test Herb Codex UI:
   - `zh_cn`
   - `en_us`
   - small window
   - GUI Scale 2
   - GUI Scale 3 or Auto
   - long entries in herbal/cuisine/alchemy chapters
3. Test hodgepodge survival crafting:
   - bowl + dandelion + oxeye daisy + cornflower
   - bowl + four valid herbs
   - invalid ingredient rejection
   - curated dish combinations still excluded
4. Test hodgepodge eating:
   - tooltip remains vague
   - empty bowl is returned
   - dynamic effects trigger
   - clear effects and clash nausea can occur under the correct ingredient mix

## Acceptance criteria

- Codex fullscreen background and panels are translucent, not solid black.
- Text remains legible in Chinese and English.
- Left navigation ellipsis and right-side scrolling still work.
- Hodgepodge appears as a survival craftable result for 3 and 4 valid herbs.
- Crafted hodgepodge carries `herbcraft_cuisine:hodgepodge_contents`.
- Eating hodgepodge returns a bowl and uses ingredient snapshot effects.
- No new crash, missing translation key, or data-pack error appears.

## If this passes

Then the next feature task can be P1 villager professions:

- Fisherman
- Shepherd
- Leatherworker
- Mason
