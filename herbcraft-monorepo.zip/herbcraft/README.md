# Herbcraft / 百草可食

Minecraft 26.1.2 + Fabric Loader 0.19.3 + Fabric API 0.151.0+26.1.2 monorepo.

This repository is split into two independent Fabric jars:

- `herbcraft-core` → `herbcraft`: the core edible-herb system.
- `herbcraft-alchemy` → `herbcraft-alchemy`: a separate add-on shell for the future essence/alchemy system.

## Build

Requires JDK 25+.

```bash
./gradlew build
```

Outputs:

```text
herbcraft-core/build/libs/herbcraft-1.0.0.jar
herbcraft-alchemy/build/libs/herbcraft-alchemy-0.1.0.jar
```

## Current milestone

- M0: monorepo dual-jar skeleton.
- Core migration: current edible item logic moved into `herbcraft-core` with mod id `herbcraft`.
- Alchemy is intentionally an empty dependent add-on until the core API/data layer is frozen.
