package com.herbcraft.alchemy.client;

import com.herbcraft.alchemy.armor.ArmorSupportComponent;
import com.herbcraft.alchemy.armor.ArmorSupportComponents;
import com.herbcraft.alchemy.armor.ArmorSupportRules;
import com.herbcraft.alchemy.registry.AlchemyRegistries;
import java.util.List;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;

public final class ArmorSupportTooltips {
   private ArmorSupportTooltips() {
   }

   public static void register() {
      ItemTooltipCallback.EVENT.register(ArmorSupportTooltips::appendTooltip);
   }

   private static void appendTooltip(ItemStack stack, TooltipContext context, TooltipFlag flag, List<Component> lines) {
      ArmorSupportComponent component = stack.get(ArmorSupportComponents.ARMOR_SUPPORT);
      if (component == null) return;
      int state = AlchemyKnowledgeClientSupport.armorSupportState(stack);
      ArmorSupportRules.support(component.supportId()).ifPresent(support -> {
         lines.add(Component.translatable("tooltip.herbcraft.armor_support", Component.translatable(support.langKey())).withStyle(ChatFormatting.AQUA));
         if (state >= 4 && !support.descriptionKey().isBlank()) {
            lines.add(Component.translatable(support.descriptionKey()).withStyle(ChatFormatting.GRAY));
         }
      });
      lines.add(Component.translatable("tooltip.herbcraft.armor_support.mode", Component.translatable("tooltip.herbcraft.armor_support.mode." + component.mode().getSerializedName())).withStyle(ChatFormatting.GRAY));
      AlchemyRegistries.essenceInfoById(component.sourceEssence()).ifPresent(info ->
         lines.add(Component.translatable("tooltip.herbcraft.armor_support.source", Component.translatable(info.item().getDescriptionId())).withStyle(ChatFormatting.DARK_GRAY))
      );
      if (state >= 4) {
         lines.add(Component.translatable("tooltip.herbcraft.armor_support.buffer", component.bufferAmount()).withStyle(ChatFormatting.DARK_GRAY));
      }
   }
}
