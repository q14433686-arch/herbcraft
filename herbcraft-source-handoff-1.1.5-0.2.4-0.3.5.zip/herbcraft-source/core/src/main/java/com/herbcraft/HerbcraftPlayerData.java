package com.herbcraft;

import java.util.Map;

public interface HerbcraftPlayerData {
   int herbcraft$getHerbStack(long var1);

   int herbcraft$addHerbStack(long var1);

   void herbcraft$clearHerbStack();

   int herbcraft$incrementWindowCounter(String var1, long var2, int var4);

   Map<String, Integer> herbcraft$knowledge();
}
