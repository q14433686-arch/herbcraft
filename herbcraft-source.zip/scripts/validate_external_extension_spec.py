#!/usr/bin/env python3
"""Validate draft Herbcraft external extension example data.

This is a source-tree/schema validator. It does not inspect a live modded
Minecraft registry, so it checks syntax and Herbcraft-supported value domains
rather than proving every third-party item exists.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "docs" / "examples" / "external_extension_compat_pack"
STARTUP_FOOD_EXAMPLE = ROOT / "docs" / "examples" / "startup_herb_food_extension_mod"
ID_RE = re.compile(r"^[a-z0-9_.-]+:[a-z0-9_./-]+$")

TEMPERATURES = {"cold", "cool", "neutral", "warm", "hot"}
FLAVORS = {"sweet", "bitter", "pungent", "sour", "astringent", "salty", "bland"}
TRAITS = {
    "clearing", "toxic", "nourishing", "stirring", "sedating", "aquatic", "fiery",
    "withered", "nether", "floral", "resinous", "fungal", "lunar", "solar", "leafy",
    "icy", "slimy", "honeyed", "earthy", "addictive", "curio",
}
DIMENSIONS = {"grain", "flesh", "oil", "vege", "fruit"}
PAGE_KINDS = {"common", "rare", "secret", "errata"}


def load(path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except Exception as exc:  # noqa: BLE001
        raise SystemExit(f"JSON parse failed: {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise SystemExit(f"Expected JSON object: {path}")
    return data


def require_id(value: str, path: Path, field: str) -> None:
    if not isinstance(value, str) or not ID_RE.match(value):
        raise SystemExit(f"Invalid identifier in {path} field {field}: {value!r}")


def entries(root: dict) -> list[dict]:
    if "entries" in root:
        if not isinstance(root["entries"], list):
            raise SystemExit("entries must be a list")
        return root["entries"]
    return [root]


def validate_natures() -> int:
    count = 0
    for path in (EXAMPLE / "data").glob("*/herbcraft/herb_natures/*.json"):
        for entry in entries(load(path)):
            require_id(entry.get("item"), path, "item")
            temp = entry.get("temperature", "neutral")
            if temp not in TEMPERATURES:
                raise SystemExit(f"Unknown temperature in {path}: {temp}")
            for field, allowed in (("flavors", FLAVORS), ("taste_flavors", FLAVORS), ("traits", TRAITS)):
                values = entry.get(field, [])
                if not isinstance(values, list):
                    raise SystemExit(f"{field} must be a list in {path}")
                for value in values:
                    if value not in allowed:
                        raise SystemExit(f"Unknown {field} value in {path}: {value}")
            count += 1
    return count


def validate_nutrition() -> int:
    count = 0
    for path in (EXAMPLE / "data").glob("*/herbcraft/nutrition_profiles/*.json"):
        for entry in entries(load(path)):
            require_id(entry.get("item"), path, "item")
            values = entry.get("values", entry)
            for dim, val in values.items():
                if dim in {"schema_version", "item"}:
                    continue
                if dim not in DIMENSIONS:
                    raise SystemExit(f"Unknown nutrition dimension in {path}: {dim}")
                if not isinstance(val, int) or val < 0:
                    raise SystemExit(f"Nutrition value must be non-negative int in {path}: {dim}={val!r}")
            count += 1
    return count


def validate_counters() -> int:
    count = 0
    for path in (EXAMPLE / "data").glob("*/herbcraft/special_counters/*.json"):
        root = load(path)
        rule_entries = root.get("counters") or root.get("entries") or [root]
        for entry in rule_entries:
            for item in entry.get("items", []):
                require_id(item, path, "items[]")
            for bucket in ("always_effects", "threshold_effects"):
                for effect in entry.get(bucket, []):
                    require_id(effect.get("effect"), path, f"{bucket}.effect")
                    if bucket == "threshold_effects" and int(effect.get("min_count", 1)) < 1:
                        raise SystemExit(f"min_count must be >= 1 in {path}")
            count += 1
    return count


def validate_rumors() -> int:
    count = 0
    lang_keys: set[str] = set()
    for lang in (EXAMPLE / "assets").glob("*/lang/*.json"):
        lang_keys.update(load(lang).keys())
    for path in (EXAMPLE / "data").glob("*/herbcraft/knowledge_rumors/*.json"):
        for entry in entries(load(path)):
            entry_key = entry.get("entry")
            if not isinstance(entry_key, str) or "/" not in entry_key:
                raise SystemExit(f"knowledge rumor entry must be chapter/entry in {path}: {entry_key!r}")
            for claim in entry.get("claims", []):
                text_key = claim.get("text_key")
                if text_key not in lang_keys:
                    raise SystemExit(f"Missing example lang key for {path}: {text_key}")
            count += 1
    return count


def validate_herb_foods() -> int:
    count = 0
    required = {
        "item",
        "nutrition",
        "saturation_modifier",
        "consume_seconds",
        "medicinal",
        "stack_group",
    }
    for path in (STARTUP_FOOD_EXAMPLE / "data").glob("*/herbcraft/herbs/*.json"):
        for entry in entries(load(path)):
            missing = sorted(required - set(entry))
            if missing:
                raise SystemExit(f"Missing herb food fields in {path}: {', '.join(missing)}")
            require_id(entry.get("item"), path, "item")
            if not isinstance(entry.get("nutrition"), int) or entry["nutrition"] < 0:
                raise SystemExit(f"nutrition must be non-negative int in {path}")
            if not isinstance(entry.get("saturation_modifier"), (int, float)):
                raise SystemExit(f"saturation_modifier must be number in {path}")
            if not isinstance(entry.get("consume_seconds"), (int, float)) or entry["consume_seconds"] <= 0:
                raise SystemExit(f"consume_seconds must be positive number in {path}")
            for field in ("medicinal", "stack_group"):
                if not isinstance(entry.get(field), bool):
                    raise SystemExit(f"{field} must be boolean in {path}")
            for effect in entry.get("effects", []):
                require_id(effect.get("effect"), path, "effects.effect")
            count += 1
    return count


def validate_codex_loot() -> int:
    count = 0
    for path in (EXAMPLE / "data").glob("*/herbcraft/codex_loot_injections/*.json"): 
        root = load(path)
        loot_entries = root.get("page_injections") or root.get("entries") or [root]
        for entry in loot_entries:
            require_id(entry.get("loot_table"), path, "loot_table")
            chance = entry.get("chance")
            if not isinstance(chance, (int, float)) or not (0.0 <= float(chance) <= 1.0):
                raise SystemExit(f"chance must be 0..1 in {path}: {chance!r}")
            kind = entry.get("page_kind", "common")
            if kind not in PAGE_KINDS:
                raise SystemExit(f"Unknown page_kind in {path}: {kind}")
            count += 1
    return count


def main() -> int:
    if not EXAMPLE.exists():
        raise SystemExit(f"Missing example pack: {EXAMPLE}")
    counts = {
        "natures": validate_natures(),
        "nutrition": validate_nutrition(),
        "counters": validate_counters(),
        "rumors": validate_rumors(),
        "codex_loot": validate_codex_loot(),
        "herb_foods": validate_herb_foods(),
    }
    print("EXTERNAL EXTENSION SPEC CHECK OK:", ", ".join(f"{k}={v}" for k, v in counts.items()))
    return 0


if __name__ == "__main__":
    sys.exit(main())
