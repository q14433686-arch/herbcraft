# NEXT_TASK

## Recommended next task: client-test `1.1.2` guidance, pharmacology, and raw-herb food-roll polish

The current source is packaged as the `1.1.2` release/test line with nutrition correction, 0.6x profile scaling, ingredients chapter, fluid surplus refinements, raw herb food-roll rebalance, and onboarding/Codex guidance polish.

Current status:

- P1 Homeostatic temperature research is documented; no temperature gameplay integration exists yet.
- P2 low-risk external server-data merge layer is implemented and server-smoked.
- P3 startup-only loaded-mod/addon herb food extension is implemented, server-smoked, and author client-tested PASS.
- Nutrition correction/recent-meal redesign is implemented in source and built jars:
  - recent 24 meal tracking;
  - 3-minute correction scoring window;
  - correction score threshold 60;
  - data-backed correction relationship matrix in `data/herbcraft/nutrition_correction_rules.json`;
  - excessive dimensions extra-decay every 200 ticks by 15..45;
  - correction target 650;
  - high `fruit` / 津液 / Fluids non-punitive in the base mod;
  - high 津液 surplus helper: when fruit >= 850 and at least two non-fruit dimensions above 850 share a correction-matrix relationship, normalizes those related excesses toward 700 by 10 per 200 ticks;
  - client status `correcting` / `饮食回正中`;
  - debug presets and validator.
- 食材录 (Ingredient Codex) chapter implemented: 39 vanilla foods, data-driven from `ingredients.json`, eating-gated knowledge.
- All nutrition profiles scaled to 0.6x for balanced pacing.
- `correction_high_threshold` lowered to 750 with graduated decay (half-speed 750-849, full-speed 850+).
- Fluid surplus helper now requires correction-matrix relationship between excess dimensions.
- P4 stable public Java extension events/API is **not** implemented.
- `1.1.2` new-player guidance Phase 1 is implemented: route-sign advancement descriptions, rewritten four-line 百草经总纲, and polished 食材录 wording.
- `1.1.2` new-player guidance Phase 2.1 is implemented: guide entries are data-backed by module-owned `codex_guides.json`; Cuisine/Alchemy guide pages are addon-owned; 五味/七情 principle discovery is persisted and can reveal guide lines with latest item examples. A small Codex microcopy pass now explains plainly that 性味 is pharmacology, not nutrition, and 七情 is recent-herb interaction, not a fixed recipe list.
- `1.1.2` one-time guide hints are implemented as data-backed module-owned `guide_hints.json` files plus `GuideHintManager` with persisted seen-hint IDs.
- Pharmacology qi/relation data tuning is implemented: `temperature_values` and ordered `seven_emotion_rules` are in `pharmacology_rules.json`; exact hot/cold same-qi now builds more slowly.
- P3.9 Cuisine/Alchemy module overview guides are implemented: `膳房录` and `炼金要术` now have their own overview sections and staged guide subentries.
- P3.10 raw herb hunger/saturation rebalance is implemented in source: `food_rolls` support exists, 70 raw herb entries were tuned, and `scripts/validate_raw_herb_food_balance.py` guards the new balance. Client survival feel testing found seeds/sugar cane too weak, so a follow-up tuning pass increased seed hidden-saturation roll amounts and sugar cane hidden saturation while keeping sugar cane visible hunger at +1; retest pending.
- Remaining immediate work after `1.1.2` packaging: real-client smoke test the final jars in module combinations, especially guide visibility, one-time hints, pharmacology tuning, Cuisine/Alchemy hidden-catalyst wording, and P3.10 raw herb food-roll balance.

## Why this is next

The ingredients chapter, nutrition scaling, and correction threshold change all need real-client verification. Test in a real client before further tuning.

Implementation report:

```text
docs/reports/NUTRITION_CORRECTION_IMPLEMENTATION_REPORT_20260615.md
```

Future ideas and a conservative `1.1.2` polish roadmap are collected in:

```text
docs/HERBCRAFT_FUTURE_IDEAS_AND_1_1_2_ROADMAP.md
```

Raw herb hunger/saturation rebalance source audit and refined parameter review are recorded in:

```text
docs/reports/HERB_FOOD_HUNGER_SATURATION_REBALANCE_REVIEW_20260616.md
docs/reports/HERB_FOOD_PROBABILITY_PARAMETER_REVIEW_20260616.md
docs/reports/HERB_FOOD_ROLLS_IMPLEMENTATION_REPORT_20260616.md
docs/reports/HERB_FOOD_SEED_SUGARCANE_TUNING_20260616.md
```

## Required next work

1. Client-test Phase 2.1/P3.7 guidance in four module combinations: Core only, Core + Cuisine, Core + Alchemy, and all three modules. Confirm addon guide pages and module-owned hints only appear with their addon, and confirm the new 五味/七情 Codex microcopy is clear enough without adding new advancements.
2. In a real client, trigger several pharmacology principles and verify 五味/七情 guide lines become clearer and show useful recent item examples without spoiling unearned item entries. Use `docs/reports/PHARMACOLOGY_SEVEN_EMOTION_TEST_MATRIX_20260616.md`.
3. Client-test pharmacology tuning: exact hot/cold should no longer trigger same-qi on the 3rd bite; with current values it should be closer to the 5th exact-hot/cold bite unless qi is already biased.
4. Client-test that data-backed seven-emotion relation rules still match the table in `docs/reports/PHARMACOLOGY_SEVEN_EMOTION_TEST_MATRIX_20260616.md`.
5. Client-test the implemented P3.10 raw herb hunger/saturation rebalance in the packaged `1.1.2` jars. In a fresh survival world, verify wildflowers/petals/ferns/leaves/saplings no longer act as reliable early food; retest seeds after the stronger hidden-saturation pass (`S+2` ordinary seeds, `S+3` melon/pumpkin seeds); sugar cane should remain visible +1 but now feel like juicy short fullness and Homeostatic hydration amount 3; blue orchid should no longer bypass the model with guaranteed `minecraft:saturation`.
6. Test debug presets:

```mcfunction
/herbcraft nutrition preset @p correcting_flesh
/herbcraft nutrition preset @p correcting_oil
/herbcraft nutrition preset @p correcting_grain
/herbcraft nutrition preset @p excess_fruit_nonpunitive
/herbcraft nutrition preset @p fluid_surplus_pair
/herbcraft nutrition preset @p fluid_surplus_single
/herbcraft nutrition preset @p fluid_surplus_unrelated
/herbcraft nutrition preset @p fruit_low
```

8. Check:
   - `饮食回正中` / correcting appears in the nutrition panel when correction is active;
   - high dimensions decay faster than the old `-2/minute` during correction;
   - high `fruit` / 津液 / Fluids does not apply negative dietary imbalance;
   - `fluid_surplus_pair` (flesh+vege+fruit=900) should show correcting status and both flesh/vege should decay;
   - `fluid_surplus_single` (flesh+fruit=900) should NOT trigger surplus decay;
   - `fluid_surplus_unrelated` (flesh+oil+fruit=900) should NOT trigger surplus decay (flesh↔oil have 0.0 weight);
   - low `fruit` / 津液 still applies deficiency;
   - normal deficiency, well_nourished, water bowl relief, Cuisine clearing isolation, and custom nutrition effects still behave correctly.
9. If behavior feels too weak/strong, tune:

```text
correction_high_threshold (now 750, was 850)
correction_score_threshold
correction_extra_decay_min
correction_extra_decay_max
correction_target_value
correction_recent_window_ticks
nutrition_correction_rules.json matrix weights
fluid_surplus_decay_amount
fluid_surplus_target_value
Note: 750-849 range uses half decay rate; 850+ uses full rate
```

10. Record client results in a new report under `docs/reports/`.
11. Only after `1.1.2` guidance and correction system are stable, draft P4 API design before coding:

```text
docs/PUBLIC_EXTENSION_API_DESIGN.md
```

## Do not do unless explicitly asked

- Do not claim P3 supports hot-reloadable world datapack FOOD/CONSUMABLE changes.
- Do not add a hard dependency on Homeostatic.
- Do not implement P4 Java API before nutrition correction client validation/tuning.
- Do not change stable IDs.
- Do not make main-mod nutrition more hardcore; reserve stricter mechanics for a future addon.

## Acceptance criteria

- Build passes.
- Validators in `CURRENT_BASELINE.md` pass, including `python3 scripts/validate_raw_herb_food_balance.py`.
- Client sanity pass has no visible blocker.
- Any new report is included in `herbcraft-source-current-20260614.zip`.
- `release_output/herbcraft_test_20260614_review/` contains current `1.1.2` jars and source zip, with the source zip still named `herbcraft-source-current-20260614.zip`.
- `CURRENT_BASELINE.md` is updated after any further modifying turn.
