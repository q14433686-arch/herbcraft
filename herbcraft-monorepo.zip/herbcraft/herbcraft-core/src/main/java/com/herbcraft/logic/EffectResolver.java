package com.herbcraft.logic;

import com.herbcraft.registry.HerbEntry;
import com.herbcraft.registry.HerbFoodRegistry;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import java.util.List;

public final class EffectResolver {
	private static final int SECOND = 20;

	private EffectResolver() {}

	public static void applyAfterConsume(ItemStack stack, Level level, LivingEntity entity) {
		if (level.isClientSide() || !(entity instanceof Player player)) return;
		HerbEntry entry = HerbFoodRegistry.get(stack);
		if (entry == null) return;

		long gameTime = level.getGameTime();
		int herbStack = HerbStackManager.updateAndGet(player, gameTime, entry.stackGroup);

		entry.removeEffects.forEach(player::removeEffect);
		if (entry.clearPositiveEffects) {
			List<Holder<MobEffect>> positiveEffects = player.getActiveEffects().stream()
					.filter(effect -> effect.getEffect().value().isBeneficial())
					.map(MobEffectInstance::getEffect)
					.toList();
			positiveEffects.forEach(player::removeEffect);
		}
		if (entry.extinguish) player.setRemainingFireTicks(0);

		entry.effects.forEach(effect -> applyEffect(player, effect, entry.stackGroup, herbStack));
		if (level instanceof ServerLevel serverLevel) {
			entry.damageEvents.forEach(event -> {
				if (roll(player, event.chance())) player.hurtServer(serverLevel, level.damageSources().magic(), event.amount());
			});
		}
		entry.healEvents.forEach(event -> {
			if (roll(player, event.chance())) player.heal(event.amount());
		});
		if (entry.bucketRemainder && !player.getAbilities().instabuild) player.addItem(new ItemStack(Items.BUCKET));

		SpecialCounters.apply(player, entry.item, gameTime);
		HerbStackManager.overloadIfNeeded(player, herbStack);
	}

	private static void applyEffect(Player player, HerbEntry.Effect effect, boolean herbGroup, int herbStack) {
		float probability = effect.chance();
		int amplifier = effect.amplifier();
		int durationTicks = effect.durationTicks();
		if (effect.positive() && herbGroup) {
			probability = Math.min(probability + 0.10F * Math.max(0, herbStack - 1), 0.90F);
			if (herbStack >= 5) amplifier = Math.min(amplifier + 1, 1);
			if (herbStack >= 8) durationTicks = Math.round(durationTicks * 1.5F);
		}
		if (roll(player, probability)) player.addEffect(new MobEffectInstance(effect.effect(), durationTicks, amplifier));
	}

	public static void addOverloadEffects(Player player) {
		player.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 10 * SECOND, 0));
		player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 10 * SECOND, 0));
	}

	public static boolean roll(Player player, float probability) {
		return probability >= 1.0F || player.getRandom().nextFloat() < probability;
	}
}
