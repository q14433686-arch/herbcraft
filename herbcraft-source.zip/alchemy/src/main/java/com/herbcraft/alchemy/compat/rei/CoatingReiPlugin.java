package com.herbcraft.alchemy.compat.rei;

import com.herbcraft.alchemy.coating.CoatingItems;
import com.herbcraft.alchemy.coating.CoatingSystem;
import com.herbcraft.alchemy.coating.WeaponCoating;
import com.herbcraft.alchemy.registry.AlchemyRegistries;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import me.shedaniel.rei.api.client.plugins.REIClientPlugin;
import me.shedaniel.rei.api.client.registry.display.DisplayRegistry;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryStacks;
import me.shedaniel.rei.plugin.common.SmithingDisplay;
import me.shedaniel.rei.plugin.common.displays.DefaultSmithingDisplay;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class CoatingReiPlugin implements REIClientPlugin {
   public void registerDisplays(DisplayRegistry registry) {
      for (AlchemyRegistries.EssenceInfo info : AlchemyRegistries.essenceInfos()) {
         registry.add(applyDisplay(info));
         if (info.effects().stream().anyMatch(AlchemyRegistries.EssenceEffect::positive)) {
            registry.add(refineDisplay(info, true));
         }
         if (info.effects().stream().anyMatch(effect -> !effect.positive())) {
            registry.add(refineDisplay(info, false));
         }
      }
   }

   private static DefaultSmithingDisplay applyDisplay(AlchemyRegistries.EssenceInfo info) {
      return new DefaultSmithingDisplay(
         List.of(
            entry(CoatingItems.BLANK_ADHESIVE),
            entryStacks(coatableWeaponStacks()),
            entry(info.item())
         ),
         List.of(entryStacks(coatedWeaponStacks(info, WeaponCoating.Mode.FULL))),
         Optional.of(SmithingDisplay.SmithingRecipeType.TRANSFORM),
         Optional.of(id("coating_apply_" + info.id()))
      );
   }

   private static DefaultSmithingDisplay refineDisplay(AlchemyRegistries.EssenceInfo info, boolean positive) {
      WeaponCoating.Mode refinedMode = positive ? WeaponCoating.Mode.POSITIVE : WeaponCoating.Mode.NEGATIVE;
      return new DefaultSmithingDisplay(
         List.of(
            entry(positive ? CoatingItems.AMETHYST_ADHESIVE : CoatingItems.ECHO_ADHESIVE),
            entryStacks(coatedWeaponStacks(info, WeaponCoating.Mode.FULL)),
            EntryIngredient.empty()
         ),
         List.of(entryStacks(coatedWeaponStacks(info, refinedMode))),
         Optional.of(SmithingDisplay.SmithingRecipeType.TRANSFORM),
         Optional.of(id("coating_refine_" + (positive ? "positive_" : "negative_") + info.id()))
      );
   }

   private static EntryIngredient entry(net.minecraft.world.level.ItemLike item) {
      return EntryIngredient.of(EntryStacks.of(item));
   }

   private static EntryIngredient entryStacks(List<ItemStack> stacks) {
      return EntryIngredient.of(stacks.stream().map(EntryStacks::of).toList());
   }

   private static List<ItemStack> coatableWeaponStacks() {
      List<ItemStack> stacks = new ArrayList<>();
      for (Holder<Item> holder : BuiltInRegistries.ITEM.getTagOrEmpty(CoatingSystem.COATABLE_WEAPONS)) {
         stacks.add(new ItemStack(holder.value()));
      }
      return stacks.isEmpty() ? List.of(new ItemStack(Items.IRON_SWORD)) : List.copyOf(stacks);
   }

   private static List<ItemStack> coatedWeaponStacks(AlchemyRegistries.EssenceInfo info, WeaponCoating.Mode mode) {
      List<ItemStack> stacks = new ArrayList<>();
      for (ItemStack base : coatableWeaponStacks()) {
         ItemStack coated = base.copyWithCount(1);
         CoatingSystem.applyCoating(coated, info, mode);
         stacks.add(coated);
      }
      return List.copyOf(stacks);
   }

   private static Identifier id(String path) {
      return Identifier.fromNamespaceAndPath("herbcraft", path);
   }
}
