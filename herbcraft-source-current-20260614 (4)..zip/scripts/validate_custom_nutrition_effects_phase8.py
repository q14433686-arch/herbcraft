#!/usr/bin/env python3
import json
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
EFFECTS = [
    "grain_deficiency", "flesh_deficiency", "oil_deficiency", "vege_deficiency",
    "fruit_deficiency", "dietary_imbalance", "well_nourished",
]
DEFICIENCIES = ["grain_deficiency", "flesh_deficiency", "oil_deficiency", "vege_deficiency", "fruit_deficiency"]
VANILLA_FORBIDDEN_IN_NUTRITION = [
    "MobEffects.WEAKNESS", "MobEffects.SLOWNESS", "MobEffects.MINING_FATIGUE",
    "MobEffects.HUNGER", "MobEffects.NAUSEA", "MobEffects.RESISTANCE",
]
errors = []

def require(cond, msg):
    if not cond:
        errors.append(msg)

def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

registry = read("core/src/main/java/com/herbcraft/effect/HerbcraftMobEffects.java")
nutrition_effect = read("core/src/main/java/com/herbcraft/effect/NutritionMobEffect.java")
nutrition = read("core/src/main/java/com/herbcraft/nutrition/NutritionManager.java")
commands = read("core/src/main/java/com/herbcraft/nutrition/NutritionDebugCommands.java")
effect_resolver = read("core/src/main/java/com/herbcraft/logic/EffectResolver.java")
dish_item = read("cuisine/src/main/java/com/herbcraft/cuisine/item/DishItem.java")
hodgepodge = read("cuisine/src/main/java/com/herbcraft/cuisine/item/HodgepodgeItem.java")
water_bowl = read("cuisine/src/main/java/com/herbcraft/cuisine/item/WaterBowlItem.java")
herbcraft = read("core/src/main/java/com/herbcraft/Herbcraft.java")
icon_script = read("scripts/generate_nutrition_effect_icons.py")

# Registration/resources.
require("Registry.registerForHolder(BuiltInRegistries.MOB_EFFECT" in registry, "custom effects are not registered into MOB_EFFECT registry")
require("isNutritionEffect" in registry, "missing nutrition-effect identification helper")
for effect in EFFECTS:
    require(f'"{effect}"' in registry, f"effect not declared in registry source: {effect}")
for lang in ["zh_cn", "en_us"]:
    data = json.load(open(ROOT / f"core/src/main/resources/assets/herbcraft/lang/{lang}.json", encoding="utf-8"))
    for effect in EFFECTS:
        require(data.get(f"effect.herbcraft.{effect}"), f"missing {lang} lang key for {effect}")
require("HerbcraftMobEffects.initialize();" in herbcraft, "Herbcraft initializer does not load custom mob effects")

# Icon checks: generated from vanilla item textures, 18x18, deficiency down arrows and well-nourished up arrow.
require("minecraft-client.jar" in icon_script and "assets/minecraft/textures/item/" in icon_script, "nutrition icon generator should derive icons from vanilla item textures")
for token in ["wheat.png", "cooked_beef.png", "honeycomb.png", "kelp.png", "melon_slice.png", "suspicious_stew.png", "golden_apple.png"]:
    require(token in icon_script, f"nutrition icon generator missing vanilla base texture {token}")
for effect in EFFECTS:
    icon = ROOT / f"core/src/main/resources/assets/herbcraft/textures/mob_effect/{effect}.png"
    require(icon.exists(), f"missing mob effect icon: {effect}.png")
    if icon.exists():
        require(icon.read_bytes().startswith(b"\x89PNG\r\n\x1a\n"), f"mob effect icon is not PNG: {effect}.png")
        img = Image.open(icon).convert("RGBA")
        require(img.size == (18, 18), f"mob effect icon should be 18x18: {effect}.png")
        pixels = list(img.get_flattened_data() if hasattr(img, "get_flattened_data") else img.getdata())
        require(sum(1 for p in pixels if p[3] > 0) > 40, f"mob effect icon appears mostly empty: {effect}.png")
        if effect in DEFICIENCIES:
            red_pixels = sum(1 for r, g, b, a in pixels if a > 0 and r > 150 and g < 80 and b < 80)
            require(red_pixels >= 4, f"deficiency icon lacks red down-arrow pixels: {effect}.png")
        if effect == "well_nourished":
            green_pixels = sum(1 for r, g, b, a in pixels if a > 0 and g > 150 and r < 130 and b < 130)
            require(green_pixels >= 4, "well_nourished icon lacks green up-arrow/accent pixels")

# Effect mechanics.
for needle, msg in [
    ("Attributes.BLOCK_BREAK_SPEED", "grain_deficiency lacks block break speed modifier"),
    ("grain_deficiency_break_speed", "grain_deficiency lacks named modifier"),
    ("-0.15D", "grain_deficiency lacks -15% modifier"),
    ("Attributes.ATTACK_DAMAGE", "flesh_deficiency lacks attack damage modifier"),
    ("-1.0D", "flesh_deficiency lacks -1 damage modifier"),
    ("oil_deficiency_movement_speed", "oil_deficiency lacks movement modifier"),
    ("-0.08D", "oil_deficiency lacks -8% movement modifier"),
    ("fruit_deficiency_movement_speed", "fruit_deficiency lacks movement modifier"),
    ("-0.05D", "fruit_deficiency lacks -5% movement modifier"),
    ("dietary_imbalance_movement_speed", "dietary_imbalance lacks movement modifier"),
    ("-0.03D", "dietary_imbalance lacks -3% movement modifier"),
    ("4 * SECOND, 0.08F", "vege_deficiency lacks 4s/+0.08 exhaustion"),
    ("6 * SECOND, 0.04F", "dietary_imbalance lacks 6s/+0.04 exhaustion"),
    ("well_nourished_armor", "well_nourished lacks armor modifier"),
    ("3.0D", "well_nourished lacks +3 armor"),
    ("well_nourished_knockback_resistance", "well_nourished lacks knockback modifier"),
    ("0.12D", "well_nourished lacks +12% knockback resistance"),
]:
    require(needle in registry, msg)
require("causeFoodExhaustion" in nutrition_effect and "amplifier + 1" in nutrition_effect, "NutritionMobEffect exhaustion behavior missing or not amplifier-scaled")

# NutritionManager migration, refresh and sustained serious states.
for token in VANILLA_FORBIDDEN_IN_NUTRITION:
    require(token not in nutrition, f"NutritionManager still references old vanilla nutrition/balanced effect: {token}")
for constant in ["GRAIN_DEFICIENCY", "FLESH_DEFICIENCY", "OIL_DEFICIENCY", "VEGE_DEFICIENCY", "FRUIT_DEFICIENCY", "DIETARY_IMBALANCE", "WELL_NOURISHED"]:
    require(f"HerbcraftMobEffects.{constant}" in nutrition or f"{constant}" in registry, f"missing use/registration of {constant}")
require("int sustainedTicks = sustainedEffectTicks(rules);" in nutrition, "NutritionManager does not compute sustained effect duration at evaluation start")
require("clearNutritionEffects(player);" in nutrition, "NutritionManager does not clear stale nutrition effects before re-evaluation")
require("private static void clearNutritionEffects" in nutrition and "filter(HerbcraftMobEffects::isNutritionEffect)" in nutrition, "clearNutritionEffects does not remove only Herbcraft nutrition effects")
require("return Math.max(400, rules.checkIntervalTicks + 200);" in nutrition, "sustained effect duration should cover next check interval")
require("if (player.getRandom().nextFloat() < 0.80F)" not in nutrition, "starved state is still random")
require("DANGER_DEBUFF_TICKS" not in nutrition, "danger state still uses old short duration constant")
require("STARVED_DEBUFF_TICKS" not in nutrition, "starved state still uses old short duration constant")
require("IMBALANCED_DEBUFF_TICKS" not in nutrition, "confirmed imbalance still uses old short duration constant")
require("case \"grain\" -> addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.GRAIN_DEFICIENCY, sustainedTicks, 0));" in nutrition, "grain danger is not sustained/deterministic")
require(nutrition.count("HerbcraftMobEffects.GRAIN_DEFICIENCY, sustainedTicks") == 2, "grain_deficiency sustained use should be starved + danger only; duplicate grain danger may remain")
require("state.shouldApplyDebuff()) {\n            addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.DIETARY_IMBALANCE, sustainedTicks, 0));" in nutrition, "confirmed imbalance is not sustained after grace")
require("new MobEffectInstance(HerbcraftMobEffects.WELL_NOURISHED, 1800" in nutrition, "balanced state does not apply well_nourished")

# Debug commands.
require("CommandRegistrationCallback.EVENT.register" in commands, "nutrition debug command is not registered")
require("Commands.literal(\"herbcraft\")" in commands and "Commands.literal(\"nutrition\")" in commands, "missing /herbcraft nutrition command tree")
for token in ["get", "set", "preset", "grain_low", "flesh_low", "oil_low", "vege_low", "fruit_low", "starved", "balanced"]:
    require(f'"{token}"' in commands, f"nutrition debug command missing token/preset: {token}")
require("setNutritionForDebug" in nutrition and "applyNutritionPresetForDebug" in nutrition, "NutritionManager lacks debug mutation APIs")
require("Commands.hasPermission(Commands.LEVEL_GAMEMASTERS)" in commands, "nutrition debug command should require gamemaster permission")

# Water bowl relief and clear isolation.
require("DIETARY_IMBALANCE_RELIEF_TICKS = 1200" in nutrition, "dietary imbalance water-bowl relief should last 1200 ticks / 60s")
require("relieveDietaryImbalance" in nutrition, "NutritionManager lacks water-bowl dietary imbalance relief API")
require("!isDietaryImbalanceRelieved(player) && state.shouldApplyDebuff()" in nutrition, "temporary relief does not suppress dietary imbalance reapplication")
require("filter(effect -> !HerbcraftMobEffects.isNutritionEffect(effect))" in effect_resolver, "EffectResolver.clearPositiveEffects does not skip nutrition effects")
require("filter(effect -> !HerbcraftMobEffects.isNutritionEffect(effect))" in dish_item, "DishItem.clear_all_effects does not skip nutrition effects")
require("filter(effect -> !HerbcraftMobEffects.isNutritionEffect(effect))" in hodgepodge, "HodgepodgeItem.clearPositiveEffects does not skip nutrition effects")
require("CLEAR_NAUSEA_CHANCE = 0.15F" in water_bowl, "water bowl relief chance must remain 15%")
require("removeEffect(MobEffects.NAUSEA)" in water_bowl, "WaterBowlItem should still clear vanilla nausea on success")
require("NutritionManager.relieveDietaryImbalance" in water_bowl, "WaterBowlItem does not trigger temporary dietary imbalance relief")
require("nutritionState" not in water_bowl and "setDirect" not in water_bowl, "WaterBowlItem must not directly repair nutrition values")

if errors:
    print("FAIL")
    for err in errors:
        print(" -", err)
    raise SystemExit(1)
print("PASS - vanilla-derived nutrition icons, stale effect refresh, sustained serious malnutrition, debug commands, well_nourished, water relief, mechanics, and clear isolation are intact.")
