package com.herbcraft.nutrition;

import com.herbcraft.HerbcraftPlayerData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;

public final class NutritionManager {
   private static final Identifier FLESH_ATTACK_ID = Identifier.fromNamespaceAndPath("herbcraft", "flesh_abundant_attack");
   private static final Identifier FRUIT_SPEED_ID = Identifier.fromNamespaceAndPath("herbcraft", "fruit_abundant_speed");

   // Debuff durations (ticks) — unified and reasonable
   private static final int DANGER_DEBUFF_TICKS = 200;   // 10s
   private static final int WARNING_DEBUFF_TICKS = 100;   // 5s
   private static final int EXCESS_DEBUFF_TICKS = 80;     // 4s
   private static final int STARVED_DEBUFF_TICKS = 300;   // 15s
   private static final int IMBALANCED_DEBUFF_TICKS = 100; // 5s

   private NutritionManager() {}

   public static void onFoodConsumed(ServerPlayer player, ItemStack stack) {
      NutritionRegistry.get(stack).ifPresent(profile -> {
         if (!profile.isEmpty()) {
            PlayerNutritionState state = nutritionState(player);
            state.addFromProfile(profile);
            syncToClient(player);
         }
      });
   }

   /** Called every server tick per player. */
   public static void tick(ServerPlayer player, long gameTime) {
      PlayerNutritionState state = nutritionState(player);
      boolean decayed = state.tickDecay(gameTime);
      if (state.shouldCheck(gameTime)) {
         evaluateAndApply(player, state);
      }
      if (decayed) syncToClient(player);
   }

   /** Called on player login — reapply modifiers immediately. (Fix #1: cold start) */
   public static void onLogin(ServerPlayer player) {
      evaluateAndApply(player, nutritionState(player));
      syncToClient(player);
   }

   public static void onDeath(ServerPlayer player) {
      nutritionState(player).resetOnDeath();
      removeAllModifiers(player);
   }

   public static PlayerNutritionState nutritionState(ServerPlayer player) {
      return ((HerbcraftPlayerData) player).herbcraft$nutritionState();
   }

   private static void evaluateAndApply(ServerPlayer player, PlayerNutritionState state) {
      NutritionRules rules = NutritionRules.current();

      // Compute cross-dimension stats first
      int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
      boolean allCritical = true;
      for (String dim : NutritionProfile.DIMENSIONS) {
         int v = state.get(dim);
         if (v < min) min = v;
         if (v > max) max = v;
         if (v >= rules.malnutritionLow) allCritical = false;
      }

      // Fix #2: If STARVED, only apply global penalty, skip per-dimension danger
      if (allCritical) {
         if (player.getRandom().nextFloat() < 0.80F) {
            player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, STARVED_DEBUFF_TICKS, 0));
            player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, STARVED_DEBUFF_TICKS, 0));
            player.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, STARVED_DEBUFF_TICKS, 0));
         }
         if (state.canWarn(player.level().getGameTime())) {
            player.sendSystemMessage(Component.translatable("nutrition.herbcraft.state.starved").withStyle(ChatFormatting.RED));
         }
         // Remove all positive modifiers when starved
         removeAllModifiers(player);
         syncToClient(player);
         return; // Skip per-dimension evaluation — STARVED supersedes everything
      }

      // Per-dimension gradient evaluation (only when NOT starved)
      for (String dim : NutritionProfile.DIMENSIONS) {
         int value = state.get(dim);
         applyDimensionEffects(player, dim, value, rules);
      }

      // Fix #4: IMBALANCED with debuff cooldown via badStateStreak
      if (max - min > 500 && max > rules.imbalanceHigh) {
         // Only apply debuff if persistent (grace checks)
         state.incrementBadStreak();
         if (state.shouldApplyDebuff()) {
            float chance = rules.minorDebuffChance;
            if (player.getRandom().nextFloat() < chance) {
               player.addEffect(new MobEffectInstance(MobEffects.NAUSEA, IMBALANCED_DEBUFF_TICKS, 0));
            }
         }
         if (state.canWarn(player.level().getGameTime())) {
            player.sendSystemMessage(Component.translatable("nutrition.herbcraft.state.imbalanced").withStyle(ChatFormatting.GOLD));
         }
      } else {
         state.clearBadStreak();
      }

      // BALANCED: all in [fullBalanceMin, fullBalanceMax]
      boolean balanced = true;
      for (String dim : NutritionProfile.DIMENSIONS) {
         int v = state.get(dim);
         if (v < rules.fullBalanceMin || v > rules.fullBalanceMax) { balanced = false; break; }
      }
      applyBalancedModifier(player, balanced);

      syncToClient(player);
   }

   private static void applyDimensionEffects(ServerPlayer player, String dim, int value, NutritionRules rules) {
      // === DANGER (0~149) ===
      if (value < rules.malnutritionLow) {
         float chance = 0.80F;
         switch (dim) {
            case "grain" -> { if (roll(player, chance)) { player.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, DANGER_DEBUFF_TICKS, 0)); player.addEffect(new MobEffectInstance(MobEffects.HUNGER, DANGER_DEBUFF_TICKS, 0)); } }
            case "flesh" -> { if (roll(player, chance)) player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, DANGER_DEBUFF_TICKS, 0)); }
            case "oil"   -> { if (roll(player, 0.40F)) player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, DANGER_DEBUFF_TICKS, 0)); }
            case "vege"  -> { if (roll(player, 0.60F)) player.addEffect(new MobEffectInstance(MobEffects.HUNGER, DANGER_DEBUFF_TICKS, 0)); }
            case "fruit" -> { if (roll(player, 0.60F)) player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, DANGER_DEBUFF_TICKS, 0)); }
         }
         removeAbundantModifier(player, dim);
         return;
      }

      // === WARNING (150~349) ===
      if (value < 350) {
         float gradient = 1.0F - (float)(value - rules.malnutritionLow) / 200.0F;
         float chance = 0.05F + gradient * 0.13F;
         switch (dim) {
            case "grain" -> { if (roll(player, chance)) player.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, WARNING_DEBUFF_TICKS, 0)); }
            case "flesh" -> { if (roll(player, chance)) player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, WARNING_DEBUFF_TICKS, 0)); }
            case "oil"   -> {} // warning oil: message only
            case "vege"  -> { if (roll(player, chance * 0.7F)) player.addEffect(new MobEffectInstance(MobEffects.HUNGER, WARNING_DEBUFF_TICKS, 0)); }
            case "fruit" -> { if (roll(player, chance * 0.7F)) player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, WARNING_DEBUFF_TICKS, 0)); }
         }
         removeAbundantModifier(player, dim);
         return;
      }

      // === NORMAL (350~649) ===
      if (value < 650) {
         removeAbundantModifier(player, dim);
         return;
      }

      // === ABUNDANT (650~849) ===
      if (value < 850) {
         applyAbundantModifier(player, dim);
         return;
      }

      // === EXCESS (850~1000) ===
      applyAbundantModifier(player, dim);
      switch (dim) {
         case "flesh" -> { if (roll(player, 0.10F)) player.addEffect(new MobEffectInstance(MobEffects.HUNGER, EXCESS_DEBUFF_TICKS, 0)); }
         case "oil"   -> { if (roll(player, 0.08F)) player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, EXCESS_DEBUFF_TICKS, 0)); }
         case "fruit" -> { if (roll(player, 0.10F)) player.addEffect(new MobEffectInstance(MobEffects.NAUSEA, EXCESS_DEBUFF_TICKS, 0)); }
         default -> {}
      }
   }

   private static void applyAbundantModifier(ServerPlayer player, String dim) {
      switch (dim) {
         case "flesh" -> {
            AttributeInstance attack = player.getAttribute(Attributes.ATTACK_DAMAGE);
            if (attack != null && !attack.hasModifier(FLESH_ATTACK_ID))
               attack.addTransientModifier(new AttributeModifier(FLESH_ATTACK_ID, 1.0, AttributeModifier.Operation.ADD_VALUE));
         }
         case "fruit" -> {
            AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null && !speed.hasModifier(FRUIT_SPEED_ID))
               speed.addTransientModifier(new AttributeModifier(FRUIT_SPEED_ID, 0.05, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
         }
         default -> {}
      }
   }

   private static void removeAbundantModifier(ServerPlayer player, String dim) {
      switch (dim) {
         case "flesh" -> { AttributeInstance a = player.getAttribute(Attributes.ATTACK_DAMAGE); if (a != null) a.removeModifier(FLESH_ATTACK_ID); }
         case "fruit" -> { AttributeInstance s = player.getAttribute(Attributes.MOVEMENT_SPEED); if (s != null) s.removeModifier(FRUIT_SPEED_ID); }
         default -> {}
      }
   }

   private static void applyBalancedModifier(ServerPlayer player, boolean balanced) {
      if (balanced) {
         // Hidden Resistance I — no particles, no icon, just silent toughness
         // "饮食均衡，身体底子稳了。" — a well-fed body takes less damage
         if (!player.hasEffect(MobEffects.RESISTANCE) || isHerbcraftResistance(player)) {
            player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 1800, 0, true, false, false));
         }
      }
      // When not balanced, resistance naturally expires (duration 90s, re-checked every 60s)
      // No need to manually remove — it fades gracefully
   }

   private static boolean isHerbcraftResistance(ServerPlayer player) {
      MobEffectInstance existing = player.getEffect(MobEffects.RESISTANCE);
      return existing != null && existing.isAmbient() && !existing.isVisible();
   }

   private static void removeAllModifiers(ServerPlayer player) {
      // Balanced resistance expires naturally, no manual removal needed
      AttributeInstance attack = player.getAttribute(Attributes.ATTACK_DAMAGE);
      if (attack != null) attack.removeModifier(FLESH_ATTACK_ID);
      AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
      if (speed != null) speed.removeModifier(FRUIT_SPEED_ID);
   }

   private static boolean roll(ServerPlayer player, float chance) {
      return player.getRandom().nextFloat() < chance;
   }

   public static void syncToClient(ServerPlayer player) {
      net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player, NutritionSyncPayload.build(player));
   }
}
