# Herbcraft Compat: Farmer's Delight + More Delight

Generated draft Herbcraft compatibility data pack.

Namespace: `farmers_moredelight_herbcraft`
Rows read: 108

Generated surfaces:

- nutrition_profiles: 108 entries
- ingredients: 108 entries
- herb_natures: 5 entries
- knowledge_rumors: 0 entries

Review all values manually before release. This generator does not know real balance, cuisine context, or herb pharmacology; it only writes valid draft JSON from the CSV table.
