package com.herbcraft.effect;

import com.herbcraft.Herbcraft;
import java.util.Set;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

public final class HerbcraftMobEffects {
   private static final int SECOND = 20;

   public static final Holder<MobEffect> GRAIN_DEFICIENCY = register(
      "grain_deficiency",
      new NutritionMobEffect(MobEffectCategory.HARMFUL, 0xC8A85A)
         .addAttributeModifier(Attributes.BLOCK_BREAK_SPEED, id("grain_deficiency_break_speed"), -0.15D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)
   );
   public static final Holder<MobEffect> FLESH_DEFICIENCY = register(
      "flesh_deficiency",
      new NutritionMobEffect(MobEffectCategory.HARMFUL, 0x9A4A45)
         .addAttributeModifier(Attributes.ATTACK_DAMAGE, id("flesh_deficiency_attack_damage"), -1.0D, AttributeModifier.Operation.ADD_VALUE)
   );
   public static final Holder<MobEffect> OIL_DEFICIENCY = register(
      "oil_deficiency",
      new NutritionMobEffect(MobEffectCategory.HARMFUL, 0xB8A060)
         .addAttributeModifier(Attributes.MOVEMENT_SPEED, id("oil_deficiency_movement_speed"), -0.08D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)
   );
   public static final Holder<MobEffect> VEGE_DEFICIENCY = register(
      "vege_deficiency",
      new NutritionMobEffect(MobEffectCategory.HARMFUL, 0x6F9B4A, 4 * SECOND, 0.08F)
   );
   public static final Holder<MobEffect> FRUIT_DEFICIENCY = register(
      "fruit_deficiency",
      new NutritionMobEffect(MobEffectCategory.HARMFUL, 0xB66AA0)
         .addAttributeModifier(Attributes.MOVEMENT_SPEED, id("fruit_deficiency_movement_speed"), -0.05D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)
   );
   public static final Holder<MobEffect> DIETARY_IMBALANCE = register(
      "dietary_imbalance",
      new NutritionMobEffect(MobEffectCategory.HARMFUL, 0x7F6AAE, 6 * SECOND, 0.04F)
         .addAttributeModifier(Attributes.MOVEMENT_SPEED, id("dietary_imbalance_movement_speed"), -0.03D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)
   );
   public static final Holder<MobEffect> WELL_NOURISHED = register(
      "well_nourished",
      new NutritionMobEffect(MobEffectCategory.BENEFICIAL, 0x77B86A)
         .addAttributeModifier(Attributes.ARMOR, id("well_nourished_armor"), 3.0D, AttributeModifier.Operation.ADD_VALUE)
         .addAttributeModifier(Attributes.KNOCKBACK_RESISTANCE, id("well_nourished_knockback_resistance"), 0.12D, AttributeModifier.Operation.ADD_VALUE)
   );

   private static final Set<Identifier> NUTRITION_EFFECT_IDS = Set.of(
      id("grain_deficiency"),
      id("flesh_deficiency"),
      id("oil_deficiency"),
      id("vege_deficiency"),
      id("fruit_deficiency"),
      id("dietary_imbalance"),
      id("well_nourished")
   );

   private HerbcraftMobEffects() {
   }

   public static void initialize() {
      Herbcraft.LOGGER.info("Registered {} Herbcraft nutrition effects.", NUTRITION_EFFECT_IDS.size());
   }

   public static boolean isNutritionEffect(Holder<MobEffect> effect) {
      return effect.unwrapKey().map(key -> NUTRITION_EFFECT_IDS.contains(key.identifier())).orElse(false);
   }

   public static boolean isNutritionEffect(MobEffect effect) {
      Identifier key = BuiltInRegistries.MOB_EFFECT.getKey(effect);
      return key != null && NUTRITION_EFFECT_IDS.contains(key);
   }

   private static Holder<MobEffect> register(String name, MobEffect effect) {
      Identifier id = id(name);
      ResourceKey<MobEffect> key = ResourceKey.create(Registries.MOB_EFFECT, id);
      return Registry.registerForHolder(BuiltInRegistries.MOB_EFFECT, key, effect);
   }

   private static Identifier id(String name) {
      return Identifier.fromNamespaceAndPath(Herbcraft.MOD_ID, name);
   }
}
