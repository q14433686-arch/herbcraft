# BUGS_TODO

## Known bugs by priority

| Priority | Status | Item |
|---:|---|---|
| P0 | Needs real-client verification | Confirm `herbcraft_cuisine:hodgepodge` survival crafting appears in a real crafting grid with 3 and 4 valid herbs. Static checks and build pass. |
| P0 | Needs real-client verification | Confirm Herb Codex panel translucency and readability in zh_cn/en_us, small windows and GUI Scale 2/3/Auto. |
| P1 | Open | Some sandbox server smoke tests time out before full world ready due slow MC 26.1 startup. No build/data errors observed, but local real-world smoke is recommended. |
| P2 | Open | Alchemy dependency is looser (`herbcraft >=1.1.2`) than the latest recommended core (`1.1.5`). This is compatible but may be tightened in a future release. |

## TODO / new feature ideas

| Priority | Idea |
|---:|---|
| P1 | Add light villager trades for Fisherman, Shepherd, Leatherworker and Mason if the design table is provided. |
| P1 | Add real client screenshots/testing notes for Herb Codex UI layouts. |
| P2 | Add a minimal in-game command or GameTest-style diagnostic for hodgepodge ingredient snapshots. |
| P2 | Revisit REI support only after a REI build supports Minecraft 26.1.x. |
| P2 | Add more specific hodgepodge tooltip lines for advanced players, while preserving unknown/immersive behavior. |
| P3 | Improve English flavor text for Codex entries beyond current key parity. |

## Recently fixed

- High-tier randomized potions could not be sold to villagers: fixed in alchemy `0.2.4` with minimal `ItemCost` Mixin.
- Herb Codex fullscreen background became opaque black: fixed with `0x80000000` overlay.
- Herb Codex panels were too opaque: fixed with translucent smoke-glass panel colors.
- Hodgepodge dynamic effects were incomplete: fixed by resolving full `HerbEntry` from ingredient snapshots.
- Hodgepodge had a custom recipe class but no actual recipe JSON: fixed by adding `data/herbcraft_cuisine/recipe/hodgepodge.json`.
- `#herbcraft:herb` was missing: fixed by generating the tag from current core herb definitions.
