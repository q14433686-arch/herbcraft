package com.herbcraft.nutrition.client;

import com.herbcraft.knowledge.client.CodexTextLayout;
import com.herbcraft.nutrition.NutritionProfile;
import com.herbcraft.nutrition.NutritionRules;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
/**
 * Nutrition panel screen with per-dimension colored bars, item icons, and proper ARGB colors.
 */
public class NutritionPanelScreen extends Screen {
   private static final int PANEL_W = 240;
   private static final int PANEL_H = 170;
   private static final int BAR_W = 100;
   private static final int BAR_H = 8;
   private static final int ROW_H = 20;

   // Per-dimension ARGB bar colors (fully opaque)
   private static final int[] DIM_COLORS = {
      0xFFDAA520,  // grain  — golden
      0xFFCD5C5C,  // flesh  — dark red
      0xFFFF8C00,  // oil    — orange
      0xFF32CD32,  // vege   — lime green
      0xFFDDA0DD,  // fruit  — plum/purple-pink
   };

   // Per-dimension representative item icons
   private static net.minecraft.world.item.ItemStack[] dimIcons() {
      return new net.minecraft.world.item.ItemStack[]{
         new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.BREAD),
         new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.COOKED_BEEF),
         new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.HONEYCOMB),
         new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.CARROT),
         new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.APPLE),
      };
   }

   public NutritionPanelScreen() {
      super(Component.translatable("nutrition.herbcraft.panel.title"));
   }

   @Override
   public boolean isPauseScreen() { return false; }

   @Override
   public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
      if (event.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_N) {
         this.onClose();
         return true;
      }
      return super.keyPressed(event);
   }

   @Override
   public void extractRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(extractor, mouseX, mouseY, partialTick);

      NutritionRules rules = NutritionRules.current();
      int maxValue = rules.maxValue;
      int cx = this.width / 2;
      int cy = this.height / 2;
      int panelX = cx - PANEL_W / 2;
      int panelY = cy - PANEL_H / 2;

      // 1. Full-screen overlay (ARGB: semi-transparent black)
      extractor.fill(0, 0, this.width, this.height, 0x80000000);

      // 2. Panel border (ARGB: golden frame)
      extractor.fill(panelX - 2, panelY - 2, panelX + PANEL_W + 2, panelY + PANEL_H + 2, 0xFFC0A060);
      // 3. Panel background (ARGB: dark, mostly opaque)
      extractor.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, 0xD0101010);
      // Text is also trimmed/wrapped below, but the scissor is a final hard guard
      // so translated strings can never draw outside the nutrition panel.
      extractor.enableScissor(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H);

      // 4. Title. Keep it inside the panel in every language.
      int innerTextWidth = PANEL_W - 16;
      Component title = Component.translatable("nutrition.herbcraft.panel.title");
      drawCenteredTrimmed(extractor, title, cx, panelY + 8, innerTextWidth, 0xFFDAA520);

      // 5. Five-dimension rows
      int rowStartY = panelY + 28;
      int iconX = panelX + 8;
      int labelX = panelX + 30;
      int barX = panelX + 80;
      int valueX = barX + BAR_W + 6;

      for (int i = 0; i < NutritionProfile.DIMENSIONS.length; i++) {
         String dim = NutritionProfile.DIMENSIONS[i];
         int value = NutritionClientCache.get(dim);
         int y = rowStartY + i * ROW_H;

         // Item icon (16x16)
         net.minecraft.world.item.ItemStack[] icons = dimIcons();
         extractor.fakeItem(icons[i], iconX, y - 4);

         // Label. Trim defensively so long translated dimension names cannot overlap the bar.
         Component label = Component.translatable("nutrition.herbcraft.dimension." + dim);
         int labelMaxWidth = Math.max(8, barX - labelX - 4);
         drawTrimmed(extractor, label, labelX, y + 1, labelMaxWidth, 0xFFAAAAAA);

         // Bar border (1px)
         extractor.fill(barX - 1, y - 1, barX + BAR_W + 1, y + BAR_H + 1, 0xFF666666);
         // Bar background
         extractor.fill(barX, y, barX + BAR_W, y + BAR_H, 0xFF333333);
         // Bar fill
         int fillW = maxValue > 0 ? Math.min((int)((float)value / maxValue * BAR_W), BAR_W) : 0;
         if (fillW > 0) {
            int barColor;
            if (value < rules.malnutritionLow) {
               barColor = 0xFFFF0000;        // Red warning
            } else if (value > rules.imbalanceHigh) {
               barColor = 0xFFFFFFFF;         // White overflow
            } else {
               barColor = DIM_COLORS[i];      // Dimension-specific color
            }
            extractor.fill(barX, y, barX + fillW, y + BAR_H, barColor);
         }

         // Value text
         float percent = maxValue > 0 ? (float) value / maxValue * 100f : 0f;
         String valueText = String.format("%.1f%%", percent);
         extractor.text(this.font, valueText, valueX, y + 1, 0xFFCCCCCC);
      }

      // 6. Status line
      int statusY = rowStartY + NutritionProfile.DIMENSIONS.length * ROW_H + 6;
      int statusCode = NutritionClientCache.statusCode();
      int statusColor = NutritionClientCache.isBad() ? 0xFFFF5555 : NutritionClientCache.isCorrecting() ? 0xFF55FFAA : NutritionClientCache.isGood() ? 0xFF55FF55 : 0xFFCCCCCC;
      Component statusText = Component.translatable("nutrition.herbcraft.panel.state")
         .append(Component.translatable(NutritionClientCache.statusTranslationKey()));
      drawCenteredWrappedLimited(extractor, statusText, cx, statusY, innerTextWidth, 2, statusColor);

      // 7. Key hint. Trim defensively like the Codex left panel.
      int hintY = panelY + PANEL_H - 14;
      Component hint = Component.translatable("nutrition.herbcraft.panel.hint");
      drawCenteredTrimmed(extractor, hint, cx, hintY, innerTextWidth, 0xFF888888);
      extractor.disableScissor();
   }

   private void drawTrimmed(GuiGraphicsExtractor extractor, Component text, int x, int y, int maxWidth, int color) {
      Component display = CodexTextLayout.trimWithEllipsis(this.font, text, Math.max(1, maxWidth));
      extractor.text(this.font, display.getVisualOrderText(), x, y, color);
   }

   private void drawCenteredTrimmed(GuiGraphicsExtractor extractor, Component text, int centerX, int y, int maxWidth, int color) {
      Component display = CodexTextLayout.trimWithEllipsis(this.font, text, Math.max(1, maxWidth));
      int x = centerX - Math.min(this.font.width(display), maxWidth) / 2;
      extractor.text(this.font, display.getVisualOrderText(), x, y, color);
   }

   private int drawCenteredWrappedLimited(GuiGraphicsExtractor extractor, Component text, int centerX, int y, int maxWidth, int maxLines, int color) {
      List<FormattedCharSequence> lines = CodexTextLayout.wrap(this.font, text, Math.max(1, maxWidth));
      int drawn = Math.min(Math.max(1, maxLines), lines.size());
      for (int i = 0; i < drawn; i++) {
         FormattedCharSequence line = lines.get(i);
         int x = centerX - Math.min(this.font.width(line), maxWidth) / 2;
         extractor.text(this.font, line, x, y, color);
         y += 10;
      }
      return y;
   }
}
