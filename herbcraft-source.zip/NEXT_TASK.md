# NEXT_TASK

## Recommended next task: client-test nutrition correction, then tune or draft P4 API

The current source is a `1.1.1` test/release candidate with the new nutrition correction pass implemented.

Current status:

- P1 Homeostatic temperature research is documented; no temperature gameplay integration exists yet.
- P2 low-risk external server-data merge layer is implemented and server-smoked.
- P3 startup-only loaded-mod/addon herb food extension is implemented, server-smoked, and author client-tested PASS.
- Nutrition correction/recent-meal redesign is implemented in source and built jars:
  - recent 24 meal tracking;
  - 3-minute correction scoring window;
  - correction score threshold 60;
  - data-backed correction relationship matrix in `data/herbcraft/nutrition_correction_rules.json`;
  - excessive dimensions extra-decay every 200 ticks by 15..45;
  - correction target 650;
  - high `fruit` / 津液 / Fluids non-punitive in the base mod;
  - high 津液 surplus helper normalizes other excesses toward 700 by 10 per 200 ticks;
  - client status `correcting` / `饮食回正中`;
  - debug presets and validator.
- P4 stable public Java extension events/API is **not** implemented.

## Why this is next

The correction pass changes live nutrition behavior and client panel status. It should be tested in a real client before tuning thresholds or drafting a public extension API, because nutrition profiles are one of the main external extension surfaces.

Implementation report:

```text
docs/reports/NUTRITION_CORRECTION_IMPLEMENTATION_REPORT_20260615.md
```

## Required next work

1. Run a real client with the current `1.1.1` jars.
2. Test debug presets:

```mcfunction
/herbcraft nutrition preset @p correcting_flesh
/herbcraft nutrition preset @p correcting_oil
/herbcraft nutrition preset @p correcting_grain
/herbcraft nutrition preset @p excess_fruit_nonpunitive
/herbcraft nutrition preset @p fruit_low
```

3. Check:
   - `饮食回正中` / correcting appears in the nutrition panel when correction is active;
   - high dimensions decay faster than the old `-2/minute` during correction;
   - high `fruit` / 津液 / Fluids does not apply negative dietary imbalance;
   - low `fruit` / 津液 still applies deficiency;
   - normal deficiency, well_nourished, water bowl relief, Cuisine clearing isolation, and custom nutrition effects still behave correctly.
4. If behavior feels too weak/strong, tune:

```text
correction_score_threshold
correction_extra_decay_min
correction_extra_decay_max
correction_target_value
correction_recent_window_ticks
nutrition_correction_rules.json matrix weights
fluid_surplus_decay_amount
fluid_surplus_target_value
```

5. Record client results in a new report under `docs/reports/`.
6. Only after this correction system is stable, draft P4 API design before coding:

```text
docs/PUBLIC_EXTENSION_API_DESIGN.md
```

## Do not do unless explicitly asked

- Do not claim P3 supports hot-reloadable world datapack FOOD/CONSUMABLE changes.
- Do not add a hard dependency on Homeostatic.
- Do not implement P4 Java API before nutrition correction client validation/tuning.
- Do not change stable IDs.
- Do not make main-mod nutrition more hardcore; reserve stricter mechanics for a future addon.

## Acceptance criteria

- Build passes.
- Validators in `CURRENT_BASELINE.md` pass.
- Client sanity pass has no visible blocker.
- Any new report is included in `herbcraft-source-current-20260614.zip`.
- `release_output/herbcraft_test_20260614_review/` contains current `1.1.1` jars and source zip.
- `CURRENT_BASELINE.md` is updated after any further modifying turn.
