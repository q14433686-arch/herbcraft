package com.herbcraft.knowledge;

import com.herbcraft.api.HerbDefinition;
import com.herbcraft.api.HerbEffectEntry;
import com.herbcraft.api.HerbcraftAPI;
import com.herbcraft.api.KnowledgeAPI;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.Item;

public final class HerbalChapter {
   public static final String CHAPTER_ID = "herbal";

   private HerbalChapter() {
   }

   public static void register() {
      KnowledgeAPI.registerChapter("herbal", Component.translatable("book.herbcraft.chapter.herbal"), 0);

      for (String section : List.of("flowers", "foliage", "sea", "nether", "ice", "curios")) {
         KnowledgeAPI.registerSection("herbal", section, Component.translatable("book.herbcraft.section.herbal." + section));
      }

      HerbcraftAPI.getHerbRegistry()
         .forEach(
            (item, definition) -> {
               String entryId = BuiltInRegistries.ITEM.getKey(item).getPath();
               KnowledgeAPI.registerEntry(
                  "herbal",
                  new KnowledgeAPI.Entry(
                     entryId,
                     classify(entryId),
                     Component.translatable(item.getDescriptionId()),
                     (player, state) -> lines(definition, state),
                     player -> hasEaten(player, item),
                     null
                  )
               );
            }
         );
   }

   public static boolean hasEaten(ServerPlayer player, Item item) {
      return player.getStats().getValue(Stats.ITEM_USED.get(item)) > 0;
   }

   private static String classify(String path) {
      if (path.contains("crimson") || path.contains("warped") || path.contains("nether") || path.contains("weeping") || path.contains("twisting")) {
         return "nether";
      } else if (path.contains("snow") || path.contains("ice")) {
         return "ice";
      } else if (path.contains("kelp") || path.contains("seagrass") || path.contains("sea_pickle") || path.contains("lily_pad")) {
         return "sea";
      } else if (!path.contains("leaves")
         && !path.contains("sapling")
         && !path.contains("propagule")
         && !path.contains("fern")
         && !path.contains("grass")
         && !path.contains("vine")
         && !path.contains("bamboo")
         && !path.contains("sugar_cane")
         && !path.contains("cocoa")
         && !path.contains("seeds")
         && !path.contains("moss")
         && !path.contains("mushroom")
         && !path.contains("fungus")) {
         return !path.contains("dandelion")
               && !path.contains("poppy")
               && !path.contains("orchid")
               && !path.contains("bluet")
               && !path.contains("daisy")
               && !path.contains("cornflower")
               && !path.contains("lily_of_the_valley")
               && !path.contains("wither_rose")
               && !path.contains("sunflower")
               && !path.contains("lilac")
               && !path.contains("rose_bush")
               && !path.contains("peony")
               && !path.contains("pitcher")
               && !path.contains("torchflower")
               && !path.contains("eyeblossom")
               && !path.contains("allium")
               && !path.contains("azalea")
               && !path.contains("tulip")
               && !path.contains("petals")
               && !path.contains("spore_blossom")
               && !path.contains("cactus_flower")
               && !path.contains("flower")
            ? "curios"
            : "flowers";
      } else {
         return "foliage";
      }
   }

   private static List<Component> lines(HerbDefinition definition, KnowledgeAPI.State state) {
      List<Component> lines = new ArrayList<>();
      if (state == KnowledgeAPI.State.HEARD) {
         lines.add(Component.translatable("book.herbcraft.entry.heard").withStyle(new ChatFormatting[]{ChatFormatting.GRAY, ChatFormatting.ITALIC}));
         return lines;
      } else {
         lines.add(
            Component.translatable("book.herbcraft.entry.nutrition", new Object[]{definition.nutrition(), String.format("%.1f", definition.saturation())})
               .withStyle(ChatFormatting.GRAY)
         );

         for (HerbEffectEntry effect : definition.effects()) {
            MutableComponent name = Component.translatable(((MobEffect)effect.effect().value()).getDescriptionId());
            if (effect.amplifier() > 0) {
               name = Component.translatable("potion.withAmplifier", new Object[]{name, Component.translatable("potion.potency." + effect.amplifier())});
            }

            int seconds = effect.durationTicks() / 20;
            MutableComponent line = Component.translatable("potion.withDuration", new Object[]{name, String.format("%d:%02d", seconds / 60, seconds % 60)});
            if (effect.chance() < 1.0F) {
               line = line.append(Component.literal(" " + Math.round(effect.chance() * 100.0F) + "%"));
            }

            lines.add(line.withStyle(effect.negative() ? ChatFormatting.RED : ChatFormatting.BLUE));
         }

         return lines;
      }
   }
}
