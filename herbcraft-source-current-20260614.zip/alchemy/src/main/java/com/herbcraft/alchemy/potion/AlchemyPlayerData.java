package com.herbcraft.alchemy.potion;

public interface AlchemyPlayerData {
   PlayerPotionBurdenState herbcraftAlchemy$potionBurdenState();
}
