# NEXT_TASK

## Recommended next task: real-client nutrition and UI validation pass

The old P0 source/jar desync tasks are no longer the immediate next task for this test baseline. Source now builds, server smoke reaches `Done`, hidden cuisine resources exist, and custom nutrition effects have been implemented. The next best task is a real client pass focused on validating player-facing behavior.

## Why this is the next task

Recent work touched several systems that are hard to fully validate from server smoke alone:

- custom nutrition MobEffect registration and icons;
- sustained malnutrition effects and immediate stale-effect cleanup;
- `/herbcraft nutrition` debug commands;
- water bowl temporary dietary-imbalance relief;
- cuisine/medicine clear-effect isolation;
- Codex/Jade/tooltip rendering still needs real visual checks;
- brewing stand hidden-cuisine catalysts still need real client interaction verification.

## Required work

1. Run a real client or equivalent interactive test with current jars/source.
2. Test nutrition commands:
   - `/herbcraft nutrition get @s`
   - `/herbcraft nutrition preset @s balanced`
   - `/herbcraft nutrition preset @s grain_low`
   - `/herbcraft nutrition preset @s flesh_low`
   - `/herbcraft nutrition preset @s oil_low`
   - `/herbcraft nutrition preset @s vege_low`
   - `/herbcraft nutrition preset @s fruit_low`
   - `/herbcraft nutrition preset @s starved`
   - `/herbcraft nutrition preset @s imbalanced_fruit`
3. Confirm old nutrition effects disappear immediately after changing nutrition values through commands or food consumption.
4. Confirm sustained severe effects remain visible until the next evaluation, but disappear immediately after corrective food/commands.
5. Inspect all seven nutrition icons in the effect HUD/inventory:
   - grain deficiency
   - flesh deficiency
   - oil deficiency
   - vege deficiency
   - fruit deficiency
   - dietary imbalance
   - well nourished
6. Test water bowl relief:
   - give dietary imbalance,
   - drink water bowls until the 15% success triggers,
   - confirm the effect is removed and not reapplied for about 60 seconds if values remain imbalanced.
7. Verify cuisine `clear_all_effects` does not remove Herbcraft nutrition effects.
8. Verify raw-herb and hodgepodge `clearPositiveEffects` do not remove future/positive nutrition effects; current `well_nourished` is the relevant check.
9. Do a real brewing stand test for:
   - Hundred-Flower Feast catalyst on clarified potion,
   - Deadly Hodgepodge catalyst on murky potion,
   - ingredient slot insertion,
   - component preservation.
10. Open the Codex and inspect `百草经总纲`, claim markers, scrolling, and long text layout.

## Acceptance criteria

- `JAVA_HOME=/tmp/herbcraft-jdk25/jdk-25 ./gradlew build --rerun-tasks` passes.
- `python3 scripts/check_lang_diff.py` passes.
- `python3 scripts/validate_custom_nutrition_effects_phase8.py` passes.
- `python3 scripts/validate_nutrition_cuisine_immunity_isolation.py` passes.
- `python3 scripts/validate_recipe_isolation.py` passes.
- `python3 scripts/validate_item_textures.py` passes.
- `python3 scripts/validate_extended_features.py` passes.
- `python3 scripts/verify_built_jars.py` passes.
- A client run reaches world entry without startup crash.
- Nutrition commands behave as expected and require gamemaster permission.
- Custom nutrition effects show correct names/icons.
- Severe malnutrition effects are sustained; warning effects remain light/probabilistic.
- Water bowl relief is temporary and does not repair nutrition values.
- Food/commands that repair nutrition remove obsolete nutrition effects immediately.
- Hidden cuisine catalyst brewing works in an actual brewing stand.

## Do not do in this next task unless explicitly asked

- Do not harden nutrition penalties for the main mod. Hard-core nutrition is a future addon concept.
- Do not rename nutrition effect IDs.
- Do not rewrite the full Codex UI unless a concrete client bug is observed.
- Do not migrate versions away from Minecraft `26.1.2`.
