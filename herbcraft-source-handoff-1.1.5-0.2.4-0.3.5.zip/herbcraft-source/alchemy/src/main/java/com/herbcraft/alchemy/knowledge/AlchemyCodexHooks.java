package com.herbcraft.alchemy.knowledge;

import com.herbcraft.knowledge.CodexLoot;
import java.util.Map;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents.Modify;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootTable;

public final class AlchemyCodexHooks {
   private static final Map<ResourceKey<LootTable>, Float> ALCHEMY_TABLES = Map.ofEntries(
      Map.entry(BuiltInLootTables.VILLAGE_TEMPLE, 0.18F),
      Map.entry(BuiltInLootTables.VILLAGE_FLETCHER, 0.12F),
      Map.entry(BuiltInLootTables.VILLAGE_CARTOGRAPHER, 0.1F),
      Map.entry(BuiltInLootTables.SHIPWRECK_MAP, 0.12F),
      Map.entry(BuiltInLootTables.SHIPWRECK_TREASURE, 0.12F),
      Map.entry(BuiltInLootTables.BURIED_TREASURE, 0.12F),
      Map.entry(BuiltInLootTables.JUNGLE_TEMPLE, 0.14F),
      Map.entry(BuiltInLootTables.NETHER_BRIDGE, 0.18F),
      Map.entry(BuiltInLootTables.BASTION_TREASURE, 0.12F),
      Map.entry(BuiltInLootTables.BASTION_OTHER, 0.12F),
      Map.entry(BuiltInLootTables.BASTION_BRIDGE, 0.12F),
      Map.entry(BuiltInLootTables.BASTION_HOGLIN_STABLE, 0.12F),
      Map.entry(BuiltInLootTables.TRIAL_CHAMBERS_REWARD, 0.25F),
      Map.entry(BuiltInLootTables.TRIAL_CHAMBERS_REWARD_RARE, 0.18F),
      Map.entry(BuiltInLootTables.TRIAL_CHAMBERS_REWARD_UNIQUE, 0.12F),
      Map.entry(BuiltInLootTables.WOODLAND_MANSION, 0.05F)
   );

   private AlchemyCodexHooks() {
   }

   public static void register() {
      LootTableEvents.MODIFY.register((Modify)(key, tableBuilder, source, registries) -> {
         Float chance = ALCHEMY_TABLES.get(key);
         if (chance != null && source.isBuiltin()) {
            CodexLoot.addTatteredPagePool(tableBuilder, chance, "alchemy", "");
         }
      });
   }
}
