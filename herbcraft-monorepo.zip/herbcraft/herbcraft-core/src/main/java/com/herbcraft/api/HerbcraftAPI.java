package com.herbcraft.api;

import com.herbcraft.Herbcraft;
import net.minecraft.world.item.Item;

import java.util.Map;
import java.util.Optional;

/**
 * Stable public read-only API for Herbcraft add-ons.
 * Add-ons must use this layer instead of depending on internal registry or mixin classes.
 */
public final class HerbcraftAPI {
	private HerbcraftAPI() {}

	public static Map<Item, HerbDefinition> getHerbRegistry() {
		return Herbcraft.getHerbDefinitions();
	}

	public static Optional<HerbDefinition> getDefinition(Item item) {
		return Optional.ofNullable(getHerbRegistry().get(item));
	}
}
