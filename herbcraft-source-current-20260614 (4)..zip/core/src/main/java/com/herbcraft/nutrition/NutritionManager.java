package com.herbcraft.nutrition;

import com.herbcraft.HerbcraftPlayerData;
import com.herbcraft.effect.HerbcraftMobEffects;
import com.herbcraft.logic.EffectImmunityManager;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;

public final class NutritionManager {
   private static final Identifier FLESH_ATTACK_ID = Identifier.fromNamespaceAndPath("herbcraft", "flesh_abundant_attack");
   private static final Identifier FRUIT_SPEED_ID = Identifier.fromNamespaceAndPath("herbcraft", "fruit_abundant_speed");

   // Short warning/excess durations. Serious danger/starved/confirmed imbalance states use
   // sustainedEffectTicks(rules), which covers the next nutrition check interval.
   private static final int WARNING_DEBUFF_TICKS = 100;   // 5s
   private static final int EXCESS_DEBUFF_TICKS = 80;     // 4s
   private static final int DIETARY_IMBALANCE_RELIEF_TICKS = 1200; // 60s
   private static final Map<UUID, Long> DIETARY_IMBALANCE_RELIEF_UNTIL = new HashMap<>();

   private NutritionManager() {}

   public static void onFoodConsumed(ServerPlayer player, ItemStack stack) {
      NutritionRegistry.get(stack).ifPresent(profile -> {
         if (!profile.isEmpty()) {
            PlayerNutritionState state = nutritionState(player);
            state.addFromProfile(profile);
            // Re-evaluate immediately after the meal. This prevents medicinal cuisine from
            // clearing vanilla MobEffect-based nutrition warnings for a full check interval
            // unless the meal actually fixed the underlying nutrition state.
            evaluateAndApply(player, state);
         }
      });
   }

   /** Called every server tick per player. */
   public static void tick(ServerPlayer player, long gameTime) {
      cleanupReliefMap(gameTime);
      PlayerNutritionState state = nutritionState(player);
      boolean decayed = state.tickDecay(gameTime);
      if (state.shouldCheck(gameTime)) {
         evaluateAndApply(player, state);
      }
      if (decayed) syncToClient(player);
   }

   /** Called on player login — reapply modifiers immediately. (Fix #1: cold start) */
   public static void onLogin(ServerPlayer player) {
      evaluateAndApply(player, nutritionState(player));
      syncToClient(player);
   }

   public static void onDeath(ServerPlayer player) {
      nutritionState(player).resetOnDeath();
      removeAllModifiers(player);
   }

   public static PlayerNutritionState nutritionState(ServerPlayer player) {
      return ((HerbcraftPlayerData) player).herbcraft$nutritionState();
   }

   public static void relieveDietaryImbalance(ServerPlayer player) {
      long now = player.level().getGameTime();
      DIETARY_IMBALANCE_RELIEF_UNTIL.put(player.getUUID(), now + DIETARY_IMBALANCE_RELIEF_TICKS);
      player.removeEffect(HerbcraftMobEffects.DIETARY_IMBALANCE);
   }

   private static boolean isDietaryImbalanceRelieved(ServerPlayer player) {
      long now = player.level().getGameTime();
      Long until = DIETARY_IMBALANCE_RELIEF_UNTIL.get(player.getUUID());
      if (until == null) {
         return false;
      }
      if (until <= now) {
         DIETARY_IMBALANCE_RELIEF_UNTIL.remove(player.getUUID());
         return false;
      }
      return true;
   }

   private static void cleanupReliefMap(long gameTime) {
      Iterator<Map.Entry<UUID, Long>> iterator = DIETARY_IMBALANCE_RELIEF_UNTIL.entrySet().iterator();
      while (iterator.hasNext()) {
         if (iterator.next().getValue() <= gameTime) {
            iterator.remove();
         }
      }
   }

   public static void setNutritionForDebug(ServerPlayer player, String dimension, int value) {
      PlayerNutritionState state = nutritionState(player);
      if ("all".equals(dimension)) {
         for (String dim : NutritionProfile.DIMENSIONS) {
            state.setDirect(dim, value);
         }
      } else {
         state.setDirect(dimension, value);
      }
      DIETARY_IMBALANCE_RELIEF_UNTIL.remove(player.getUUID());
      evaluateAndApply(player, state);
   }

   public static void applyNutritionPresetForDebug(ServerPlayer player, String preset) {
      PlayerNutritionState state = nutritionState(player);
      for (String dim : NutritionProfile.DIMENSIONS) {
         state.setDirect(dim, 500);
      }
      switch (preset) {
         case "starved" -> {
            for (String dim : NutritionProfile.DIMENSIONS) state.setDirect(dim, 0);
         }
         case "balanced" -> {
            for (String dim : NutritionProfile.DIMENSIONS) state.setDirect(dim, 500);
         }
         case "grain_low" -> state.setDirect("grain", 0);
         case "flesh_low" -> state.setDirect("flesh", 0);
         case "oil_low" -> state.setDirect("oil", 0);
         case "vege_low" -> state.setDirect("vege", 0);
         case "fruit_low" -> state.setDirect("fruit", 0);
         case "imbalanced_grain" -> setImbalancedPreset(state, "grain");
         case "imbalanced_flesh" -> setImbalancedPreset(state, "flesh");
         case "imbalanced_oil" -> setImbalancedPreset(state, "oil");
         case "imbalanced_vege" -> setImbalancedPreset(state, "vege");
         case "imbalanced_fruit" -> setImbalancedPreset(state, "fruit");
         case "excess_flesh" -> state.setDirect("flesh", 900);
         case "excess_oil" -> state.setDirect("oil", 900);
         case "excess_fruit" -> state.setDirect("fruit", 900);
         default -> {
         }
      }
      DIETARY_IMBALANCE_RELIEF_UNTIL.remove(player.getUUID());
      evaluateAndApply(player, state);
   }

   private static void setImbalancedPreset(PlayerNutritionState state, String highDimension) {
      for (String dim : NutritionProfile.DIMENSIONS) {
         state.setDirect(dim, dim.equals(highDimension) ? 950 : 350);
      }
   }

   private static void evaluateAndApply(ServerPlayer player, PlayerNutritionState state) {
      NutritionRules rules = NutritionRules.current();
      int sustainedTicks = sustainedEffectTicks(rules);
      clearNutritionEffects(player);

      // Compute cross-dimension stats first
      int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
      boolean allCritical = true;
      for (String dim : NutritionProfile.DIMENSIONS) {
         int v = state.get(dim);
         if (v < min) min = v;
         if (v > max) max = v;
         if (v >= rules.malnutritionLow) allCritical = false;
      }

      // If STARVED, apply sustained global nutrition penalties and skip per-dimension danger.
      if (allCritical) {
         addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.GRAIN_DEFICIENCY, sustainedTicks, 0));
         addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.FLESH_DEFICIENCY, sustainedTicks, 0));
         addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.OIL_DEFICIENCY, sustainedTicks, 0));
         addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.VEGE_DEFICIENCY, sustainedTicks, 0));
         addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.FRUIT_DEFICIENCY, sustainedTicks, 0));
         if (state.canWarn(player.level().getGameTime())) {
            player.sendSystemMessage(Component.translatable("nutrition.herbcraft.state.starved").withStyle(ChatFormatting.RED));
         }
         // Remove all positive modifiers when starved
         removeAllModifiers(player);
         syncToClient(player);
         return; // Skip per-dimension evaluation — STARVED supersedes everything
      }

      // Per-dimension gradient evaluation (only when NOT starved)
      for (String dim : NutritionProfile.DIMENSIONS) {
         int value = state.get(dim);
         applyDimensionEffects(player, dim, value, rules);
      }

      // Persistent imbalance: grace checks remain lenient, but once confirmed the state
      // lasts until the next nutrition evaluation unless temporarily relieved by water.
      if (max - min > 500 && max > rules.imbalanceHigh) {
         state.incrementBadStreak();
         if (!isDietaryImbalanceRelieved(player) && state.shouldApplyDebuff()) {
            addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.DIETARY_IMBALANCE, sustainedTicks, 0));
         }
         if (state.canWarn(player.level().getGameTime())) {
            player.sendSystemMessage(Component.translatable("nutrition.herbcraft.state.imbalanced").withStyle(ChatFormatting.GOLD));
         }
      } else {
         state.clearBadStreak();
      }

      // BALANCED: all in [fullBalanceMin, fullBalanceMax]
      boolean balanced = true;
      for (String dim : NutritionProfile.DIMENSIONS) {
         int v = state.get(dim);
         if (v < rules.fullBalanceMin || v > rules.fullBalanceMax) { balanced = false; break; }
      }
      applyBalancedModifier(player, balanced);

      syncToClient(player);
   }

   private static void applyDimensionEffects(ServerPlayer player, String dim, int value, NutritionRules rules) {
      // === DANGER (0~149): sustained state, not a short random flicker ===
      if (value < rules.malnutritionLow) {
         int sustainedTicks = sustainedEffectTicks(rules);
         switch (dim) {
            case "grain" -> addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.GRAIN_DEFICIENCY, sustainedTicks, 0));
            case "flesh" -> addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.FLESH_DEFICIENCY, sustainedTicks, 0));
            case "oil"   -> addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.OIL_DEFICIENCY, sustainedTicks, 0));
            case "vege"  -> addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.VEGE_DEFICIENCY, sustainedTicks, 0));
            case "fruit" -> addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.FRUIT_DEFICIENCY, sustainedTicks, 0));
         }
         removeAbundantModifier(player, dim);
         return;
      }

      // === WARNING (150~349) ===
      if (value < 350) {
         float gradient = 1.0F - (float)(value - rules.malnutritionLow) / 200.0F;
         float chance = 0.05F + gradient * 0.13F;
         switch (dim) {
            case "grain" -> { if (roll(player, chance)) addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.GRAIN_DEFICIENCY, WARNING_DEBUFF_TICKS, 0)); }
            case "flesh" -> { if (roll(player, chance)) addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.FLESH_DEFICIENCY, WARNING_DEBUFF_TICKS, 0)); }
            case "oil"   -> {} // warning oil: message only
            case "vege"  -> { if (roll(player, chance * 0.7F)) addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.VEGE_DEFICIENCY, WARNING_DEBUFF_TICKS, 0)); }
            case "fruit" -> { if (roll(player, chance * 0.7F)) addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.FRUIT_DEFICIENCY, WARNING_DEBUFF_TICKS, 0)); }
         }
         removeAbundantModifier(player, dim);
         return;
      }

      // === NORMAL (350~649) ===
      if (value < 650) {
         removeAbundantModifier(player, dim);
         return;
      }

      // === ABUNDANT (650~849) ===
      if (value < 850) {
         applyAbundantModifier(player, dim);
         return;
      }

      // === EXCESS (850~1000) ===
      applyAbundantModifier(player, dim);
      switch (dim) {
         case "flesh" -> { if (roll(player, 0.10F)) addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.DIETARY_IMBALANCE, EXCESS_DEBUFF_TICKS, 0)); }
         case "oil"   -> { if (roll(player, 0.08F)) addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.DIETARY_IMBALANCE, EXCESS_DEBUFF_TICKS, 0)); }
         case "fruit" -> { if (roll(player, 0.10F)) addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.DIETARY_IMBALANCE, EXCESS_DEBUFF_TICKS, 0)); }
         default -> {}
      }
   }

   private static void applyAbundantModifier(ServerPlayer player, String dim) {
      switch (dim) {
         case "flesh" -> {
            AttributeInstance attack = player.getAttribute(Attributes.ATTACK_DAMAGE);
            if (attack != null && !attack.hasModifier(FLESH_ATTACK_ID))
               attack.addTransientModifier(new AttributeModifier(FLESH_ATTACK_ID, 1.0, AttributeModifier.Operation.ADD_VALUE));
         }
         case "fruit" -> {
            AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null && !speed.hasModifier(FRUIT_SPEED_ID))
               speed.addTransientModifier(new AttributeModifier(FRUIT_SPEED_ID, 0.05, AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
         }
         default -> {}
      }
   }

   private static void removeAbundantModifier(ServerPlayer player, String dim) {
      switch (dim) {
         case "flesh" -> { AttributeInstance a = player.getAttribute(Attributes.ATTACK_DAMAGE); if (a != null) a.removeModifier(FLESH_ATTACK_ID); }
         case "fruit" -> { AttributeInstance s = player.getAttribute(Attributes.MOVEMENT_SPEED); if (s != null) s.removeModifier(FRUIT_SPEED_ID); }
         default -> {}
      }
   }

   private static void applyBalancedModifier(ServerPlayer player, boolean balanced) {
      if (balanced) {
         // 五养调和: a light custom nutrition boon for maintaining all five dimensions.
         // It gives modest armor and at least 12% knockback resistance via attribute modifiers.
         addNutritionEffect(player, new MobEffectInstance(HerbcraftMobEffects.WELL_NOURISHED, 1800, 0, true, true, true));
      }
      // When not balanced, the nutrition boon naturally expires (duration 90s, re-checked every 60s).
   }

   private static void removeAllModifiers(ServerPlayer player) {
      AttributeInstance attack = player.getAttribute(Attributes.ATTACK_DAMAGE);
      if (attack != null) attack.removeModifier(FLESH_ATTACK_ID);
      AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
      if (speed != null) speed.removeModifier(FRUIT_SPEED_ID);
   }

   private static int sustainedEffectTicks(NutritionRules rules) {
      return Math.max(400, rules.checkIntervalTicks + 200);
   }

   private static void clearNutritionEffects(ServerPlayer player) {
      List<Holder<MobEffect>> active = player.getActiveEffects()
         .stream()
         .map(MobEffectInstance::getEffect)
         .filter(HerbcraftMobEffects::isNutritionEffect)
         .toList();
      active.forEach(player::removeEffect);
   }

   private static void addNutritionEffect(ServerPlayer player, MobEffectInstance effect) {
      EffectImmunityManager.runBypassingImmunity(() -> player.addEffect(effect));
   }

   private static boolean roll(ServerPlayer player, float chance) {
      return player.getRandom().nextFloat() < chance;
   }

   public static void syncToClient(ServerPlayer player) {
      net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player, NutritionSyncPayload.build(player));
   }
}
