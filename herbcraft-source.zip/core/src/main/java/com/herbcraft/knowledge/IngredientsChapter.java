package com.herbcraft.knowledge;

import com.herbcraft.Herbcraft;
import com.herbcraft.api.KnowledgeAPI;
import com.herbcraft.api.KnowledgeDisplayState;
import com.herbcraft.nutrition.NutritionProfile;
import com.herbcraft.nutrition.NutritionRegistry;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.item.Item;

/**
 * "食材录" chapter — a data-driven knowledge chapter for vanilla/non-herb foods.
 * Entries are loaded from {@code data/herbcraft/ingredients.json}.
 * Gated by eating: you must eat the food to see its nutrition info.
 * No pharmacology, no herb stack, no effects — only nutrition dimensions.
 */
public final class IngredientsChapter {
   public static final String CHAPTER_ID = "ingredients";
   private static final String DATA_PATH = "data/herbcraft/ingredients.json";

   private static final Set<String> ENTRY_PATHS = new LinkedHashSet<>();
   private static final Map<String, String> ENTRY_SECTIONS = new LinkedHashMap<>();

   private IngredientsChapter() {}

   /** Check whether a given item path has an entry in the ingredients chapter. */
   public static boolean hasEntry(String itemPath) {
      return ENTRY_PATHS.contains(itemPath);
   }

   public static void register() {
      KnowledgeAPI.registerChapter(CHAPTER_ID,
         Component.translatable("book.herbcraft.chapter.ingredients"), 50);

      List<JsonEntry> entries = loadFromJson();
      if (entries.isEmpty()) {
         Herbcraft.LOGGER.warn("No ingredient entries loaded from {}; chapter will be empty", DATA_PATH);
         return;
      }

      // Collect and register sections in order
      Set<String> registeredSections = new LinkedHashSet<>();
      for (JsonEntry entry : entries) {
         if (entry.section != null && registeredSections.add(entry.section)) {
            KnowledgeAPI.registerSection(CHAPTER_ID, entry.section,
               Component.translatable("book.herbcraft.section.ingredients." + entry.section));
         }
      }

      // Register entries
      for (JsonEntry entry : entries) {
         Identifier id = Identifier.tryParse(entry.itemId);
         if (id == null) {
            Herbcraft.LOGGER.warn("Invalid item id '{}' in {}; skipping", entry.itemId, DATA_PATH);
            continue;
         }
         Item item = BuiltInRegistries.ITEM.getValue(id);
         if (item == null) {
            Herbcraft.LOGGER.warn("Item '{}' not found in registry; skipping", entry.itemId);
            continue;
         }
         String entryId = id.getPath();
         ENTRY_PATHS.add(entryId);
         ENTRY_SECTIONS.put(entryId, entry.section);

         final Item finalItem = item;
         KnowledgeAPI.registerEntry(
            CHAPTER_ID,
            new KnowledgeAPI.Entry(
               entryId,
               entry.section,
               Component.translatable(finalItem.getDescriptionId()),
               (player, state) -> lines(player, finalItem, entryId),
               player -> hasEaten(player, finalItem),
               player -> false
            )
         );
      }

      Herbcraft.LOGGER.info("Loaded {} ingredient entries from {} into {} sections",
         ENTRY_PATHS.size(), DATA_PATH, registeredSections.size());
   }

   private static List<JsonEntry> loadFromJson() {
      List<JsonEntry> entries = new ArrayList<>();
      try (InputStream in = IngredientsChapter.class.getClassLoader().getResourceAsStream(DATA_PATH)) {
         if (in == null) {
            Herbcraft.LOGGER.warn("Missing {}; ingredients chapter will be empty", DATA_PATH);
            return entries;
         }
         JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
         JsonArray arr = root.getAsJsonArray("entries");
         if (arr == null) return entries;
         for (JsonElement element : arr) {
            JsonObject obj = element.getAsJsonObject();
            String itemId = obj.has("item") ? obj.get("item").getAsString() : null;
            String section = obj.has("section") ? obj.get("section").getAsString() : null;
            if (itemId != null) {
               entries.add(new JsonEntry(itemId, section));
            }
         }
      } catch (Exception e) {
         Herbcraft.LOGGER.warn("Failed to load {}; using empty ingredients chapter", DATA_PATH, e);
      }
      return entries;
   }

   private static boolean hasEaten(ServerPlayer player, Item item) {
      return player.getStats().getValue(Stats.ITEM_USED.get(item)) > 0;
   }

   private static List<Component> lines(ServerPlayer player, Item item, String entryId) {
      List<Component> lines = new ArrayList<>();

      KnowledgeAPI.Entry entry = KnowledgeAPI.chapter(CHAPTER_ID)
         .map(ch -> ch.entry(entryId)).orElse(null);
      KnowledgeDisplayState display = entry == null
         ? KnowledgeDisplayState.UNKNOWN
         : KnowledgeAPI.displayState(player, CHAPTER_ID, entry);

      if (display == KnowledgeDisplayState.UNKNOWN || display == KnowledgeDisplayState.ENCOUNTERED) {
         lines.add(Component.translatable("book.herbcraft.ingredients.unknown")
            .withStyle(ChatFormatting.GRAY));
         return lines;
      }

      // Eaten → show fuzzy nutrition
      var profileOpt = NutritionRegistry.get(new net.minecraft.world.item.ItemStack(item));
      if (profileOpt.isEmpty() || profileOpt.get().isEmpty()) {
         lines.add(Component.translatable("book.herbcraft.ingredients.no_nutrition")
            .withStyle(ChatFormatting.GRAY));
         return lines;
      }

      NutritionProfile profile = profileOpt.get();

      lines.add(Component.translatable("book.herbcraft.ingredients.nutrition_header")
         .withStyle(ChatFormatting.DARK_AQUA));

      for (String dim : NutritionProfile.DIMENSIONS) {
         int val = profile.get(dim);
         if (val > 0) {
            String level = fuzzyLevel(val);
            lines.add(Component.literal("  ")
               .append(Component.translatable("nutrition.herbcraft.level." + level)
                  .withStyle(ChatFormatting.AQUA))
               .append(Component.translatable("nutrition.herbcraft.dimension." + dim)
                  .withStyle(ChatFormatting.GRAY)));
         }
      }

      lines.add(Component.empty());
      lines.add(Component.translatable("book.herbcraft.ingredients.note")
         .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));

      return lines;
   }

   private static String fuzzyLevel(int value) {
      if (value <= 15) return "trace";
      if (value <= 40) return "rich";
      return "heavy";
   }

   private record JsonEntry(String itemId, String section) {}
}
