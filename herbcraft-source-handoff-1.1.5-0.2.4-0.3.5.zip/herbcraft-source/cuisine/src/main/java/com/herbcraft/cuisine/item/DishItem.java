package com.herbcraft.cuisine.item;

import com.herbcraft.logic.LastMealTracker;
import com.herbcraft.logic.SpecialCounters;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;

public class DishItem extends Item {
   private final List<Item> counterItems;
   private final boolean clearFire;

   public DishItem(Properties properties, List<Item> counterItems, boolean clearFire) {
      super(properties);
      this.counterItems = counterItems;
      this.clearFire = clearFire;
   }

   public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
      if (!level.isClientSide()) {
         if (this.clearFire) {
            entity.setRemainingFireTicks(0);
         }

         if (entity instanceof Player player) {
            long gameTime = level.getGameTime();
            this.counterItems.forEach(item -> SpecialCounters.apply(player, item, gameTime));
         }

         if (entity instanceof ServerPlayer serverPlayer) {
            LastMealTracker.record(serverPlayer, this);
         }
      }

      return super.finishUsingItem(stack, level, entity);
   }
}
