package com.herbcraft.api;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.crafting.Recipe;

public final class KnowledgeManager {
   private KnowledgeManager() {
   }

   public static void awardRecipes(ServerPlayer player, List<ResourceKey<Recipe<?>>> keys) {
      if (!keys.isEmpty()) {
         player.awardRecipesByKey(keys);
      }
   }

   public static boolean unlock(ServerPlayer player, String chapterId, String entryId, KnowledgeAPI.State target) {
      if (target == KnowledgeAPI.State.UNKNOWN) {
         return false;
      } else {
         KnowledgeAPI.Chapter chapter = KnowledgeAPI.chapter(chapterId).orElse(null);
         if (chapter == null) {
            return false;
         } else {
            KnowledgeAPI.Entry entry = chapter.entry(entryId);
            if (entry == null) {
               return false;
            } else {
               KnowledgeAPI.State current = KnowledgeAPI.state(player, chapterId, entry);
               if (current.ordinal() >= target.ordinal()) {
                  return false;
               } else {
                  KnowledgeAPI.knowledge(player).put(chapterId + "/" + entryId, target.ordinal());
                  String key = target == KnowledgeAPI.State.MASTERED ? "message.herbcraft.knowledge.mastered" : "message.herbcraft.knowledge.heard";
                  player.sendOverlayMessage(Component.translatable(key, new Object[]{entry.title().copy().withStyle(ChatFormatting.GREEN)}));
                  return true;
               }
            }
         }
      }
   }
}
