package com.herbcraft.alchemy.registry;

import net.fabricmc.fabric.api.registry.FabricPotionBrewingBuilder;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.Potions;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public final class AlchemyRegistries {
    public static final String NAMESPACE = "herbcraft";
    private static final List<EssenceDefinition> ESSENCES = new ArrayList<>();
    private static final List<ModifierMix> MODIFIER_MIXES = new ArrayList<>();

    public static final Item ESSENCE_DANDELION = essence("dandelion", "dandelion",
            new EffectSpec(MobEffects.REGENERATION, 0, 5, true));
    public static final Item ESSENCE_GOLDEN_DANDELION = essence("golden_dandelion", "golden_dandelion",
            new EffectSpec(MobEffects.ABSORPTION, 0, 240, true),
            new EffectSpec(MobEffects.REGENERATION, 1, 5, true));
    public static final Item ESSENCE_POPPY = essence("poppy", "poppy",
            new EffectSpec(MobEffects.RESISTANCE, 0, 95, true),
            new EffectSpec(MobEffects.NAUSEA, 0, 65, false),
            new EffectSpec(MobEffects.SLOWNESS, 0, 35, false));
    public static final Item ESSENCE_BLUE_ORCHID = essence("blue_orchid", "blue_orchid",
            new EffectSpec(MobEffects.SATURATION, 0, 5, true),
            new EffectSpec(MobEffects.SPEED, 0, 25, true));
    public static final Item ESSENCE_AZURE_BLUET = essence("azure_bluet", "azure_bluet",
            new EffectSpec(MobEffects.BLINDNESS, 0, 25, false));
    public static final Item ESSENCE_TULIP = essence("tulip", "tulip",
            new EffectSpec(MobEffects.WEAKNESS, 0, 25, false));
    public static final Item ESSENCE_OXEYE_DAISY = essence("oxeye_daisy", "oxeye_daisy",
            new EffectSpec(MobEffects.REGENERATION, 0, 20, true));
    public static final Item ESSENCE_CORNFLOWER = essence("cornflower", "cornflower",
            new EffectSpec(MobEffects.JUMP_BOOST, 0, 25, true));
    public static final Item ESSENCE_LILY_OF_THE_VALLEY = essence("lily_of_the_valley", "lily_of_the_valley",
            new EffectSpec(MobEffects.REGENERATION, 0, 25, true),
            new EffectSpec(MobEffects.POISON, 1, 80, false),
            new EffectSpec(MobEffects.WEAKNESS, 0, 15, false));
    public static final Item ESSENCE_WITHER_ROSE = essence("wither_rose", "wither_rose",
            new EffectSpec(MobEffects.WITHER, 1, 65, false),
            new EffectSpec(MobEffects.HUNGER, 1, 120, false));
    public static final Item ESSENCE_TORCHFLOWER = essence("torchflower", "torchflower",
            new EffectSpec(MobEffects.GLOWING, 0, 240, true),
            new EffectSpec(MobEffects.NIGHT_VISION, 0, 95, true));
    public static final Item ESSENCE_CLOSED_EYEBLOSSOM = essence("closed_eyeblossom", "closed_eyeblossom",
            new EffectSpec(MobEffects.DARKNESS, 0, 80, false),
            new EffectSpec(MobEffects.NAUSEA, 0, 25, false),
            new EffectSpec(MobEffects.RESISTANCE, 0, 15, true));
    public static final Item ESSENCE_OPEN_EYEBLOSSOM = essence("open_eyeblossom", "open_eyeblossom",
            new EffectSpec(MobEffects.GLOWING, 0, 160, true),
            new EffectSpec(MobEffects.WITHER, 0, 10, false));
    public static final Item ESSENCE_CACTUS_FLOWER = essence("cactus_flower", "cactus_flower",
            new EffectSpec(MobEffects.REGENERATION, 0, 10, true));
    public static final Item ESSENCE_PINK_PETALS = essence("pink_petals", "pink_petals",
            new EffectSpec(MobEffects.SPEED, 0, 10, true));
    public static final Item ESSENCE_SUNFLOWER = essence("sunflower", "sunflower",
            new EffectSpec(MobEffects.ABSORPTION, 0, 50, true));
    public static final Item ESSENCE_LILAC = essence("lilac", "lilac",
            new EffectSpec(MobEffects.SPEED, 0, 65, true));
    public static final Item ESSENCE_ROSE_BUSH = essence("rose_bush", "rose_bush",
            new EffectSpec(MobEffects.REGENERATION, 0, 10, true));
    public static final Item ESSENCE_PEONY = essence("peony", "peony",
            new EffectSpec(MobEffects.RESISTANCE, 0, 35, true));
    public static final Item ESSENCE_PITCHER_PLANT = essence("pitcher_plant", "pitcher_plant",
            new EffectSpec(MobEffects.HUNGER, 0, 15, false));
    public static final Item ESSENCE_FERN = essence("fern", "fern",
            new EffectSpec(MobEffects.POISON, 0, 5, false));
    public static final Item ESSENCE_SPORE_BLOSSOM = essence("spore_blossom", "spore_blossom",
            new EffectSpec(MobEffects.NAUSEA, 0, 65, false),
            new EffectSpec(MobEffects.SLOW_FALLING, 0, 50, true));
    public static final Item ESSENCE_COCOA_BEANS = essence("cocoa_beans", "cocoa_beans",
            new EffectSpec(MobEffects.SPEED, 0, 15, true),
            new EffectSpec(MobEffects.HASTE, 0, 15, true));
    public static final Item ESSENCE_OAK_LEAVES = essence("oak_leaves", "oak_leaves",
            new EffectSpec(MobEffects.RESISTANCE, 0, 10, true));
    public static final Item ESSENCE_SPRUCE_LEAVES = essence("spruce_leaves", "spruce_leaves",
            new EffectSpec(MobEffects.REGENERATION, 0, 10, true));
    public static final Item ESSENCE_BIRCH_LEAVES = essence("birch_leaves", "birch_leaves",
            new EffectSpec(MobEffects.SPEED, 0, 25, true));
    public static final Item ESSENCE_ACACIA_LEAVES = essence("acacia_leaves", "acacia_leaves",
            new EffectSpec(MobEffects.RESISTANCE, 0, 10, true));
    public static final Item ESSENCE_MANGROVE_LEAVES = essence("mangrove_leaves", "mangrove_leaves",
            new EffectSpec(MobEffects.WATER_BREATHING, 0, 25, true));
    public static final Item ESSENCE_CHERRY_LEAVES = essence("cherry_leaves", "cherry_leaves",
            new EffectSpec(MobEffects.REGENERATION, 0, 10, true),
            new EffectSpec(MobEffects.SPEED, 0, 10, true));
    public static final Item ESSENCE_PALE_OAK_LEAVES = essence("pale_oak_leaves", "pale_oak_leaves",
            new EffectSpec(MobEffects.DARKNESS, 0, 10, false),
            new EffectSpec(MobEffects.NIGHT_VISION, 0, 25, true));
    public static final Item ESSENCE_AZALEA_LEAVES = essence("azalea_leaves", "azalea_leaves",
            new EffectSpec(MobEffects.POISON, 0, 65, false),
            new EffectSpec(MobEffects.NAUSEA, 0, 10, false));
    public static final Item ESSENCE_FLOWERING_AZALEA_LEAVES = essence("flowering_azalea_leaves", "flowering_azalea_leaves",
            new EffectSpec(MobEffects.POISON, 1, 50, false),
            new EffectSpec(MobEffects.NAUSEA, 0, 25, false));
    public static final Item ESSENCE_CHERRY_SAPLING = essence("cherry_sapling", "cherry_sapling",
            new EffectSpec(MobEffects.REGENERATION, 0, 5, true));
    public static final Item ESSENCE_AZALEA = essence("azalea", "azalea",
            new EffectSpec(MobEffects.POISON, 0, 20, false));
    public static final Item ESSENCE_FLOWERING_AZALEA = essence("flowering_azalea", "flowering_azalea",
            new EffectSpec(MobEffects.POISON, 0, 40, false),
            new EffectSpec(MobEffects.NAUSEA, 0, 10, false));
    public static final Item ESSENCE_KELP = essence("kelp", "kelp",
            new EffectSpec(MobEffects.WATER_BREATHING, 0, 20, true));
    public static final Item ESSENCE_SEA_PICKLE = essence("sea_pickle", "sea_pickle",
            new EffectSpec(MobEffects.GLOWING, 0, 240, true),
            new EffectSpec(MobEffects.WATER_BREATHING, 0, 30, true));
    public static final Item ESSENCE_CRIMSON_FUNGUS = essence("crimson_fungus", "crimson_fungus",
            new EffectSpec(MobEffects.STRENGTH, 0, 80, true),
            new EffectSpec(MobEffects.NAUSEA, 0, 15, false));
    public static final Item ESSENCE_WARPED_FUNGUS = essence("warped_fungus", "warped_fungus",
            new EffectSpec(MobEffects.SPEED, 0, 80, true),
            new EffectSpec(MobEffects.FIRE_RESISTANCE, 0, 120, true),
            new EffectSpec(MobEffects.NAUSEA, 0, 20, false));
    public static final Item ESSENCE_BROWN_MUSHROOM = essence("brown_mushroom", "brown_mushroom",
            new EffectSpec(MobEffects.REGENERATION, 0, 5, true));

    private static Holder.Reference<Potion> FLOWERING_AZALEA_MURKY;
    private static Holder.Reference<Potion> LILY_OF_THE_VALLEY_MURKY;
    private static Holder.Reference<Potion> WITHER_ROSE_BASE;
    private static Holder.Reference<Potion> UNDEAD_VENOM;
    private static Holder.Reference<Potion> CARDIAC_TOXIN;
    private static Holder.Reference<Potion> WITHER_VENOM_III;

    public static final CreativeModeTab ALCHEMY_TAB = Registry.register(
            BuiltInRegistries.CREATIVE_MODE_TAB,
            Identifier.fromNamespaceAndPath(NAMESPACE, "alchemy"),
            CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0)
                    .title(Component.translatable("itemGroup.herbcraft.alchemy"))
                    .icon(() -> new ItemStack(ESSENCE_DANDELION))
                    .displayItems((parameters, output) -> ESSENCES.forEach(definition -> output.accept(definition.item)))
                    .build()
    );

    private AlchemyRegistries() {}

    public static void initialize() {
        FabricPotionBrewingBuilder.BUILD.register(builder -> {
            for (EssenceDefinition definition : ESSENCES) {
                builder.addMix(Potions.AWKWARD, definition.item, definition.basePotion);
            }
            for (ModifierMix mix : MODIFIER_MIXES) {
                builder.addMix(mix.from, mix.ingredient, mix.to);
            }
            builder.addMix(FLOWERING_AZALEA_MURKY, ESSENCE_WITHER_ROSE, UNDEAD_VENOM);
            builder.addMix(LILY_OF_THE_VALLEY_MURKY, ESSENCE_CLOSED_EYEBLOSSOM, CARDIAC_TOXIN);
        });
    }

    private static Item essence(String id, String potionName, EffectSpec... effects) {
        String itemPath = "essence_" + id;
        Item item = registerItem(itemPath, Item::new, new Item.Properties().stacksTo(64));
        Holder.Reference<Potion> basePotion = registerPotion(potionName, effects);
        EssenceDefinition definition = new EssenceDefinition(id, item, basePotion, List.of(effects));
        ESSENCES.add(definition);
        registerModifiers(definition);
        return item;
    }

    private static void registerModifiers(EssenceDefinition definition) {
        List<EffectSpec> positive = definition.effects.stream().filter(EffectSpec::positive).toList();
        List<EffectSpec> negative = definition.effects.stream().filter(e -> !e.positive()).toList();
        if (!positive.isEmpty()) {
            Holder.Reference<Potion> clarified = registerPotion(definition.id + "_clarified", halfDuration(positive, false));
            MODIFIER_MIXES.add(new ModifierMix(definition.basePotion, Items.HONEYCOMB, clarified));
        }
        if (!negative.isEmpty()) {
            Holder.Reference<Potion> murky = registerPotion(definition.id + "_murky", multiplyDuration(negative, 1.5F));
            MODIFIER_MIXES.add(new ModifierMix(definition.basePotion, Items.FERMENTED_SPIDER_EYE, murky));
            if (definition.id.equals("flowering_azalea")) FLOWERING_AZALEA_MURKY = murky;
            if (definition.id.equals("lily_of_the_valley")) LILY_OF_THE_VALLEY_MURKY = murky;
        }
        Holder.Reference<Potion> extended = registerPotion(definition.id + "_long", multiplyDuration(definition.effects, 2.0F));
        MODIFIER_MIXES.add(new ModifierMix(definition.basePotion, Items.REDSTONE, extended));
        if (definition.id.equals("wither_rose")) {
            WITHER_ROSE_BASE = definition.basePotion;
            WITHER_VENOM_III = registerPotion("wither_venom_iii",
                    new EffectSpec(MobEffects.WITHER, 2, 30, false),
                    new EffectSpec(MobEffects.HUNGER, 2, 60, false));
            MODIFIER_MIXES.add(new ModifierMix(definition.basePotion, Items.GLOWSTONE_DUST, WITHER_VENOM_III));
        } else {
            Holder.Reference<Potion> strong = registerPotion(definition.id + "_strong", strengthen(definition.effects));
            MODIFIER_MIXES.add(new ModifierMix(definition.basePotion, Items.GLOWSTONE_DUST, strong));
        }
    }

    static {
        UNDEAD_VENOM = registerPotion("undead_venom",
                new EffectSpec(MobEffects.WITHER, 1, 50, false),
                new EffectSpec(MobEffects.POISON, 1, 50, false),
                new EffectSpec(MobEffects.HUNGER, 1, 60, false));
        CARDIAC_TOXIN = registerPotion("cardiac_toxin",
                new EffectSpec(MobEffects.POISON, 1, 120, false),
                new EffectSpec(MobEffects.WEAKNESS, 0, 22, false),
                new EffectSpec(MobEffects.DARKNESS, 0, 40, false));
    }

    private static EffectSpec[] halfDuration(List<EffectSpec> effects, boolean strengthenPositive) {
        return effects.stream().map(e -> new EffectSpec(e.effect, strengthenPositive && e.positive ? Math.min(e.amplifier + 1, 1) : e.amplifier, roundToFive(Math.round(e.durationSeconds * 0.5F)), e.positive)).toArray(EffectSpec[]::new);
    }

    private static EffectSpec[] multiplyDuration(List<EffectSpec> effects, float multiplier) {
        return effects.stream().map(e -> new EffectSpec(e.effect, e.amplifier, roundToFive(Math.round(e.durationSeconds * multiplier)), e.positive)).toArray(EffectSpec[]::new);
    }

    private static EffectSpec[] strengthen(List<EffectSpec> effects) {
        return effects.stream().map(e -> new EffectSpec(e.effect, e.positive ? Math.min(e.amplifier + 1, 1) : e.amplifier, roundToFive(Math.round(e.durationSeconds * 0.5F)), e.positive)).toArray(EffectSpec[]::new);
    }

    private static int roundToFive(int seconds) {
        return Math.max(5, Math.min(480, Math.round(seconds / 5.0F) * 5));
    }

    private static <T extends Item> T registerItem(String name, Function<Item.Properties, T> factory, Item.Properties properties) {
        Identifier id = Identifier.fromNamespaceAndPath(NAMESPACE, name);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        T item = factory.apply(properties.setId(key));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        return item;
    }

    private static Holder.Reference<Potion> registerPotion(String name, EffectSpec... effects) {
        Identifier id = Identifier.fromNamespaceAndPath(NAMESPACE, name);
        ResourceKey<Potion> key = ResourceKey.create(Registries.POTION, id);
        MobEffectInstance[] instances = new MobEffectInstance[effects.length];
        for (int i = 0; i < effects.length; i++) {
            EffectSpec effect = effects[i];
            instances[i] = new MobEffectInstance(effect.effect, effect.durationSeconds * 20, effect.amplifier);
        }
        return Registry.registerForHolder(BuiltInRegistries.POTION, key, new Potion(name, instances));
    }

    private record EssenceDefinition(String id, Item item, Holder.Reference<Potion> basePotion, List<EffectSpec> effects) {}
    private record ModifierMix(Holder<Potion> from, Item ingredient, Holder<Potion> to) {}
    private record EffectSpec(Holder<MobEffect> effect, int amplifier, int durationSeconds, boolean positive) {}
}
