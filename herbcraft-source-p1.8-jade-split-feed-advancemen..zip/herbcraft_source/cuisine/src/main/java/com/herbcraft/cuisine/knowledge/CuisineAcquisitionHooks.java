package com.herbcraft.cuisine.knowledge;

import com.herbcraft.api.KnowledgeManager;
import com.herbcraft.api.KnowledgeAPI.State;
import com.herbcraft.cuisine.registry.DishRegistry;
import com.herbcraft.knowledge.KnowledgeInventoryScanner;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class CuisineAcquisitionHooks {
   private static final Map<Item, String> DISH_BY_ITEM = new HashMap<>();
   private static final Map<Item, String> DISH_BY_RAW_ITEM = new HashMap<>();

   private CuisineAcquisitionHooks() {
   }

   public static void register() {
      for (DishRegistry.Dish dish : DishRegistry.dishes()) {
         DISH_BY_ITEM.put(dish.item(), dish.id());
         if (dish.rawItem() != null) {
            DISH_BY_RAW_ITEM.put(dish.rawItem(), dish.id());
         }
      }

      KnowledgeInventoryScanner.registerHandler(CuisineAcquisitionHooks::onStack);
   }

   private static void onStack(ServerPlayer player, ItemStack stack) {
      String dishId = DISH_BY_ITEM.get(stack.getItem());
      if (dishId != null) {
         KnowledgeManager.unlock(player, "cuisine", dishId, State.HEARD);
      } else {
         String rawDishId = DISH_BY_RAW_ITEM.get(stack.getItem());
         if (rawDishId != null) {
            KnowledgeManager.unlock(player, "cuisine", rawDishId, State.HEARD);
         }
      }
   }
}
