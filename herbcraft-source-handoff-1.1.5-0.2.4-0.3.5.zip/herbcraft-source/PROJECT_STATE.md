# PROJECT_STATE

Current handoff date: 2026-06-12

## Current versions

| Module | Mod id | Version | Notes |
|---|---|---:|---|
| core | `herbcraft` | `1.1.5` | Latest core changes: Codex UI translucent panels, herb tag for hodgepodge, last meal, consume sounds. |
| alchemy | `herbcraft_alchemy` | `0.2.4` | Latest alchemy change: randomized high-tier potion villager trade matching fix. |
| cuisine | `herbcraft_cuisine` | `0.3.5` | Latest cuisine changes: hodgepodge survival recipe and tag/API input validation. |

## Completed features

### Rebuilt source project

- Reconstructed a three-module source project from the original jars.
- Uses Fabric 26.1 build style: official names, Java 25, Gradle 9.4.1, `net.fabricmc.fabric-loom`.

### Core herb system

- Loads edible herb definitions from `data/herbcraft/herbs.json`.
- Applies food and consumable components to many vanilla plant/natural items.
- Provides `HerbcraftAPI` and `HerbConsumeEvents`.
- Supports special raw-herb effects including clears, healing, damage events, extinguish, projectile short-use items, bucket remainder and herb stack overload.
- Centralized consume sound selection in `ConsumeSoundResolver`.

### Herb Codex / 百草经

- Knowledge API with chapters, sections, entries and player state.
- Network sync payload for codex snapshots.
- Custom `CodexScreen` with:
  - non-pausing screen;
  - dynamic chapter numbering and sort order;
  - dynamic layout;
  - left panel ellipsis trimming + hover tooltip;
  - right panel word wrapping and scroll clipping;
  - semi-transparent fullscreen background and semi-transparent panels.
- Tattered pages unlock knowledge on use, not on pickup.
- Creative tab variants are generated for each loaded knowledge entry; no bare empty tattered pages are added.

### Loot and tattered pages

- `herbcraft:tattered_page` exists in core with `herbcraft:page_entry` component.
- Core, alchemy and cuisine inject their own tattered pages with Fabric `LootTableEvents.MODIFY` and `source.isBuiltin()` guards.
- Module boundaries are respected: addon pages only exist if that addon is installed.

### Cuisine

- Loads curated dishes from `data/herbcraft_cuisine/dishes.json`.
- Registers raw medicinal dish items, cooked dishes, water bowl and hodgepodge.
- Standard recipes/cooking recipes exist for curated dishes.
- `herbcraft_cuisine:hodgepodge` custom recipe is now enabled by `data/herbcraft_cuisine/recipe/hodgepodge.json`.
- Hodgepodge recipe accepts exactly one bowl + 3 or 4 herbs, checks `#herbcraft:herb` and `HerbcraftAPI`, and writes `herbcraft_cuisine:hodgepodge_contents` ingredient snapshot.
- Hodgepodge eating uses the snapshot and full `HerbEntry` logic: dynamic effects, +15% chance bonus, clear effects, extinguish, damage/heal events, herb stack + up to 3, clash nausea and special counters.

### Alchemy

- Registers essences, brewing recipes and potion variants.
- Ordinary herbal potions are stabilized with minimum positive/negative duration rules.
- Clarified potions keep positive effects and strengthen them.
- Murky potions keep negative effects and weaponize them.
- High-tier potions get `herbcraft_alchemy:potion_quality`, `herbcraft_alchemy:potion_bonus` and `herbcraft_alchemy:advanced_potion_initialized` components.
- Inventory scan initializes old/new high-tier potion stacks idempotently.
- Tooltips show high-tier type, quality and bonus effect.
- `ItemCostAdvancedPotionMixin` fixes villager buy trades for randomized high-tier potion stacks by comparing potion identity instead of exact full `potion_contents`.

### Weapon coating

- `herbcraft:weapon_coating` data component.
- Coating recipes and smithing logic.
- Coated weapon tooltip and hit behavior.
- Some weaponsmith trades sell real coated weapons with the coating component.

### Villager trades

- Uses 26.1 data-driven `villager_trade` JSON and `data/minecraft/tags/villager_trade/...` tags.
- Existing and added trades cover cleric, farmer, fletcher, wandering trader, weaponsmith, toolsmith, armorer and librarian.
- Tag validation script confirms current custom trades are referenced and tags use `replace=false`.

### Translation quality

- `zh_cn` and `en_us` key sets currently match across core, alchemy and cuisine.
- `scripts/check_lang_diff.py` checks translation key parity.

### Flavor features

- Last meal: after player death, if a Herbcraft food was eaten within 60 ticks, a grey “Last meal” message is broadcast without replacing vanilla death messages.
- Differentiated herb/cuisine consume sounds.

## In progress / fragile areas

- REI integration is intentionally not implemented because REI currently has no 26.1.2-compatible release.
- UI should still be tested in a real client at GUI Scale 2/3/Auto and small windows.
- Hodgepodge survival crafting should be tested in-game with 3 and 4 valid herbs.

## Known bugs / caveats

- Some server smoke tests in the sandbox timed out because Minecraft 26.1 startup is slow here, not because of observed data-pack failures. Build and static validation pass.
- Alchemy depends on `herbcraft >=1.1.2`; the current all-mod recommended set uses core `1.1.5`. This dependency is looser but compatible.
- P1 villager professions (fisherman, shepherd, leatherworker, mason) are not implemented.
