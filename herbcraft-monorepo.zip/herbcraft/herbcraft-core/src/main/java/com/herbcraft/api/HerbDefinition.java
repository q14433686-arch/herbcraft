package com.herbcraft.api;

import net.minecraft.world.item.Item;

import java.util.List;

/** A read-only public description of one herb/organic item known by Herbcraft core. */
public record HerbDefinition(
		Item item,
		int nutrition,
		float saturation,
		float consumeSeconds,
		boolean medicinal,
		boolean stackGroup,
		List<HerbEffectEntry> effects
) {}
