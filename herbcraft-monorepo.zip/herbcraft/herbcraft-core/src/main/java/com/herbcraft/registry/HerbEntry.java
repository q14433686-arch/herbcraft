package com.herbcraft.registry;

import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.component.Consumables;

import java.util.ArrayList;
import java.util.List;

public final class HerbEntry {
	public final Item item;
	public final int nutrition;
	public final float saturation;
	public final float consumeSeconds;
	public final boolean medicinal;
	public final boolean stackGroup;
	public final List<Holder<MobEffect>> removeEffects = new ArrayList<>();
	public final List<Effect> effects = new ArrayList<>();
	public final List<DamageEvent> damageEvents = new ArrayList<>();
	public final List<HealEvent> healEvents = new ArrayList<>();
	public String counter;
	public boolean clearPositiveEffects;
	public boolean extinguish;
	public boolean bucketRemainder;
	public boolean drink;
	public boolean shortUseProjectile;

	public HerbEntry(Item item, int nutrition, float saturation, float consumeSeconds, boolean medicinal, boolean stackGroup) {
		this.item = item;
		this.nutrition = nutrition;
		this.saturation = saturation;
		this.consumeSeconds = consumeSeconds;
		this.medicinal = medicinal;
		this.stackGroup = stackGroup;
	}

	public FoodProperties foodProperties() {
		FoodProperties.Builder builder = new FoodProperties.Builder()
				.nutrition(nutrition)
				.saturationModifier(saturation);
		if (medicinal) builder.alwaysEdible();
		return builder.build();
	}

	public Consumable consumable() {
		Consumable.Builder builder = drink ? Consumables.defaultDrink() : Consumables.defaultFood();
		return builder.consumeSeconds(consumeSeconds).build();
	}

	public record Effect(Holder<MobEffect> effect, float chance, int amplifier, int durationTicks, boolean positive) {}
	public record DamageEvent(float chance, float amount) {}
	public record HealEvent(float chance, float amount) {}
}
