# NEXT_TASK

## Immediate next task: real-client JEI/REI verification for weapon coatings

This turn completed a stronger source-level fix for weapon coatings (武器淬层) being craftable in the smithing table but not searchable in JEI/REI-style viewers. Passive vanilla display metadata was not sufficient in the user's live client, so Alchemy now includes explicit optional JEI and REI plugins: JEI gets a smithing category extension plus explicit `RecipeTypes.SMITHING` recipe holders through the required `jei_mod_plugin` entrypoint, and REI gets explicit `DefaultSmithingDisplay` entries through `rei_client`, now expanded from `#herbcraft:coatable_weapons` rather than an iron-sword-only sample.

Next verification should be done in a real client with Core + Alchemy + JEI or REI:

1. search `淬层`, `coating`, `Blank Adhesive`, `Amethyst Adhesive`, `Echo Adhesive`, and several essence names;
2. confirm apply recipes show as smithing-table recipes: blank adhesive + coatable weapon + essence;
3. confirm refine recipes show amethyst/echo adhesive flows for essences with matching positive/negative effects;
4. confirm runtime smithing and hit effects are unchanged.

If client verification passes, resume the prior structural recommendation: split `HerbalChapter` into registration/projection/guide/text-provider layers.

## Recommended next task: structural decomposition phase 3 — split `HerbalChapter`

Structural decomposition Phase 2 is now complete: the nutrition subsystem has been separated into runtime, effect, discovery, and debug layers behind the stable `NutritionManager` facade.

The next highest-value structural reduction is now:

1. split `HerbalChapter` into registration/projection/guide/text-provider layers;
2. optionally introduce narrower Codex delta packets for claim-mark refreshes;
3. optionally standardize disconnect-clearing for all client caches.

Immediate runtime verification still recommended before or alongside Phase 3:

- nutrition gameplay remains unchanged;
- ingredient discovery / guide hints still fire correctly on food consume;
- Codex book still opens correctly;
- claim-mark updates refresh open Codex without reopening;
- death/respawn preserves knowledge but does not auto-open Codex.

Until Phase 3 and runtime verification are complete, treat the architecture as improved but not yet fully decomposed.

## Previous recommended next task: optional P4 runtime datapack test, then 1.1.3 release upload / Wiki split

The current source is packaged as the `1.1.3` release/test line with nutrition correction, 0.6x profile scaling, ingredients chapter, fluid surplus refinements, raw herb food-roll rebalance, and onboarding/Codex guidance polish.

Current status:

- Professional Role Alignment frozen per author instruction (`GAME_PLANNER_AND_DEVELOPER_COLLABORATION_SPEC_20260618.md`): Author is Lead Game Planner & System Architect (游戏策划); Agent is Lead Professional Developer executing 100% of codebase, AST verifications, and Gradle operations. Confirmed zero network lag / TPS impact of localized Item RAM traversal. Kicking off Yansheng (`严生`) Mode B design discussion and requesting Planner's acceptance criteria for immediate subproject provisioning.
- Systematic source audit of all recently implemented features in `1.1.3` completed as of 2026-06-18. Flawless algorithmic health confirmed, and architectural cleanups executed to decouple hardcoded item-path and counter ID assumptions. Zipped source updated with `docs/reports/SYSTEMATIC_SOURCE_AUDIT_AND_DECOUPLING_20260618.md`.
- Codex UI claim hitbox clearing bug is fully fixed (`contentHeight` no longer wipes interactive hitboxes, multi-line hitboxes are accurate, strict click bounds enforced). AST/Textual validator `scripts/validate_codex_hitboxes.py` added.
- Environment setup in the sandbox is fully verified (JDK 25 Temurin provisioned, automated validation suite 100% passed).
- Final source-level datapack integration verification is recorded in `docs/reports/DATAPACK_RUNTIME_COMPAT_VERIFICATION_20260617.md`. A runtime test datapack is available at `release_output/herbcraft_test_20260614_review/herbcraft-p4-runtime-test-datapack-20260617.zip`.
- Edge/regression source review is recorded in `docs/reports/EDGE_REGRESSION_REVIEW_20260617.md`; P1/P2 fixes are implemented in `docs/reports/EDGE_P1_P2_FIXES_20260617.md`. Remaining edge work is runtime-only/perf/cross-dimension/multiplayer testing plus optional custom-counter runtime verification.
- P1 Homeostatic temperature research is documented; no temperature gameplay integration exists yet.
- P2 low-risk external server-data merge layer is implemented and server-smoked.
- P3 startup-only loaded-mod/addon herb food extension is implemented, server-smoked, and author client-tested PASS.
- Nutrition correction/recent-meal redesign is implemented in source and built jars:
  - recent 24 meal tracking;
  - 3-minute correction scoring window;
  - correction score threshold 60;
  - data-backed correction relationship matrix in `data/herbcraft/nutrition_correction_rules.json`;
  - excessive dimensions extra-decay every 200 ticks by 15..45;
  - correction target 650;
  - high `fruit` / 津液 / Fluids non-punitive in the base mod;
  - high 津液 surplus helper: when fruit >= 850 and at least two non-fruit dimensions above 850 share a correction-matrix relationship, normalizes those related excesses toward 700 by 10 per 200 ticks;
  - client status `correcting` / `饮食回正中`;
  - debug presets and validator.
- 食材录 (Ingredient Codex) chapter implemented: 39 vanilla foods, data-driven from `ingredients.json`, eating-gated knowledge.
- All nutrition profiles scaled to 0.6x for balanced pacing.
- `correction_high_threshold` lowered to 750 with graduated decay (half-speed 750-849, full-speed 850+).
- Fluid surplus helper now requires correction-matrix relationship between excess dimensions.
- P4.1-P4.5 are complete for the read/event extension boundary: JSON spec, read-only Java API, observational event API, examples, validators/docs sweep, and `docs/reports/P4_EXTENSION_READINESS_1_1_3_20260617.md`. Java write/registration APIs remain deferred.
- Full system Wiki draft exists at `docs/HERBCRAFT_FULL_SYSTEM_WIKI_1_1_3.md`; optional next docs work is splitting it into player-facing and developer-facing Wiki pages.
- `1.1.3` new-player guidance Phase 1 is implemented: route-sign advancement descriptions, rewritten four-line 百草经总纲, and polished 食材录 wording.
- `1.1.3` new-player guidance Phase 2.1 is implemented: guide entries are data-backed by module-owned `codex_guides.json`; Cuisine/Alchemy guide pages are addon-owned; 五味/七情 principle discovery is persisted and can reveal guide lines with latest item examples. A small Codex microcopy pass now explains plainly that 性味 is pharmacology, not nutrition, and 七情 is recent-herb interaction, not a fixed recipe list.
- `1.1.3` one-time guide hints are implemented as data-backed module-owned `guide_hints.json` files plus `GuideHintManager` with persisted seen-hint IDs.
- Pharmacology qi/relation data tuning is implemented: `temperature_values` and ordered `seven_emotion_rules` are in `pharmacology_rules.json`; exact hot/cold same-qi now builds more slowly.
- P3.9 Cuisine/Alchemy module overview guides are implemented: `膳房录` and `炼金要术` now have their own overview sections and staged guide subentries.
- P3.10 raw herb hunger/saturation rebalance is implemented in source: `food_rolls` support exists, 70 raw herb entries were tuned, and `scripts/validate_raw_herb_food_balance.py` guards the new balance. Client survival feel testing found seeds/sugar cane too weak, so a follow-up tuning pass increased seed hidden-saturation roll amounts and sugar cane hidden saturation while keeping sugar cane visible hunger at +1; retest pending.
- Remaining immediate work after `1.1.3` packaging: real-client smoke test the final jars in module combinations, especially guide visibility, one-time hints, pharmacology tuning, Cuisine/Alchemy hidden-catalyst wording, P3.10 raw herb food-roll balance, and the new external ingredient/client data sync path with a small datapack.
- Food-mod compatibility work completed its five tracked rounds for the current decision. Author client testing passed for Farmer's Delight Refabricated + More Delight. RMF was removed due datapack-driven item identity / vanilla-item collision risk. Reference generated datapack remains under `docs/compat_drafts/food_mods_26_1_2/generated_pack/`, but it is not a public old-jar route. The Farmer+More compatibility is bundled into Core, and ordinary foods with explicit nature+nutrition profiles participate in nature pharmacology through a generic bridge without overriding target food components.

## Why this is next

P4.1 through P4.5 are now complete for the read/event extension boundary: `docs/JSON_EXTENSION_SPEC_1_1_3.md` freezes the supported JSON paths, `com.herbcraft.api.HerbcraftDataAPI` exposes safe read-only Java queries, `com.herbcraft.api.HerbcraftEvents` exposes observational events, examples show both JSON content and Java read/event usage, and `docs/reports/P4_EXTENSION_READINESS_1_1_3_20260617.md` summarizes release readiness. The source is now bumped to 1.1.3; food-nature tooltip/Jade/guide integration was fixed after client report; author final client sanity pass is now reported PASS, so the next step is release copy/platform final check. Separately, because Core jar behavior changed after the Farmer+More client test, one focused local sanity test with the refreshed Core jar and no standalone compat datapack is still recommended. Confirm Farmer+More entries still appear in 食材录/nutrition and that the 5 Farmer's Delight nature rows participate in pharmacology without breaking target food behavior.

Implementation report:

```text
docs/reports/NUTRITION_CORRECTION_IMPLEMENTATION_REPORT_20260615.md
```

Future ideas and a conservative `1.1.3` polish roadmap are collected in:

```text
docs/HERBCRAFT_FUTURE_IDEAS_AND_1_1_2_ROADMAP.md
```

Raw herb hunger/saturation rebalance source audit and refined parameter review are recorded in:

```text
docs/reports/HERB_FOOD_HUNGER_SATURATION_REBALANCE_REVIEW_20260616.md
docs/reports/HERB_FOOD_PROBABILITY_PARAMETER_REVIEW_20260616.md
docs/reports/HERB_FOOD_ROLLS_IMPLEMENTATION_REPORT_20260616.md
docs/reports/HERB_FOOD_SEED_SUGARCANE_TUNING_20260616.md
```

## Required next work

1.1.3 extension release track:

- Optional but recommended: install `herbcraft-p4-runtime-test-datapack-20260617.zip` in a test world, run `/reload`, drink two honey bottles to test a custom external special counter, and eat bread + baked potato to test datapack-added food-nature/七情 integration.
- Optional runtime check: create a tiny datapack with a new `special_counters` ID and verify threshold effects now count/persist.
- Current source is bumped to `1.1.3`; prepare final release sanity and copy.
- Run the full validator suite listed in `CURRENT_BASELINE.md` before tagging/uploading.
- Use `docs/reports/P4_EXTENSION_READINESS_1_1_3_20260617.md` as the release-readiness checklist.
- Keep Java write/registration APIs deferred. P4.1-P4.5 delivered JSON spec + read API + event API + examples + validators/docs, not mutable registration APIs.
- If writing release copy, describe this as an extension/API and data-compatibility release.

Compatibility sanity track:

- Client sanity for refreshed `release_output/herbcraft_test_20260614_review/herbcraft-1.1.3.jar` + Farmer's Delight + More Delight without standalone compat datapack is reported PASS by the author. If changing code again, repeat this sanity set.
- Final checked set included Farmer+More built-in compat behavior, food-nature tooltip/Jade/guide behavior, and removal of raw rice/seeds from compat entries. Next action is release text/platform readiness, not more compat-table editing unless a new client bug appears.
- Confirm target food behavior is not overwritten: hunger/saturation/consumption still feel like Farmer's Delight / More Delight, because the bridge must not use startup `herbs` component override.
- Final public route: refreshed Core jar with built-in optional compat. The generated datapack is reference/example material only, because older jars lack the food-nature bridge.
- Do not re-add RMF unless explicitly creating a separate experimental pack.

General `1.1.3` stabilization track:

1. Client-test Phase 2.1/P3.7 guidance in four module combinations: Core only, Core + Cuisine, Core + Alchemy, and all three modules. Confirm addon guide pages and module-owned hints only appear with their addon, and confirm the new 五味/七情 Codex microcopy is clear enough without adding new advancements.
2. In a real client, trigger several pharmacology principles and verify 五味/七情 guide lines become clearer and show useful recent item examples without spoiling unearned item entries. Use `docs/reports/PHARMACOLOGY_SEVEN_EMOTION_TEST_MATRIX_20260616.md`.
3. Client-test pharmacology tuning: exact hot/cold should no longer trigger same-qi on the 3rd bite; with current values it should be closer to the 5th exact-hot/cold bite unless qi is already biased.
4. Client-test that data-backed seven-emotion relation rules still match the table in `docs/reports/PHARMACOLOGY_SEVEN_EMOTION_TEST_MATRIX_20260616.md`.
5. Client-test the implemented P3.10 raw herb hunger/saturation rebalance in the packaged `1.1.3` jars. In a fresh survival world, verify wildflowers/petals/ferns/leaves/saplings no longer act as reliable early food; retest seeds after the stronger hidden-saturation pass (`S+2` ordinary seeds, `S+3` melon/pumpkin seeds); sugar cane should remain visible +1 but now feel like juicy short fullness and Homeostatic hydration amount 3; blue orchid should no longer bypass the model with guaranteed `minecraft:saturation`.
6. Test debug presets:

```mcfunction
/herbcraft nutrition preset @p correcting_flesh
/herbcraft nutrition preset @p correcting_oil
/herbcraft nutrition preset @p correcting_grain
/herbcraft nutrition preset @p excess_fruit_nonpunitive
/herbcraft nutrition preset @p fluid_surplus_pair
/herbcraft nutrition preset @p fluid_surplus_single
/herbcraft nutrition preset @p fluid_surplus_unrelated
/herbcraft nutrition preset @p fruit_low
```

8. Check:
   - `饮食回正中` / correcting appears in the nutrition panel when correction is active;
   - high dimensions decay faster than the old `-2/minute` during correction;
   - high `fruit` / 津液 / Fluids does not apply negative dietary imbalance;
   - `fluid_surplus_pair` (flesh+vege+fruit=900) should show correcting status and both flesh/vege should decay;
   - `fluid_surplus_single` (flesh+fruit=900) should NOT trigger surplus decay;
   - `fluid_surplus_unrelated` (flesh+oil+fruit=900) should NOT trigger surplus decay (flesh↔oil have 0.0 weight);
   - low `fruit` / 津液 still applies deficiency;
   - normal deficiency, well_nourished, water bowl relief, Cuisine clearing isolation, and custom nutrition effects still behave correctly.
9. If behavior feels too weak/strong, tune:

```text
correction_high_threshold (now 750, was 850)
correction_score_threshold
correction_extra_decay_min
correction_extra_decay_max
correction_target_value
correction_recent_window_ticks
nutrition_correction_rules.json matrix weights
fluid_surplus_decay_amount
fluid_surplus_target_value
Note: 750-849 range uses half decay rate; 850+ uses full rate
```

10. Record client results in a new report under `docs/reports/`.
11. Only after `1.1.3` guidance and correction system are stable, draft P4 API design before coding:

```text
docs/PUBLIC_EXTENSION_API_DESIGN.md
```

UI data-driven and beautification roadmap:

- **Layer 1 DONE**: `codex_theme.json` and `nutrition_theme.json` implemented. All UI constants are data-driven. Resource packs can override themes. Nutrition panel supports dynamic dimension count with auto-scaling.
- **Layer 2 DONE**: `CodexSnapshotPayload.EntrySnap` now carries `itemId`, `temperature`, `flavors`. Item icon rendering and nature flavor tag rendering are implemented in `CodexScreen` right panel. All disabled by default; enable by setting `show_entry_item_icon: true` and `nature_tags.enabled: true` in `codex_theme.json`.
- **Beautification NEXT**: Multi-round texture art direction discussion → AI-generate textures (background paper, header, divider, corners, scrollbar) → author review → activate breadcrumb, back button, visible scrollbar, search bar, and completion badge in theme JSON. Then enable item icons and nature tags.
- Layer 3 (declarative layout engine): deferred to future version.

Hardcore mod direction (confirmed by author):

- Mode B confirmed: independent hardcore survival mod (`严生` or `难存`) + Herbcraft compat bridge.
- Implementation after UI beautification is stable.
- Decisions recorded in `docs/reports/DECISIONS_UI_AND_HARDCORE_MOD_20260617.md`.
- Full discussion in `docs/reports/UI_DATADRIVEN_AND_HARDCORE_MOD_DEEP_DISCUSSION_20260617.md`.

## Do not do unless explicitly asked

- Do not claim P3 supports hot-reloadable world datapack FOOD/CONSUMABLE changes.
- Do not add a hard dependency on Homeostatic.
- Do not implement P4 Java API before nutrition correction client validation/tuning.
- Do not change stable IDs.
- Do not make main-mod nutrition more hardcore; reserve stricter mechanics for a future addon.

## Acceptance criteria

- Build passes.
- Validators in `CURRENT_BASELINE.md` pass, including `python3 scripts/validate_raw_herb_food_balance.py`.
- Client sanity pass has no visible blocker.
- Any new report is included in `herbcraft-source-current-20260614.zip`.
- `release_output/herbcraft_test_20260614_review/` contains current `1.1.3` jars and source zip, with the source zip still named `herbcraft-source-current-20260614.zip`.
- `CURRENT_BASELINE.md` is updated after any further modifying turn.
