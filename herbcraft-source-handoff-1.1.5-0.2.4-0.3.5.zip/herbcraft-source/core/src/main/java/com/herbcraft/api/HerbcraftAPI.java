package com.herbcraft.api;

import com.herbcraft.Herbcraft;
import java.util.Map;
import java.util.Optional;
import net.minecraft.world.item.Item;

public final class HerbcraftAPI {
   private HerbcraftAPI() {
   }

   public static Map<Item, HerbDefinition> getHerbRegistry() {
      return Herbcraft.getHerbDefinitions();
   }

   public static Optional<HerbDefinition> getDefinition(Item item) {
      return Optional.ofNullable(getHerbRegistry().get(item));
   }
}
