package com.herbcraft.knowledge.client;

import com.herbcraft.knowledge.CodexSnapshotPayload;
import com.herbcraft.knowledge.KnowledgeSyncPayload;
import com.herbcraft.nutrition.NutritionSyncPayload;
import com.herbcraft.nutrition.client.NutritionClientCache;
import com.herbcraft.nutrition.client.NutritionItemTooltips;
import com.herbcraft.nutrition.client.NutritionPanelScreen;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class HerbcraftCoreClient implements ClientModInitializer {
   private static final KeyMapping.Category HERBCRAFT_CATEGORY = KeyMapping.Category.register(
      Identifier.fromNamespaceAndPath("herbcraft", "keybinds")
   );
   private static final KeyMapping OPEN_NUTRITION = new KeyMapping(
      "key.herbcraft.open_nutrition_panel",
      InputConstants.Type.KEYSYM,
      GLFW.GLFW_KEY_N,
      HERBCRAFT_CATEGORY
   );

   public void onInitializeClient() {
      CodexClientTooltips.register();
      HerbNatureItemTooltips.register();
      NutritionItemTooltips.register();
      ClientPlayNetworking.registerGlobalReceiver(CodexSnapshotPayload.TYPE, (payload, context) -> context.client().setScreen(new CodexScreen(payload)));
      ClientPlayNetworking.registerGlobalReceiver(KnowledgeSyncPayload.TYPE, (payload, context) -> KnowledgeClientCache.update(payload.states()));
      ClientPlayNetworking.registerGlobalReceiver(NutritionSyncPayload.TYPE, (payload, context) ->
         NutritionClientCache.update(payload.values(), payload.statusOrdinal()));
      KeyMappingHelper.registerKeyMapping(OPEN_NUTRITION);
      ClientTickEvents.END_CLIENT_TICK.register(client -> {
         while (OPEN_NUTRITION.consumeClick()) {
            if (client.screen == null) {
               client.setScreen(new NutritionPanelScreen());
            } else if (client.screen instanceof NutritionPanelScreen) {
               client.setScreen(null);
            }
         }
      });
   }
}
