package com.herbcraft.logic;

import com.herbcraft.HerbcraftPlayerData;
import net.minecraft.world.entity.player.Player;

public final class HerbStackManager {
	private HerbStackManager() {}

	public static int updateAndGet(Player player, long gameTime, boolean stackGroup) {
		HerbcraftPlayerData data = (HerbcraftPlayerData) player;
		return stackGroup ? data.herbcraft$addHerbStack(gameTime) : data.herbcraft$getHerbStack(gameTime);
	}

	public static void overloadIfNeeded(Player player, int herbStack) {
		if (herbStack >= 10) {
			EffectResolver.addOverloadEffects(player);
			((HerbcraftPlayerData) player).herbcraft$clearHerbStack();
		}
	}
}
